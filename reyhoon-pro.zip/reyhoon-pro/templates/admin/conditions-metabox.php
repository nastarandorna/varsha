<div id="reyhoon-conditions-app" data-rules="<?php echo wc_esc_json( $conditions_json ); ?>" v-cloak>
	<div class="reyhoon-fields-row reyhoon-fields-row--meta" v-if="rules.length">
		<div class="reyhoon-fields-row__body">
			<div class="reyhoon-fields-row__body-row">
				<div class="reyhoon-fields-row__body-row-left">
					<h3><?php esc_html_e( 'Rules', 'reyhoon-pro' ); ?></h3>
					<p><?php echo esc_html( $messages['rules_description'] ); ?></p>
				</div>
				<div class="reyhoon-fields-row__body-row-right">
					<div class="reyhoon-conditions">
						<div class="reyhoon-conditions__row reyhoon-conditions__row--or" v-for="( orRule, orIndex ) in rules">
							<div v-if='0 != orIndex' class='reyhoon-conditions__row-label reyhoon-conditions__row-label--or'><?php esc_html_e( 'or', 'reyhoon-pro' ); ?></div>

							<div class="reyhoon-conditions__row reyhoon-conditions__row--and" v-for="( andRule, andIndex ) in orRule">
								<div class="reyhoon-conditions__row-item reyhoon-conditions__row-item--object-type">
									<select v-model='andRule.objectType' @change='resetConditions(andRule, orRule)'>
										<option value="product"><?php esc_html_e( 'Product', 'reyhoon-pro' ); ?></option>
										<option value="product_category"><?php esc_html_e( 'Product Category', 'reyhoon-pro' ); ?></option>
									</select>
								</div>
								<div class="reyhoon-conditions__row-item reyhoon-conditions__row-item--operator">
									<select v-model='andRule.operator' @change='resetConditions'>
										<option value="is_equal_to"><?php esc_html_e( 'Is equal to', 'reyhoon-pro' ); ?></option>
										<option value="not_equal_to"><?php esc_html_e( 'Is not equal to', 'reyhoon-pro' ); ?></option>
									</select>
								</div>
								<div class="reyhoon-conditions__row-item reyhoon-conditions__row-item--object">
									<v-select :placeholder="objectPlaceholder( andRule )" @search="fetchOptions" :options="conditionOptions" :filterable="false" v-model="andRule.objects">
										<template slot="no-options">
											<?php esc_html_e( 'Type to search...', 'reyhoon-pro' ); ?>
										</template>
									</v-select>
								</div>
								<div class="reyhoon-conditions__row-item reyhoon-conditions__row-item--action">
									<span class="dashicons dashicons-trash reyhoon-dashicons reyhoon-dashicons--trash" @click='deleteCondition( orIndex, andIndex )'></span>
								</div>
							</div>

							<!-- <button type='button' @click='addAndRule( orRule )' class='reyhoon-admin-button reyhoon-conditions__and-button'><?php esc_html_e( 'Add Rule', 'reyhoon-pro' ); ?></button> -->
						</div>

						<div class='reyhoon-conditions__row-label reyhoon-conditions__row-label--or'><?php esc_html_e( 'or', 'reyhoon-pro' ); ?></div>

						<button type='button' @click='addOrRule' class='reyhoon-admin-button reyhoon-conditions__or-button'><?php esc_html_e( 'Add Rule Group', 'reyhoon-pro' ); ?></button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div v-else class="reyhoon-fields-row reyhoon-fields-row--meta reyhoon-fields-row--empty">
		<button type="button" @click="addOrRule" class="reyhoon-admin-button"><?php esc_html_e( 'Add Your First Rule', 'reyhoon-pro' ); ?></button>
		<p><?php echo esc_html( $messages['no_condition'] ); ?></p>
	</div>

	<input type="hidden" v-model="conditionJson" name='reyhoon-pro-conditions'>
</div>
