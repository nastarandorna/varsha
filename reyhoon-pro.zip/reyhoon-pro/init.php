<?php
/**
 * Plugin Name: ریحون - حرفه ای
 * Author URI: https://avin-tarh.ir
 * Description: ساخت یک سیستم سفارش آنلاین غذا مشابه اسنپ فود برای ووکامرس (نسخه پرو)
 * Version: 3.0.0
 * Author: آوین طرح
 * Text Domain: reyhoon-pro
 * WC requires at least: 5.4.0
 * WC tested up to: 5.9.0
 */
require_once 'reyhoon-pro.php';
$reyhoon_pro = new Reyhoon_Pro();

/**
 * The code that runs during plugin activation.
 */
register_activation_hook( __FILE__, function () {

    update_option('avn_' . RYN_SELLER . '_reyhoon','');

} );
