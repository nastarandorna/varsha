<?php

defined('ABSPATH') || exit;

class Reyhoon_Product_Gallery
{
    /**
     * Init.
     */
    public static function run()
    {

        add_filter('reyhoon_default_settings', array(__CLASS__, 'default_settings'));
        add_filter('wpsf_register_settings_reyhoon', array(__CLASS__, 'register_settings'), 20);

        $setting = Reyhoon_Settings::get_setting('style_style_product_gallery');
        if(!$setting) {
            return;
        }

        add_action('reyhoon_after_product_hero', array(__CLASS__, 'add_product_galley'), 10 , 1);
        add_action('wp_enqueue_scripts', array(__CLASS__, 'loadFrontEndScript'));

    }

    public static function default_settings($default_settings = array())
    {
        $default_settings['product_gallery'] = false;
        return $default_settings;
    }

    /**
     * Register settings.
     *
     * @param array $settings
     *
     * @return array
     */
    public static function register_settings($settings = array())
    {

        $settings['sections']['style']['fields'][] = array(
                    'id' => 'product_gallery',
                    'type' => 'toggle',
                    'title' => 'فعال سازی گالری تصاویر محصول',
                    'default' => false
                );

        return $settings;

    }

    public static function loadFrontEndScript()
    {
        wp_enqueue_style('glightbox', REYHOON_PRO_URL . 'inc/modules/product-gallery/assets/glightbox.min.css', array(), '', 'all');
        wp_enqueue_script('glightbox', REYHOON_PRO_URL . 'inc/modules/product-gallery/assets/glightbox.min.js', array('jquery'), REYHOON_PRO_VERSION ,true);
        wp_add_inline_script('glightbox', 'const lightbox = GLightbox();');
    }

    public static function add_product_galley($product)
    {
        $attachment_ids = $product->get_gallery_image_ids();
        array_unshift($attachment_ids,$product->get_image_id());

        if(!empty($attachment_ids)) {
            echo '<div class="gallery hidden">';
            foreach ( $attachment_ids as $attachment_id ) {
                self::template($attachment_id, $product->get_id());
            }
            echo '</div>';
        }

    }


    public static function template($attachment_id, $id) {
        $src = wp_get_attachment_image_src( $attachment_id, 'full' );
        ?>
        <a class="glightbox" href="<?=$src[0]; ?>" data-gallery="gallery<?=$id ?>">
        </a>

    <?php
    }
}
