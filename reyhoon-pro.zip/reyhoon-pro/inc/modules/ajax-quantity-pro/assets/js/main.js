var reyModule = {};
(function ($) {
    "use strict";

    reyModule.loopQTY = (function () {
        return {
            /*
            * Constructor
            * */
            init: function () {
                this.firstClickAddToCart();
                //      this.qtyBtnClick();
            },
            /*
            * First Click
            * */
            firstClickAddToCart: () => {

                $('body').on('click', '.reyhoon-product__add-to-order[data-reyhoon-trigger=""]', function (e) {

                    e.preventDefault();
                    var clicked = $(this);
                    var quantity = clicked.siblings('.loop-qty');
                    clicked.addClass('reyhoon-button--loading');
                    var count = quantity.find('.reyhoon-quantity-roller__button--increase');
                    count.attr('data-reyhoon-quantity', parseInt(count.attr('data-reyhoon-quantity')) + 1);
                    count.siblings('span').text(count.attr('data-reyhoon-quantity'));
                    var data = {
                        action: 'rey_first_qty',
                        id: clicked.closest('.reyhoon-product__actions-button').find('button.reyhoon-product__add-to-order').attr('data-reyhoon-product-id'),
                        variation_id: clicked.closest('.reyhoon-product__actions-button').find('button.reyhoon-product__add-to-order').attr('data-reyhoon-variation-id'),
                        quantity: count.data('reyhoon-quantity'),
                    };


                    $.ajax({
                        url: reyhoon_vars.ajax_url,
                        type: 'POST',
                        dataType: 'json',
                        data : data,
                        beforeSend: ()=> {
                            clicked.css('pointer-events', 'none');
                        },
                        success : (response)=>{
                            // clicked.css('pointer-events', '');
                            clicked.hide();
                            clicked.removeClass('reyhoon-button--loading');
                            count.data('qty') === 1 ? $('.reyhoon-quantity-roller__button--decrease').addClass('recycle') : $('.reyhoon-quantity-roller__button--decrease').removeClass('recycle') ;
                            count.siblings('.reyhoon-quantity-roller__button--decrease').addClass('recycle');
                            count.siblings('.reyhoon-quantity-roller__button--decrease').attr('data-reyhoon-cart-item-key',response.item_key);
                            count.attr('data-reyhoon-cart-item-key',response.item_key);
                            clicked.css('pointer-events', '');
                            addQty();
                            $(document.body).trigger('wc_fragment_refresh');
                        }
                    });



                    $(document.body).on('added_to_cart', function () {
                        //reyModule.tools.rmPreloader();

                    });

                    function addQty() {
                        quantity.css('display', 'flex');
                    }

                });
            },

            /*
            * Each Click On plus and minus Button
            * */
            qtyBtnClick: () => {

                $(document).on('click', '.loop-qty button', function (event) {
                    event.preventDefault();


                    var clicked = $(this);
                    var count = clicked.closest('.loop-qty').find('.reyhoon-quantity-roller__quantity');
                    clicked.data('type') === 'increase' ? count.data('qty', parseInt(count.data('reyhoon-quantity')) + 1) : count.data('qty', parseInt(count.data('reyhoon-quantity')) - 1);
                    count.text(count.data('qty'));
                    var data = {
                        action: 'rey_loop_qty',
                        id: clicked.closest('.reyhoon-product__actions-button').find('button.reyhoon-product__add-to-order').attr('data-reyhoon-product-id'),
                        variation_id : clicked.closest('.reyhoon-product__actions-button').find('button.reyhoon-product__add-to-order').attr('data-reyhoon-variation-id'),
                        quantity: count.data('qty'),
                    };

                    $.ajax({
                        url: reyhoon_vars.ajax_url,
                        type: 'POST',
                        dataType: 'json',
                        data : data,
                        async : false,
                        beforeSend: ()=> {
                            // clicked.css('pointer-events', 'none');
                            //reyModule.tools.preloader(clicked);
                        },
                        success : ()=>{
                            // clicked.css('pointer-events', '');
                            count.data('qty') === 1 ? $('.reyhoon-quantity-roller__button--decrease').addClass('recycle') : $('.reyhoon-quantity-roller__button--decrease').removeClass('recycle') ;
                            $(document.body).trigger('wc_fragment_refresh');
                        }
                    });
                    // since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
                    /*  $.post(reyhoon_vars.ajax_url, data, function (response) {
                          // reyModule.tools.alert(response.data);

                          //$(document.body).trigger('wc_fragment_refresh');
                          //  reyModule.tools.rmPreloader();
                          clicked.css('pointer-events', '');
                      });*/
                });
            }
        }
    }());

    $(document).ready(function () {
        reyModule.loopQTY.init();
    });

})(jQuery);
