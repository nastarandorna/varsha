<?php
/**
 * Module: Layouts Pro.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

/**
 * Timings module class.
 */
class Reyhoon_Layouts_Pro
{
    /**
     * Init.
     */
    public static function run()
    {
        add_filter('reyhoon_layout_sections_field', array(__CLASS__, 'layout_sections_field'), 10, 3);
        add_filter('reyhoon_layout_cards_field', array(__CLASS__, 'layout_cards_field'), 10, 3);
        add_filter('reyhoon_layout_defaults', array(__CLASS__, 'layout_defaults'), 10, 2);
        add_filter('reyhoon_layout_settings_save_data', array(__CLASS__, 'layout_settings_save_data'), 10, 2);
        add_filter('reyhoon_main_class', array(__CLASS__, 'reyhoon_main_class'), 10, 2);
        add_action('reyhoon_main_before_sections', array(__CLASS__, 'add_tabs'), 10, 2);
        add_action('reyhoon_main_before_sections', array(__CLASS__, 'add_tabs_tab'), 10, 2);
        add_action('reyhoon_main_before_products', array(__CLASS__, 'add_child_category_headings'), 10, 3);
        add_filter('reyhoon_flatten_products_by_category_level', array(__CLASS__, 'maybe_flatten_products_by_category'), 10, 2);
    }

    /**
     * Layout sections field.
     *
     * @param string $field
     * @param array $layout_settings
     */
    public static function layout_sections_field($field, $layout_settings = array())
    {
        woocommerce_wp_select(
            array(
                'id' => 'reyhoon_sections',
                'label' => '',
                'options' => array(
                    'no_titles' => __('No Titles or Tabs', 'reyhoon-pro'),
                    'titles' => __('All Category Titles', 'reyhoon-pro'),
                    'cat_titles' => __('Main Category Titles Only', 'reyhoon-pro'),
                    'sub_cat_titles' => __('Subcategory Titles Only', 'reyhoon-pro'),
                    'top_tabs' => __('Top Tabs', 'reyhoon-pro'),
                    'tabs_tab' =>  __('Tabs style 1', 'reyhoon-pro'),
                    'tabs_tab_1' =>  __('Tabs style 2', 'reyhoon-pro'),
                    'tabs_tab_2' =>  __('Tabs style 3', 'reyhoon-pro'),
                ),
                'value' => esc_attr($layout_settings['sections']),
            )
        );
    }

    public static function layout_cards_field($field, $layout_settings = array())
    {
        woocommerce_wp_select(
            array(
                'id' => 'reyhoon_cards',
                'label' => '',
                'options' => array(
                    'style_1' => __('style 1', 'reyhoon-pro'),
                    'style_2' => __('style 2', 'reyhoon-pro'),
                    'style_3' => __('style 3', 'reyhoon-pro'),
                ),
                'value' => esc_attr($layout_settings['cards']),
            )
        );
    }

    /**
     * Add Reyhoon shortcode defaults.
     *
     * @param array $defaults
     * @param int $layout_id
     *
     * @return array
     */
    public static function layout_defaults($defaults = array(), $layout_id = null)
    {
        $defaults['sections'] = 'no_titles';

        return $defaults;
    }

    /**
     * Add fields to layout settings save data.
     *
     * @param array $save_data
     *
     * @return array
     */
    public static function layout_settings_save_data($save_data = array())
    {
        $save_data['sections'] = filter_input(INPUT_POST, 'reyhoon_sections', FILTER_SANITIZE_STRING);
        $save_data['cards'] = filter_input(INPUT_POST, 'reyhoon_cards', FILTER_SANITIZE_STRING);

        return $save_data;
    }

    /**
     * Add classes to Reyhoon main layout.
     *
     * @param string $class
     * @param array $args
     *
     * @return string
     */
    public static function reyhoon_main_class($class = '', $args = array())
    {
        if (empty($args['sections'])) {
            return $class;
        }

        if (strpos($args['sections'], 'tabs') !== false) {
            $class .= ' reyhoon-main--sections-tabs';
        }

        $class .= ' reyhoon-main--sections-' . $args['sections'];

        return $class;
    }

    /**
     * Add tabs to Reyhoon main layout.
     *
     * @param array $args
     * @param array $products
     */
    public static function add_tabs($args = array(), $products)
    {
        if (empty($args['sections'])) {
            return;
        }

        include REYHOON_PRO_MODULES_PATH . 'layouts-pro/templates/tabs.php';
    }
    /**
     * Add tabs to Reyhoon main layout.
     *
     * @param array $args
     * @param array $products
     */
    public static function add_tabs_tab($args = array(), $products)
    {
        if (empty($args['sections'])) {
            return;
        }

        include REYHOON_PRO_MODULES_PATH . 'layouts-pro/templates/tabs-tab.php';
    }

    /**
     * Add child category headings to Reyhoon main layout.
     */
    public static function add_child_category_headings($args = array(), $category = array(), $products = array())
    {

        if (empty($args['sections'])) {
            return;
        }

        include REYHOON_PRO_MODULES_PATH . 'layouts-pro/templates/child-category-heading.php';

    }

    /**
     * Maybe flatten products by category.
     *
     * @param string $flatten_level
     * @param array $args
     *
     * @return mixed
     */
    public static function maybe_flatten_products_by_category($flatten_level, $args = array())
    {
        $sections = isset($args['sections']) ? $args['sections'] : null;

        if (empty($sections) || 'no_titles' === $sections) {
            return 'all';
        }

        if ('cat_titles' === $sections) {
            return 'children';
        }

        return 'none';
    }

    /**
     * Get tab item classes.
     *
     * @param int $i
     * @param array $category
     *
     * @return mixed|void
     */
    public static function get_tab_item_classes($i, $category = array())
    {
        $classes = array('reyhoon-tabs__item');

        if (0 === $i) {
            $classes[] = 'reyhoon-tabs__item--active';
        }

        if (!empty($category['children'])) {
            $classes[] = 'reyhoon-tabs__item--has-children';
        }

        if (!empty($category['parent'])) {
            $classes[] = 'reyhoon-tabs__item--has-parent';
        }

        return apply_filters('reyhoon-tab-item-classes', $classes, $i, $category);
    }
}
