<?php
/**
 * Layout: Category heading.
 *
 * @package Reyhoon/Templates
 *
 * @var $category array Category array.
 */

defined( 'ABSPATH' ) || exit;

?>

<?php if ( empty( $category ) ) {
	return;
} ?>

<div class="reyhoon-category-heading reyhoon-category-heading--depth-<?php echo esc_attr( $category['depth'] ); ?>">
	<?php if ( 0 === $category['depth'] ) { ?>
		<h2 class="reyhoon-category-heading__title"><?php echo $category['name']; ?></h2>
	<?php } else { ?>
		<h3 class="reyhoon-category-heading__title reyhoon-category-heading__title--sub-category"><?php echo $category['name']; ?></h3>
	<?php } ?>

	<?php if ( ! empty( $category['description'] ) ) { ?>
		<p class="reyhoon-category-heading__description"><?php echo $category['description']; ?></p>
	<?php } ?>
</div>