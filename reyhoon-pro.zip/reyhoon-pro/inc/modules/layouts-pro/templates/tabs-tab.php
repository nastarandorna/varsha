<?php
/**
 * Layout: Tabs Tab.
 *
 * @package Reyhoon/Templates
 *
 * @var $products array Produces array.
 */

defined( 'ABSPATH' ) || exit;

if ( ! in_array( $args['sections'], array( 'tabs_tab','tabs_tab_1' ,'tabs_tab_2'), true ) || isset( $products[0] ) ) {
    return;
}
?>
<?php
do_action('reyhoon_before_tabs');

switch ($args['sections']){
    case 'tabs_tab_1':
        $layout_style = 'tabs-blur';
        break;
    case 'tabs_tab_2':
        $layout_style = 'tabs-blur-2';
}
?>
<div class="reyhoon-main__tabs-tab <?=$layout_style?>">
    <?php $i = 0;
    foreach ( $products as $product_group ) {
        $category = $product_group['category'];
        $classes = Reyhoon_Layouts_Pro::get_tab_item_classes( $i, $category );
        $thumbnail_id = get_term_meta($category['id'], 'thumbnail_id', true);
            $image = wp_get_attachment_url($thumbnail_id) === false ? REYHOON_ASSETS_URL . 'img/no-cat-img.svg' : wp_get_attachment_url($thumbnail_id);
        ?>
        <button type="button" data-cat="#category-<?php echo esc_attr( $category['id'] ); ?>" class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" role="tab">
            <img src="<?=$image; ?>" width="50px" height="auto">
            <?php echo wp_kses_post( $category['name'] ); ?>
        </button>
        <?php $i ++;
    } ?>
</div>

<script>
    jQuery(document).ready(function($) {
        let button = $('.reyhoon-tabs__item');
        let tabContents = $('.reyhoon-main__group')
        button.click(function () {
            let $this = $(this);
            if(typeof $this.data('parent-cat') === 'undefined') {
                $('.reyhoon-main__tabs-tab:not(.child-tab) > button').removeClass('reyhoon-tabs__item--active');
                tabContents.hide(250);
            }else {
                $('.child-tab > button').removeClass('reyhoon-tabs__item--active');
                $('.child-group .reyhoon-products-list').hide(250)
            }

            $this.addClass('reyhoon-tabs__item--active');
            $($(this).data('cat')).show(250);
        })
    });
</script>
