<?php
/** @var $category array Produces array.
 */
defined( 'ABSPATH' ) || exit;

if ( ! in_array( $args['sections'], array( 'tabs_tab'), true ) )  {
    return;
}
?>
<?php
do_action('reyhoon_before_child_tabs');
//FIXME add option for supermarket
?>
<div class="reyhoon-main__tabs-tab child-tab">
    <?php $i = 0;
    $has_child_categories = ! empty( $category['children'] );
    if($has_child_categories){
    foreach ( $category['children'] as $child_category_group ) {
        $category = $child_category_group['category'];
        $classes = Reyhoon_Layouts_Pro::get_tab_item_classes( $i, $category );
        $thumbnail_id = get_term_meta($category['id'], 'thumbnail_id', true);
        $image = wp_get_attachment_url($thumbnail_id) === false ? REYHOON_ASSETS_URL . 'img/no-cat-img.svg' : wp_get_attachment_url($thumbnail_id);
        ?>
        <button type="button" data-cat="#category-<?php echo esc_attr( $category['id'] ); ?>" data-parent-cat="#category-<?php echo esc_attr( $category['parent'] ); ?>" class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" role="tab">
            <img src="<?=$image; ?>" width="50px" height="auto">
            <?php echo wp_kses_post( $category['name'] ); ?>
        </button>
        <?php $i ++;
    }
    }?>
</div>
