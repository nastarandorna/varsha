<?php
/**
 * Layout: Tabs.
 *
 * @package Reyhoon/Templates
 *
 * @var $products array Produces array.
 */

defined( 'ABSPATH' ) || exit;

if ( ! in_array( $args['sections'], array( 'top_tabs' ), true ) || isset( $products[0] ) ) {
	return;
}
?>
<?php
 do_action('reyhoon_before_tabs');
?>
<ul class="reyhoon-main__tabs">
	<?php $i = 0;
	foreach ( $products as $product_group ) {
		$category = $product_group['category'];
		$classes = Reyhoon_Layouts_Pro::get_tab_item_classes( $i, $category );
        $thumbnail_id = get_term_meta($category['id'], 'thumbnail_id', true);
        $image = wp_get_attachment_url($thumbnail_id);
        ?>
		<li class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" role="tab">
			<a href="#category-<?php echo esc_attr( $category['id'] ); ?>" class="reyhoon-tabs__link"><?php echo $image ? "<img src='{$image}'>" : "" ?><?php echo wp_kses_post( $category['name'] ); ?></a>
		</li>
		<?php $i ++;
	} ?>
</ul>
<div class="fix-sticky"></div>

