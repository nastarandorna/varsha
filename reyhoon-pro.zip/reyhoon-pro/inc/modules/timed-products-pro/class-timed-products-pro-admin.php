<?php
/**
 * Module: Timed Products Pro.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Timed Products Pro Settings class.
 */
class Reyhoon_Timed_Products_Pro_Admin {
	/**
	 * Init.
	 */
	public static function run() {
		add_action( 'init', array( __CLASS__, 'register_cpt' ), 100 );
		add_action( 'load-post.php', array( __CLASS__, 'init_metaboxes' ) );
		add_action( 'load-post-new.php', array( __CLASS__, 'init_metaboxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save_metabox' ) );
        remove_action( 'admin_menu', array( 'Reyhoon_Timed_Products', 'add_settings_page' ) );
	}


	/**
	 * Register Custom Post Type.
	 */
	public static function register_cpt() {
		$labels = array(
			'plural'   => __( 'Timed Products', 'reyhoon-pro' ),
			'singular' => __( 'Timed Products Rule', 'reyhoon-pro' ),
		);

		$args = array(
			'labels'              => Reyhoon_Helpers::prepare_post_type_labels( $labels ),
			'supports'            => array( 'title' ),
			'hierarchical'        => false,
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => 'reyhoon',
			'menu_position'       => 10,
			'show_in_admin_bar'   => true,
			'show_in_nav_menus'   => true,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'capability_type'     => 'product',
		);

		register_post_type( 'timed_prod_condition', $args );
	}

	/**
	 * Initialize meta boxes.
	 */
	public static function init_metaboxes() {
		add_meta_box(
			'reyhoon-timed-product-rules-metabox',
			__( 'Rules', 'reyhoon-pro' ),
			array( __CLASS__, 'output_time_rules_metabox' ),
			'timed_prod_condition',
			'advanced',
			'default'
		);

		add_meta_box(
			'reyhoon-timed-product-product-conditions',
			__( 'Conditions', 'reyhoon-pro' ),
			array( __CLASS__, 'render_conditions_metabox' ),
			'timed_prod_condition',
			'advanced',
			'default'
		);
	}

	/**
	 * Render date/time metabox.
	 *
	 * @param WP_Post $post Post object.
	 */
	public static function output_time_rules_metabox( $post ) {
		$rules_json = get_post_meta( $post->ID, '_reyhoon_time_rules', true );
		$rules_json = wp_json_encode( $rules_json );

		include REYHOON_PRO_PATH . 'inc/modules/timed-products-pro/templates/admin/timed-products-rules-metabox.php';
	}

	/**
	 * Display Product/categories metabox.
	 *
	 * @param WP_Post $post Post object.
	 *
	 * @return void
	 */
	public static function render_conditions_metabox( $post ) {
		$conditions      = get_post_meta( $post->ID, '_reyhoon_timed_products_condition', true );
		$conditions_json = wp_json_encode( $conditions );

		$messages = array(
			'no_condition'      => __( 'If you do not add any conditions, this time rule will not apply for any product.', 'reyhoon-pro' ),
			'rules_description' => __( 'Add a set of rules to select the products for which these time rules will apply.', 'reyhoon-pro' ),
		);

		include REYHOON_PRO_PATH . 'templates/admin/conditions-metabox.php';
	}

	/**
	 * Save metabox data.
	 *
	 * @param int $post_id Post ID.
	 */
	public static function save_metabox( $post_id ) {
		// Save time rule metabox.
		$time_data = filter_input( INPUT_POST, 'reyhoon-timed-products-conditions' );

		if ( $time_data ) {
			$time_data = json_decode( $time_data, true );
			update_post_meta( $post_id, '_reyhoon_time_rules', $time_data );
		}

		// Save conditions metabox.
		$conditions_data = filter_input( INPUT_POST, 'reyhoon-pro-conditions' );

		if ( $conditions_data ) {
			$conditions_data = json_decode( $conditions_data, true );
			update_post_meta( $post_id, '_reyhoon_timed_products_condition', $conditions_data );
		}
	}
}
