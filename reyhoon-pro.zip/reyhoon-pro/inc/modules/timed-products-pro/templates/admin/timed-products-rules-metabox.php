<?php
/**
 * Template to display the HTML for Timed Products conditions meta box.
 *
 * @package Reyhoon_Pro
 */

?>
<div id="reyhoon-timed-products-app" v-cloak data-rules="<?php echo wc_esc_json( $rules_json ); ?>">

	<div class="reyhoon-fields-row reyhoon-fields-row--meta">
		<div class="reyhoon-fields-row__body">

			<!-- Action row  -->
			<div class="reyhoon-fields-row__body-row">
				<div class="reyhoon-fields-row__body-row-left">
					<h3><?php esc_html_e( 'Action', 'reyhoon-pro' ); ?></h3>
					<p><?php esc_html_e( 'Whether to show or hide product when these conditions are met.', 'reyhoon-pro' ); ?></p>	
				</div>
				<div class="reyhoon-fields-row__body-row-right">
					<select v-model='action'>
						<option value='set_visible'><?php esc_html_e( 'Set Visible', 'reyhoon-pro' ); ?></option>
						<option value='set_hidden'><?php esc_html_e( 'Set Hidden', 'reyhoon-pro' ); ?></option>
					</select>
				</div>
			</div>

			<!-- Rules row -->
			<div class="reyhoon-fields-row__body-row">
				<div class="reyhoon-fields-row__body-row-left">
					<h3><?php esc_html_e( 'Timed Product Rules', 'reyhoon-pro' ); ?></h3>
					<p><?php esc_html_e( 'Add a set of rules to determine the timing for products.', 'reyhoon-pro' ); ?></p>
				</div>
				<div class="reyhoon-fields-row__body-row-right" :class="{ 'reyhoon-fields-row__body-row-right--empty': ! rules.length }">
					<div class="reyhoon-time-conditions" v-if="rules.length">
						<div class="reyhoon-time-conditions__row" v-for="( rule, ruleIndex ) in rules" ref='conditionRows'>
							<div>
								<select v-model='rule.date_condition'>
									<option value="on_date"><?php esc_html_e( 'On date', 'reyhoon-pro' ); ?></option>
									<option value="before_date"><?php esc_html_e( 'Before Date', 'reyhoon-pro' ); ?></option>
									<option value="after_date"><?php esc_html_e( 'After Date', 'reyhoon-pro' ); ?></option>
									<option value="date_range"><?php esc_html_e( 'Date Range', 'reyhoon-pro' ); ?></option>
									<option value="day_of_week"><?php esc_html_e( 'Day of the Week', 'reyhoon-pro' ); ?></option>
									<option value="time_range"><?php esc_html_e( 'Time Range', 'reyhoon-pro' ); ?></option>
								</select>

								<date-picker 
									v-model="rule.date_from" 
									type="date" 
									:placeholder="fromPlaceholder( rule )"
									value-type="format" 
									format="YYYY-MM-DD" 
									v-if=' [ "date_range", "after_date", "on_date" ].includes( rule.date_condition ) '>
								</date-picker>

								<date-picker 
									v-model="rule.date_to"
									:placeholder="i18n.to"
									type="date"
									value-type="format"
									format="YYYY-MM-DD" 
									v-if=' [ "date_range", "before_date" ].includes( rule.date_condition )'
									v-tooltip.bottom="{
										content: i18n.date_validation,
										show: rule.date_from && rule.date_to && 'date_range' == rule.date_condition && ( new Date( rule.date_to ) <= new Date( rule.date_from ) ),
										trigger: 'manual',
									}"
									>
								</date-picker>

								<reyhoon-multiselect v-if='[ "day_of_week" ].includes( rule.date_condition )' :days='rule.days' :idx="ruleIndex"  @day_changed="dayChanged"></reyhoon-multiselect>

								<date-picker
									v-model="rule.time_from"
									v-if='"time_range" == rule.date_condition'
									:time-picker-options="{
										start: '00:00',
										step: '00:30',
										end: '23:30',
									}"
									format="HH:mm"
									value-type="format"
									:use12h="true"
									type="time"
									:placeholder="i18n.from"
									>
								</date-picker>

								<date-picker
									v-model="rule.time_to"
									v-if='"time_range" == rule.date_condition'
									:time-picker-options="{
										start: '00:00',
										step: '00:30',
										end: '23:30',
									}"
									format="HH:mm"
									value-type="format"
									type="time"
									:placeholder="i18n.to"
									:use12h="true"
									v-tooltip.bottom="{
										content: i18n.time_validation,
										show: rule.time_to && rule.time_from && ( rule.time_to <= rule.time_from ),
										trigger: 'manual',
									}"
									>
								</date-picker>
							</div>

							<div class="reyhoon-time-conditions__row__and_label"><?php esc_html_e( 'and', 'reyhoon-pro' ); ?></div>

							<div class="reyhoon-conditions__row-item reyhoon-conditions__row-item--action">
								<span class="dashicons dashicons-trash reyhoon-dashicons reyhoon-dashicons--trash" @click='deleteCondition( ruleIndex )'></span>
							</div>
						</div>

						<button type='button' @click='addRule' class='reyhoon-admin-button reyhoon-conditions__or-button'><?php esc_html_e( 'Add Time', 'reyhoon-pro' ); ?></button>
					</div>
					<div v-else class="reyhoon-fields-row reyhoon-fields-row--meta reyhoon-fields-row--empty">
						<button type="button" @click="addRule" class="reyhoon-admin-button"><?php esc_html_e( 'Add Your First Rule', 'reyhoon-pro' ); ?></button>
					</div>
				</div>
			</div>
			<!-- Rules row ends -->

			<div class="reyhoon-fields-row__body-row">
				<div class="reyhoon-fields-row__body-row-left">
					<h3><?php esc_html_e( 'Current Date/Time', 'reyhoon-pro' ); ?></h3>
					<p><?php esc_html_e( 'The current date and time of your store.', 'reyhoon-pro' ); ?></p>
				</div>
				<div class="reyhoon-fields-row__body-row-right">
					<code style="margin: 0 10px 0 0; border-radius: 4px;"><?php echo esc_html( date_i18n( 'l, j F Y' ) ); ?></code>
					<code style="margin: 0 10px 0 0; border-radius: 4px;"><?php echo esc_html( date_i18n( 'G:i' ) ); ?></code>
					<a href="<?php echo esc_url( admin_url( 'options-general.php#timezone_string' ) ); ?>" target="_blank"><?php esc_html_e( 'Date/time settings', 'reyhoon-pro' ); ?></a>
				</div>
			</div>
		</div> <!-- reyhoon-fields-row__body -->
	</div> <!-- reyhoon-fields-row -->

	<input type="hidden" v-model="rulesJson" name='reyhoon-timed-products-conditions'>
</div>
