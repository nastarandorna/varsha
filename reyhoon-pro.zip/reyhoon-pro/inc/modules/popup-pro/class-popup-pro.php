<?php
/**
 * Module: Popup
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

/**
 * Popup module class.
 */
class Reyhoon_Popup_Pro
{
	public static function run()
	{
		add_action('wp_enqueue_scripts',[__CLASS__,'load_assets']);
        add_action('wp_footer',[__CLASS__,'render_popup_overlay']);
	}

	public static function load_assets() {
		wp_enqueue_script('ryn-popup',REYHOON_PRO_URL . 'inc/modules/popup-pro/assets/js/popup.js',array(),REYHOON_PRO_VERSION );
		wp_enqueue_script('ryn-event',REYHOON_PRO_URL . 'inc/modules/popup-pro/assets/js/events.js',array('ryn-popup'),REYHOON_PRO_VERSION);
		wp_enqueue_style('ryn-popup',REYHOON_PRO_URL . 'inc/modules/popup-pro/assets/css/popup.css',array(),REYHOON_PRO_VERSION,'all');
	}

    public static function render_popup_overlay()
    {
        echo '<div class="overlay" id="rynOverlay"></div>';
        echo '<div id="ryn-popup-container"></div>';
    }

}
