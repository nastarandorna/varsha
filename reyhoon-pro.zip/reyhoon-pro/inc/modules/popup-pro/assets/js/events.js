jQuery(document).ready(function ($) {
    $( document.body ).on('popup-handler',initPopup);
})
function initPopup(e , data) {
    popup(data);
}
