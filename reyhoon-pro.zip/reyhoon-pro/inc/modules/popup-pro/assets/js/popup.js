const popupQueue = [];
let overlayEvent = true;
let popupShown = {};


// Read cookie value by name
function getCookie(name) {
    const value = "; " + document.cookie;
    const parts = value.split("; " + name + "=");
    if (parts.length === 2) return parts.pop().split(";").shift();
}

// Set cookie with expiration time (in hours)
function setCookie(name, value, hours) {
    const d = new Date();
    d.setTime(d.getTime() + (hours * 60 * 60 * 1000));
    const expires = "expires=" + d.toUTCString();
    document.cookie = name + "=" + value + ";" + expires + ";path=/";
}

// Check if popup has been shown before
function checkPopupStatus() {
    const cookieValue = getCookie("popupShown");
    if (cookieValue) {
        popupShown = JSON.parse(cookieValue);
    }
}

// Initialize by checking cookie
checkPopupStatus();
const popup = (options) => {

    let close = options.close || '';

    var popup = document.createElement('div');
    var popupImage = document.createElement('div');
    var popupHeader = document.createElement('div');
    var popupBody = document.createElement('div');
    var popupActions = document.createElement('div');
    var overlay = document.getElementById('rynOverlay');
    var popupContainer = document.getElementById('ryn-popup-container');

    if (!close) {
        if (popupShown[options.name]) {

            return; // Check if the popup with the given name has already been shown
        } else {

            popupShown[options.name] = true;
            setCookie("popupShown", JSON.stringify(popupShown), 6); // Set cookie for 6 hours
        }
    }

    popupImage.innerHTML = options.image || '';
    popupHeader.textContent = options.header || '';
    popupBody.innerHTML = options.body || '';
    var popupClass = options.class || '';

    if (options.actions && Array.isArray(options.actions)) {
        options.actions.forEach(function (action) {
            var actionButton = document.createElement('button');
            actionButton.textContent = action.text || '';
            actionButton.classList.add(action.class || '');
            actionButton.addEventListener('click', function () {
                if (typeof action.callback === 'function') {
                    action.callback();
                }
            });
            popupActions.appendChild(actionButton);
        });
    }

    popup.appendChild(popupImage);
    popup.appendChild(popupHeader);
    popup.appendChild(popupBody);
    popup.appendChild(popupActions);

    // Add CSS classes or styles to style the popup container and its elements
    popup.classList.add('ryn-popup');
    if (popupClass)
        popup.classList.add(popupClass);
    popupImage.classList.add('ryn-popup-img');
    popupHeader.classList.add('popup-title');
    popupBody.classList.add('popup-content');
    popupActions.classList.add('ryn-popup-action');

    // Display the overlay
    overlay.style.display = 'block';
    popupContainer.style.display = 'block';

    if (close) {
        closePopup();
        return;
    }

    // Add the popup to the stack
    popupQueue.push(popup);

    // Append the popup container to the document body
    popupContainer.appendChild(popup);

    if (overlayEvent) {
        overlay.addEventListener('click', function (event) {
            if (event.target === overlay) {
                closePopup();
            }
        });
        overlayEvent = false;
    }

    function closePopup() {

        // حذف پاپ آپ از ابتدای صف
        const removedPopup = popupQueue.shift();

        if (removedPopup) {
            removedPopup.remove();
        }

        // نمایش پاپ آپ بعدی (اگر وجود داشت)
        const nextPopup = popupQueue[0];

        if (nextPopup) {
            overlay.style.display = 'block';
            popupContainer.style.display = 'block';
        } else {
            overlay.style.display = 'none';
            popupContainer.style.display = 'none';
        }
    }

};
