<?php
/**
 * Module: Timings Pro Checkout.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Timings module class.
 */
class Reyhoon_Timings_Pro_Checkout {
	/**
	 * Init.
	 */
	public static function run() {
		add_action( 'woocommerce_checkout_process', array( __CLASS__, 'validate_checkout' ) );
		add_filter( 'reyhoon_checkout_data', array( __CLASS__, 'modify_checkout_data' ) );
	}

	/**
	 * Validate checkout fields.
	 *
	 * @throws Exception
	 */
	public static function validate_checkout() {
		$order_date = filter_input( INPUT_POST, 'reyhoon_order_date', FILTER_SANITIZE_STRING );
		$order_time = filter_input( INPUT_POST, 'reyhoon_order_time', FILTER_SANITIZE_STRING );

		if ( isset( $_POST['reyhoon_order_date'] ) && empty( $order_date ) ) {
			$orders_remaining = Reyhoon_Timings_Pro::get_orders_remaining_for_date( $order_date );

			if ( $orders_remaining <= 0 ) {
				wc_add_notice( __( 'Sorry, the date you selected is no longer available. Please choose another.', 'reyhoon-pro' ), 'error' );
			}
		}

		if ( isset( $_POST['reyhoon_order_time'] ) && empty( $order_time ) ) {
			wc_add_notice( __( 'Please select an order time.', 'reyhoon-pro' ), 'error' );
		}
	}

	/**
	 * Process checkout fields.
	 *
	 * @param array $checkout_data Checkout data to save.
	 *
	 * @return mixed
	 */
	public static function modify_checkout_data( $checkout_data ) {
		$order_time = filter_input( INPUT_POST, 'reyhoon_order_time', FILTER_SANITIZE_STRING );

		if ( $order_time && 'asap' !== $order_time ) {
			$hours       = substr( $order_time, 0, 2 );
			$minutes     = substr( $order_time, 2, 2 );
			$time_format = get_option( 'time_format' );

			$date_and_time = new DateTime( 'now', wp_timezone() );
			$date_and_time->setTimestamp( (int) $checkout_data['_reyhoon_order_timestamp']['value'] );
			$date_and_time->setTime( $hours, $minutes );

			$timestamp     = $date_and_time->getTimestamp();
			$order_time    = $date_and_time->format( $time_format );

			$checkout_data['reyhoon_order_time'] = array(
				'save'  => true,
				'value' => $order_time,
			);

			$checkout_data['_reyhoon_order_timestamp'] = array(
				'save'  => true,
				'value' => $timestamp,
			);
		}

		if ( $order_time && 'asap' === $order_time ) {
			$dates = Reyhoon_Timings::get_service_dates();

			if ( ! $dates ) {
				return;
			}

			$earliest_order_time      = array_key_first( $dates[0]['slots'] );
			$earliest_order_timestamp = array_values( $dates[0]['slots'] )[0]['timestamp'];

			$hours       = substr( $earliest_order_time, 0, 2 );
			$minutes     = substr( $earliest_order_time, 2, 2 );
			$time_format = get_option( 'time_format' );

			$date_and_time = new DateTime( 'now', wp_timezone() );
			$date_and_time->setTimestamp( (int) $earliest_order_timestamp );
			$date_and_time->setTime( $hours, $minutes );

			$timestamp           = $date_and_time->getTimestamp();
			$earliest_order_time = $date_and_time->format( $time_format );

			$checkout_data['reyhoon_order_time'] = array(
				'save'  => true,
				'value' => $earliest_order_time . esc_html__( ' (As soon as possible)', 'reyhoon-pro' ),
			);

			$checkout_data['_reyhoon_order_timestamp'] = array(
				'save'  => true,
				'value' => $timestamp,
			);
		}

		return $checkout_data;
	}
}