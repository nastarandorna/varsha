<?php
/**
 * Timings Pro settings.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

/**
 * Timings Pro settings class.
 */
class Reyhoon_Timings_Pro_Settings
{
    /**
     * Init.
     */
    public static function run()
    {
        add_filter('reyhoon_get_max_orders_field', array(__CLASS__, 'get_max_orders_field'), 10, 3);
        add_filter('reyhoon_get_uplaod_map_setting', array(__CLASS__, 'get_uplaod_map_setting'), 10, 3);
        add_filter('reyhoon_get_copyright_settings', array(__CLASS__, 'get_copyright_settings'), 10);
        add_filter('reyhoon_packing_cost', array(__CLASS__, 'reyhoon_packing_cost'), 10, 3);
        add_filter('reyhoon_get_time_slot_fields', array(__CLASS__, 'get_time_slot_fields'), 10, 3);
    }

    /**
     * Get max orders field.
     *
     * @param string $field
     * @param string $name
     * @param array $settings
     *
     * @return false|string
     */
    public static function get_max_orders_field($field, $name, $settings = array())
    {
        $max_orders = !empty($settings['max_orders']) ? $settings['max_orders'] : '';

        ob_start();
        ?>
        <strong class="reyhoon-table__rwd-labels"><?php esc_attr_e('Max Orders (Day)', 'reyhoon-pro'); ?></strong>
        <input type="number" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($max_orders); ?>">
        <?php

        return ob_get_clean();
    }

    /**
     * Get time slot fields.
     *
     * @param string $field
     * @param string $name
     * @param array $settings
     *
     * @return false|string
     */
    public static function get_time_slot_fields($field, $name, $settings = array())
    {
        ob_start();
        ?>
        <tr data-reyhoon-period="time-slots" <?php if ('all-day' === $settings['period']) {
            echo 'style="display: none;"';
        } ?>>
            <th class="reyhoon-table__column reyhoon-table__column--medium"><?php _e('Hours', 'reyhoon-pro'); ?></th>
            <td class="reyhoon-table__column reyhoon-table__column--time">
                <fieldset class="reyhoon-table__fieldset reyhoon-table__fieldset--nowrap">
                    <legend><?php _e('From:', 'reyhoon-pro'); ?></legend>
                    <?php echo Reyhoon_Timings_Settings::get_time_field($name . '[from]', $settings['from']); ?>
                </fieldset>
                <fieldset class="reyhoon-table__fieldset reyhoon-table__fieldset--nowrap">
                    <legend><?php _e('To:', 'reyhoon-pro'); ?></legend>
                    <?php echo Reyhoon_Timings_Settings::get_time_field($name . '[to]', $settings['to']); ?>
                </fieldset>
            </td>
        </tr>
        <tr data-reyhoon-period="time-slots" <?php if ('all-day' === $settings['period']) {
            echo 'style="display: none;"';
        } ?>>
            <th class="reyhoon-table__column reyhoon-table__column--medium"><?php _e('Frequency (Mins)', 'reyhoon-pro'); ?></th>
            <td>
                <input type="number" name="<?php echo esc_attr($name); ?>[frequency]"
                       value="<?php echo esc_attr($settings['frequency']); ?>"
                       placeholder="<?php esc_attr_e('Default: 30', 'reyhoon-pro'); ?>">
            </td>
        </tr>
        <tr data-reyhoon-period="time-slots" <?php if ('all-day' === $settings['period']) {
            echo 'style="display: none;"';
        } ?>>
            <th class="reyhoon-table__column reyhoon-table__column--medium"><?php _e('Cutoff (Mins)', 'reyhoon-pro'); ?></th>
            <td>
                <input type="number" name="<?php echo esc_attr($name); ?>[cutoff]"
                       value="<?php echo esc_attr($settings['cutoff']); ?>">
            </td>
        </tr>
        <tr data-reyhoon-period="time-slots" <?php if ('all-day' === $settings['period']) {
            echo 'style="display: none;"';
        } ?>>
            <th class="reyhoon-table__column reyhoon-table__column--medium"><?php _e('Max Orders (Slot)', 'reyhoon-pro'); ?></th>
            <td>
                <input type="number" name="<?php echo esc_attr($name); ?>[max_orders]"
                       value="<?php echo esc_attr($settings['max_orders']); ?>">
            </td>
        </tr>
        <?php

        return ob_get_clean();
    }

    public static function reyhoon_packing_cost()
    {
        if (!is_admin()) {
            return;
        }
        ob_start(); ?>
        <input type="text" name="reyhoon_settings[store_general_packaging_cost]" id="store_general_packaging_cost"
               value="<?= Reyhoon_Settings::get_setting('store_general_packaging_cost') ?>" placeholder=""
               class="regular-text ">
        <?php
        return ob_get_clean();

    }

    public static function get_uplaod_map_setting()
    {
        if (!is_admin()) {
            return;
        }

        ob_start(); ?>
        <div title="آپلود فایل محدوده ها" id="add-file" class="reyhoon-admin-button">
            آپلود فایل محدوده ها
        </div>
        <input id="add-file-inp" type="file" style="display:none"/>
        <div class="stages"></div>
        <script>
            jQuery(document).ready(function ($) {
                let api_key = '<?=Reyhoon_Settings::get_setting('store_general_map_api');?>';
                var stage = $('.stages');
                init_stages();
                stage.on('click', '.stage-item', function (e) {
                    let stage = $(this);
                    let stage_id = stage.data('id');
                    delete_stage(stage_id, function (calback) {

                        stage.remove();
                    })
                })

                $('#add-file').click(function () {
                    $('#add-file-inp').click();
                });

                $('#add-file-inp').change(function (evt) {
                    var fileName = evt.target.files[0].name;
                    var myfile = evt.target.files[0];
                    var formData = new FormData();
                    formData.append('polygons', myfile, fileName);
                    add_polygons(formData, function (data) {
                        if (data.error === 400) {
                            alert('فایل مورد نظر باید به فرمت geojson باشد.', 'error');
                        } else {

                            alert('محدوده ها با موفقیت اضافه شدند', 'success');
                        }
                    });
                    init_stages();
                });

                function add_polygons(formData, calback) {
                    $.ajax({
                        url: 'https://map.ir/geofence/stages/',
                        headers: {
                            'x-api-key': api_key
                        },
                        method: 'POST',
                        contentType: false,
                        processData: false,
                        data: formData,
                        statusCode: {
                            400: function () {
                                const data = {error: 400};
                                calback(data);
                            }
                        }
                    }).done(function (data) {
                        calback(data);
                    });
                }

                function load_stage(calback) {
                    $.ajax({
                        url: 'https://map.ir/geofence/stages',
                        headers: {
                            'x-api-key': api_key
                        },
                        method: 'GET',
                        statusCode: {
                            404: function () {
                                const data = {
                                    'odata.count': 0,
                                    value: []
                                };
                                calback(data);
                            },
                            401: function () {
                                const data = {error: 401};
                                calback(data);
                            }
                        }
                    }).done(function (data) {

                        calback(data);
                    });
                }

                function delete_stage(id, calback) {
                    let c = window.confirm('آیا مطمئنید که میخواهید این محدوه را حذف کنید؟');
                    if (c) {
                        $.ajax({
                            url: `https://map.ir/geofence/stages/${id}`,
                            headers: {
                                'x-api-key': api_key
                            },
                            method: 'DELETE'
                        }).done(function (data) {
                            calback(data);
                        });
                    }
                }

                function init_stages() {
                    load_stage(function (data) {

                        for (let i of data.value) {
                            stage.append('<p class="stage-item" data-id="' + i.id + '"> محدوده : ' + i.id + '<span>حذف</span></p>');
                        }
                    });
                }

            });

        </script>
        <?php
        return ob_get_clean();
    }

    public static function get_copyright_settings()
    {
        if (!is_admin()) {
            return;
        }
        $copyright = Reyhoon_Settings::get_setting('footer_footer_copyright');
        $avin = Reyhoon_Settings::get_setting('footer_footer_copyright_avin');

        ob_start(); ?>
        <div class="copyrights">
            <div class="item">
                <label for="footer_footer_copyright">متن کپی رایت</label>
                <textarea name="reyhoon_settings[footer_footer_copyright]" rows="6" id="footer_footer_copyright"
                          placeholder="html کپی رایت" class="regular-text "><?= $copyright ?: '' ?></textarea>
            </div>

            <div class="item">
                <label for="footer_footer_copyright_avin">کپی رایت آوین </label>
                <label class="switch"><input type="checkbox" name="reyhoon_settings[footer_footer_copyright_avin]" id="footer_footer_copyright_avin" class="" value="<?= $avin ?: '1' ?>" <?php checked($avin , true) ?>> <span class="slider"></span></label>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
