<?php /** @var integer $post_id */ ?>
<?php
$table_url =add_query_arg('stp',$post_id,trailingslashit(home_url()));
?>

<div class="container <?= $table_url ? "" : "hidden" ?>">
    <div class="row">
        <label for="url">لینک میز :</label>
        <input id="url" name="url" value="<?= $table_url ?>" disabled>
        <button type="button" id="copy" onclick="copyAddress()"> کپی</button>
    </div>
    <div class="row">
        <label for="qr">بارکد : <span>برای چاپ بارکد روی تصویر کلیک کنید</span></label>
        <div class="qr-container">
            <div class="actions">
                <button type="button" onclick="printQR()">چاپ</button>
                <a href="" download>دانلود</a>
            </div>
            <div id="qr"></div>
        </div>
    </div>
</div>
<style>
    .container {
        display: block;
    }

    .row {
        display: flex;
        justify-content: space-between;
        flex-direction: column;
        padding: 15px;
        position: relative;
    }

    .container label {
        font-size: 14px;
        font-weight: bold;
    }

    .container input {
        width: 50%;
        border-radius: 12px;
        height: 40px;
        border: 1px solid #ddd;
        margin: 10px;
        text-align: left;
        padding: 0 10px;
    }

    .container button {
        position: absolute;
        bottom: 25px;
        right: 26px;
        height: 40px;
        border-radius: 12px;
        padding: 0 25px;
        border: unset;
    }

    .container label span {
        font-size: 12px;
        display: block;
        font-weight: normal;
    }

    .container #qr img {
        margin: 10px;
        padding: 0 10px;
        width: 128px;
    }

    .qr-container {
        display: flex;
        margin-top: 20px;
    }
    #qr {
        box-shadow:
                0.7px 0.7px 1.8px rgba(0, 0, 0, 0.02),
                1.7px 1.7px 4.3px rgba(0, 0, 0, 0.028),
                3.1px 3.1px 8px rgba(0, 0, 0, 0.035),
                5.6px 5.6px 14.3px rgba(0, 0, 0, 0.042),
                10.4px 10.4px 26.7px rgba(0, 0, 0, 0.05),
                25px 25px 64px rgba(0, 0, 0, 0.07)
    ;
        border-radius: 18px;
        margin-right: 25px;
        padding: 10px 5px;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .actions {
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .actions button {
        position: unset;
    }

    .actions a {
        height: 40px;
        border-radius: 12px;
        padding: 0 25px;
        border: unset;
        background-color: #e9e9ed;
        line-height: 36px;
        margin-top: 5px;
        text-decoration: none;
    }
</style>
<script type="text/javascript">

    new QRCode(document.getElementById("qr"), {
        text: "<?=$table_url?>",
        width: 500,
        height: 500,
        colorDark: "#1d2327",
        colorLight: "#fff",
        correctLevel: QRCode.CorrectLevel.H
    });

    function generatePNG() {
        jQuery(document).ready(function ($) {
            var base64String = document.querySelector('#qr img').src;
            $('.actions a').attr('href', base64String);
        });
    }


    function copyAddress() {

        var copyText = document.getElementById("url");
        copyText = copyText.getAttribute('value');
        navigator.clipboard.writeText(copyText);
        alert("لینک کپی شد: " + copyText);

    }

    function printQR() {
        jQuery(document).ready(function ($) {
            $('#qr').printThis();
        });
    }

    generatePNG();

</script>
