jQuery(document).ready(function ($) {
    $('.btn-rst').on('click', function () {
        let tableId = $(this).attr('data-table');
        $.ajax({
            url: stp.ajaxurl,
            type: 'post',
            data: {
                'action': 'release_smart_table_ajax',
                'table_id': tableId,
            },
            success: function (data) {
                window.location.reload();
            },
            error: function (errorThrown) {
                console.log(errorThrown);
            }
        });
    })
});
