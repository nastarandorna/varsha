(function( $, document ) {
	"use strict";

	var reyhoon_cart_bumps = {
		/**
		 * On ready.
		 */
		on_ready: function() {
			reyhoon_cart_bumps.init_slider();
			$( document.body ).on( 'reyhoon-drawer.opened', reyhoon_cart_bumps.init_slider );
			$( document ).on( 'reyhoon-drawer.quantity-updated', reyhoon_cart_bumps.init_slider );
			$( document.body ).on( 'removed_from_cart', reyhoon_cart_bumps.init_slider );
		},

		/**
		 * Init bumps slider.
		 */
		init_slider: function() {
			$( '.reyhoon-cart-bumps' ).flexslider( {
				namespace: 'reyhoon-cart-bumps-slider-',
				selector: '.reyhoon-cart-bumps__contents > .reyhoon-cart-bumps__bump',
				animation: 'slide',
				directionNav: false,
				start: function() {
					$( window ).resize();
				}
			} );
		}
	};

	$( document ).ready( reyhoon_cart_bumps.on_ready );
}( jQuery, document ));