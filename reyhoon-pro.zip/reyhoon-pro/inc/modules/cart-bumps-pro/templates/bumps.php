<?php
/**
 * Cart Bumps: Main.
 *
 * @var $bumps WC_Product[] Bump products.
 *
 * @package Reyhoon/Templates
 */

defined( 'ABSPATH' ) || exit;
$bump_title = Reyhoon_Settings::get_setting('translate_translate_bump_title');
?>

<div class="reyhoon-cart-bumps">
	<h4 class="reyhoon-cart-bumps__heading"><?php echo $bump_title ? :__('نوشیدنی و سالاد؟','reyhoon-pro'); ?></h4>
	<div class="reyhoon-cart-bumps__contents">
		<?php foreach ( $bumps as $bump ) { ?>

			<div class="reyhoon-cart-bumps__bump">
				<div class="reyhoon-cart-bumps__bump-content">
					<?php echo wp_kses_post( $bump->get_image( 'woocommerce_thumbnail', array(
						'class' => 'reyhoon-cart-bumps__bump-image'
					) ) ); ?>
					<div class="reyhoon-cart-bumps__bump-data">
						<p class="reyhoon-cart-bumps__bump-title"><?php echo wp_kses_post( $bump->get_name() ); ?></p>
<!--						<p class="reyhoon-cart-bumps__bump-price">--><?php //echo wp_kses_post( $bump->get_price_html() ); ?><!--</p>-->
					</div>
					<?php echo Reyhoon_Products::get_add_to_cart_button( $bump, 'reyhoon-cart-bumps__bump-button reyhoon-quantity-roller__button  reyhoon-quantity-roller__button--increase' ); ?>
				</div>
			</div>
		<?php } ?>
	</div>
</div>
