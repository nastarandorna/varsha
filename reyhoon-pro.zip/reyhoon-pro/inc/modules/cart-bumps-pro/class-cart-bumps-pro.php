<?php
/**
 * Module: Cart Bumps.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Cart Bumps module class.
 */
class Reyhoon_Cart_Bumps_Pro {
	/**
	 * Init.
	 */
	public static function run() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'frontend_assets' ) );
		add_action( 'woocommerce_mini_cart_contents', array( __CLASS__, 'display_cart_bumps' ) );

		add_filter('reyhoon_add_to_cart_button_args', array(__CLASS__, 'change_add_to_cart_button_text'), 20, 2);
	}

	/**
	 * Display cart bumps.
	 */
	public static function display_cart_bumps() {
		$bumps = self::get_cart_bumps();

		if ( empty( $bumps ) ) {
			return;
		}

		include REYHOON_PRO_MODULES_PATH . 'cart-bumps-pro/templates/bumps.php';
	}

	/**
	 * Get cart bump products.
	 *
	 * @param bool $validate Ensure only valid bumps are returned.
	 *
	 * @return WC_Product[]
	 */
	public static function get_cart_bumps( $validate = true ) {
		$bumps          = array();
		$cross_sell_ids = self::get_cross_sell_ids();

		if ( ! empty( $cross_sell_ids ) ) {
			foreach ( $cross_sell_ids as $cross_sell_id ) {
				$bump = wc_get_product( $cross_sell_id );

				if ( ! $bump || ( $validate && ( ! $bump->is_purchasable() || ! $bump->is_in_stock() ) ) ) {
					continue;
				}

				// Remove variations for now.
				// @todo allow variations to be bumped.
				if ( 'variation' === $bump->get_type() ) {
					continue;
				}

				$bumps[] = $bump;
			}
		}

		$bumps = array_unique( array_filter( $bumps ) );

		return apply_filters( 'reyhoon_cart_bumps', $bumps );
	}

	/**
	 * Get cross sell IDs.
	 *
	 * @return array
	 */
	public static function get_cross_sell_ids() {
		$cross_sell_ids = array();
		$cart_items     = WC()->cart->get_cart();

		if ( ! empty( $cart_items ) ) {
			$cart_item_ids = wp_list_pluck( $cart_items, 'product_id' );

			foreach ( $cart_items as $cart_item ) {
				$product_cross_sells = $cart_item['data']->get_cross_sell_ids();

				if ( empty( $product_cross_sells ) ) {
					continue;
				}

				// Remove products already in the cart.
				$remaining_cross_sells = array_diff( $product_cross_sells, $cart_item_ids );

				// Add remaining cross sells to array.
				$cross_sell_ids = array_merge( $cross_sell_ids, $remaining_cross_sells );
			}
		}

		return apply_filters( 'reyhoon_cross_sell_ids', $cross_sell_ids );
	}

	/**
	 * Enqueue frontend assets.
	 */
	public static function frontend_assets() {
		if ( is_admin() ) {
			return;
		}

		//$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
        $suffix_css = is_rtl() ? '-rtl' : '';

		// Styles.
		wp_enqueue_style( 'reyhoon-cart-bumps-pro', REYHOON_PRO_URL . 'inc/modules/cart-bumps-pro/assets/frontend/css/cart-bumps' . $suffix_css . '.css', array(), REYHOON_PRO_VERSION );

		// Scripts.
//		wp_enqueue_script( 'flexslider' );
//		wp_enqueue_script( 'reyhoon-cart-bumps-pro', REYHOON_PRO_URL . 'inc/modules/cart-bumps-pro/assets/frontend/js/main' . $suffix . '.js', array( 'jquery', 'flexslider' ), REYHOON_PRO_VERSION, true );
	}

	public static function change_add_to_cart_button_text( $args, $product ) {

		if ($args['classes'] == 'reyhoon-cart-bumps__bump-button reyhoon-quantity-roller__button  reyhoon-quantity-roller__button--increase') {
			$args['text']    = Reyhoon_Helpers::echo_svg('plus', false);
            $args['type'] = 'bumps';
        }
		return $args;
	}
}
