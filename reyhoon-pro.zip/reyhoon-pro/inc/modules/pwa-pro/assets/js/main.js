jQuery(document).ready(function ($) {
    var deferredPrompt;
    var promptedOnce = false;
    window.addEventListener("beforeinstallprompt", (e) => {
        deferredPrompt = e;
        if(!promptedOnce) {
            e.preventDefault();

            if (!window.matchMedia("(display-mode: standalone)").matches) {
                showInAppInstallPromotion()
            }
        }

    });

    function showInAppInstallPromotion(){
        setTimeout(() => {

            if (deferredPrompt) {
                let opt = {
                    header: pwa.site_name,
                    class: 'pwa',
                    image: pwa.pwa_logo,
                    body: '<p class="pwa-title">برای دسترسی سریع تر به فروشگاه میتوانید از وب اپلیکیشن سایت استفاده کنید.برای افزوده شدن وب اپلیکیشن کافیست دکمه زیر را لمس کنید.</p>',
                };

                opt.actions = [
                    {
                        text: 'نصب وب اپلیکیشن',
                        class: 'main-action',
                        callback: function () {
                            deferredPrompt.prompt();
                            deferredPrompt.userChoice.then((choiceRes) => {
                                console.log(choiceRes.outcome);
                                if (choiceRes.outcome === "accepted") {
                                    console.log("User accepted the install prompt.");
                                } else if (choiceRes.outcome === "dismissed") {
                                    console.log("User dismissed the install prompt");
                                }
                            });
                            promptedOnce = true;
                            deferredPrompt = null;
                            $(document.body).trigger('popup-handler', {close: true});
                        }

                    },
                    {
                        text: 'متوجه شدم! فعلا نه !',
                        class: 'second-action',
                        callback: function () {
                            promptedOnce = true;
                            deferredPrompt = null;
                            $(document.body).trigger('popup-handler', {close: true});
                        }
                    }
                ];
                if (isIOS()) {
                    opt.body = '<p class="pwa-title"> <span>برای افزوده شدن وب اپلیکیشن کافیست در نوار پایین گوشی روی دکمه</span> <svg xmlns="http://www.w3.org/2000/svg" fill="#162C5B" width="44px" viewBox="0 0 50 50" enable-background="new 0 0 50 50"><path d="M30.3 13.7L25 8.4l-5.3 5.3-1.4-1.4L25 5.6l6.7 6.7z"></path><path d="M24 7h2v21h-2z"></path><path d="M35 40H15c-1.7 0-3-1.3-3-3V19c0-1.7 1.3-3 3-3h7v2h-7c-.6 0-1 .4-1 1v18c0 .6.4 1 1 1h20c.6 0 1-.4 1-1V19c0-.6-.4-1-1-1h-7v-2h7c1.7 0 3 1.3 3 3v18c0 1.7-1.3 3-3 3z"></path></svg> <span>کلیک کنید و سپس گزینه</span> <b style="margin: 0 8px">Add to Home Screen</b> <span>را انتخاب کنید.</span> </p>';
                    opt.actions = [
                        {
                            text: 'متوجه شدم! فعلا نه !',
                            class: 'second-action',
                            callback: function () {
                                promptedOnce = true;
                                deferredPrompt = null;
                                $(document.body).trigger('popup-handler', {close: true});
                            }
                        }
                    ];
                }
                $(document.body).trigger('popup-handler', [opt]);
                return false;
            }
        }, 3000);
    }

    function isIOS() {
        const userAgent = window.navigator.userAgent;
        return /iPad|iPhone|iPod/.test(userAgent) && !window.MSStream;
    }
});
