<?php
function render_offline_page(){
ob_start();?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>آفلاین</title>
    <style>

        body {
            font-family: Yekan Bakh;
            width: 100%;
            min-height: 100vh;
            display: relative;
            margin: 0;
            padding: 0;
        }
        .wrapper {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 0 46px;
        }
        h1 {
            color: var(--black, #071117);
            font-size: 24px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 0.32px;
        }
        h4 {
            color: var(--black, #071117);
            text-align: center;
            font-family: Yekan Bakh;
            font-size: 16px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 0.32px;
        }
        .button {
            text-decoration: none;
            display: block;
            margin: 20px 0 0;
            padding: 15px 30px;
            border-radius: 12px;
            color: #036666;
            border: 2px solid var(--main-color, #036666);
            height: 16px;
            width: 80%;
            max-width: 250px;
            text-align: center;
            line-height: 16px;
        }
        .button.main {
            color:#fff;
            background-color:  var(--main-color, #036666);
        }
        svg {
            max-height: 410px;
        }
    </style>
</head>
<body>
<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="auto" viewBox="0 0 345 410" fill="none">
    <mask id="mask0_3569_72" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="0" y="110" width="300" height="300">
        <rect y="110" width="300" height="300" fill="white"/>
    </mask>
    <g mask="url(#mask0_3569_72)">
        <path d="M306.828 386.298C314.064 371.979 293.384 300.384 149.999 300.384C46.5036 300.384 -0.997959 358.986 9.50368 388.685" fill="url(#paint0_radial_3569_72)"/>
        <mask id="mask1_3569_72" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="8" y="300" width="301" height="89">
            <path d="M306.828 386.298C314.064 371.979 293.384 300.384 149.999 300.384C46.5036 300.384 -0.997959 358.986 9.50368 388.685" fill="white"/>
        </mask>
        <g mask="url(#mask1_3569_72)">
            <ellipse opacity="0.671968" cx="127.886" cy="340.533" rx="7.88551" ry="4.38001" fill="url(#paint1_linear_3569_72)"/>
            <ellipse opacity="0.451707" cx="212.057" cy="351.062" rx="12.4416" ry="6.83282" fill="url(#paint2_linear_3569_72)"/>
            <ellipse opacity="0.729957" cx="66.7795" cy="315.626" rx="12.4416" ry="6.83282" fill="url(#paint3_linear_3569_72)"/>
        </g>
        <path opacity="0.716378" d="M108.765 308.646C103.93 314.118 123.065 319.174 158.269 320.361C196.605 330.805 214.026 333.639 221.068 328.24C228.11 322.842 197.88 305.997 174.214 300.674C150.547 295.352 137.546 298.801 123.036 302.626C121.072 303.144 122.046 302.748 117.589 304.244C113.132 305.741 109.941 307.315 108.765 308.646Z" fill="url(#paint4_linear_3569_72)"/>
        <path d="M160.576 277.682C160.576 277.682 145.735 294.216 154.821 304.41C143.25 305.139 135.631 310.662 135.631 310.662L129.33 287.937L160.576 277.682Z" fill="url(#paint5_linear_3569_72)"/>
        <path d="M136.09 309.424C136.09 309.424 124.54 304.494 119.924 304.486C115.307 304.478 129.589 287.209 129.589 287.209L137.934 307.842L136.09 309.424Z" fill="url(#paint6_linear_3569_72)"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M46.2031 285.474C76.3892 315.307 125.106 315.137 155.233 285.01C185.36 254.883 185.53 206.166 155.697 175.98L46.2031 285.474Z" fill="url(#paint7_linear_3569_72)"/>
        <ellipse cx="101.278" cy="231.706" rx="17.1108" ry="77.4238" transform="rotate(45 101.278 231.706)" fill="url(#paint8_linear_3569_72)"/>
        <mask id="mask2_3569_72" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="45" y="175" width="113" height="113">
            <ellipse cx="101.278" cy="231.706" rx="17.1108" ry="77.4238" transform="rotate(45 101.278 231.706)" fill="white"/>
        </mask>
        <g mask="url(#mask2_3569_72)">
            <path d="M123.574 236.631L92.1928 221.513L104.306 252.913" fill="url(#paint9_linear_3569_72)"/>
        </g>
        <ellipse cx="89.1769" cy="218.955" rx="11.0605" ry="11.0989" transform="rotate(-45 89.1769 218.955)" fill="url(#paint10_linear_3569_72)"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M54.0178 210.165C54.5597 210.166 55.0409 209.926 55.4015 209.566C55.8222 209.145 56.032 208.573 56.0009 207.941C55.6601 201.951 57.9081 196.085 62.1455 191.847C66.3227 187.67 72.1285 185.422 78.0587 185.702C79.2327 185.734 80.2547 184.833 80.2829 183.659C80.3111 182.485 79.4064 181.46 78.2324 181.428C71.1282 181.116 64.1492 183.814 59.1305 188.832C54.0518 193.911 51.3842 200.98 51.757 208.145C51.8492 209.319 52.8441 210.254 54.0178 210.165ZM67.159 214.112C67.6803 214.037 68.1357 213.837 68.4634 213.509C68.8806 213.092 69.1362 212.454 69.0513 211.773C68.6354 208.616 69.6407 205.569 71.7862 203.423C73.9018 201.308 76.8872 200.3 79.9806 200.652C81.1572 200.816 82.2064 199.958 82.2579 198.758C82.3413 197.59 81.4098 196.479 80.2035 196.346C75.842 195.858 71.6075 197.285 68.6278 200.265C65.5586 203.334 64.1337 207.63 64.7172 212.087C64.8806 213.264 65.959 214.163 67.159 214.112Z" fill="url(#paint11_linear_3569_72)"/>
        <path d="M39.0728 207.582C38.7138 207.941 38.2355 208.181 37.668 208.212C36.5032 208.244 35.5492 207.35 35.4619 206.186C35.0941 195.584 39.2055 185.213 46.7161 177.703C50.5091 173.91 54.9352 171.007 59.7585 169.102C60.1368 168.906 63.3676 168.45 63.8317 169.835C64.2957 171.221 61.2026 173.116 61.2026 173.116C56.9607 174.811 53.0663 177.374 49.7266 180.713C43.0539 187.386 39.4225 196.621 39.7327 206.088C39.7019 206.596 39.4618 207.193 39.0728 207.582Z" fill="url(#paint12_linear_3569_72)"/>
        <mask id="mask3_3569_72" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="35" y="168" width="29" height="41">
            <path d="M39.0728 207.582C38.7138 207.941 38.2355 208.181 37.668 208.212C36.5032 208.244 35.5492 207.35 35.4619 206.186C35.0941 195.584 39.2055 185.213 46.7161 177.703C50.5091 173.91 54.9352 171.007 59.7585 169.102C60.1368 168.906 63.3676 168.45 63.8317 169.835C64.2957 171.221 61.2026 173.116 61.2026 173.116C56.9607 174.811 53.0663 177.374 49.7266 180.713C43.0539 187.386 39.4225 196.621 39.7327 206.088C39.7019 206.596 39.4618 207.193 39.0728 207.582Z" fill="white"/>
        </mask>
        <g mask="url(#mask3_3569_72)">
        </g>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M80.734 163.837C80.0978 163.201 79.0664 163.201 78.4303 163.837L74.2071 168.06L69.9844 163.837C69.3482 163.201 68.3168 163.201 67.6807 163.837C67.0445 164.474 67.0445 165.505 67.6807 166.141L71.9034 170.364L67.6797 174.588C67.0435 175.224 67.0435 176.255 67.6797 176.891C68.3158 177.527 69.3472 177.527 69.9834 176.891L74.2071 172.668L78.4313 176.892C79.0674 177.528 80.0988 177.528 80.735 176.892C81.3711 176.256 81.3711 175.224 80.735 174.588L76.5108 170.364L80.734 166.141C81.3701 165.505 81.3701 164.473 80.734 163.837Z" fill="#FF1C59"/>
        <path d="M199.508 283.45C199.508 283.45 198.748 285.669 198.748 287.229C197.988 300.812 199.872 324.957 199.872 324.957H202.799L207.12 289.636L212.976 324.957H215.855C215.855 324.957 216.235 301.567 215.095 287.229C215.095 285.685 214.432 284.205 214.432 284.205L199.508 283.45Z" fill="url(#paint13_linear_3569_72)"/>
        <path d="M194.566 264.714L190.868 262.097L190.904 260.059L200.296 254.668L202.633 251.916L206.106 249.711L206.337 250.093L203.76 252.691L202.74 252.823C202.74 252.823 202.72 253.242 202.72 253.955C202.72 254.668 202.183 255.455 202.183 255.455L194.819 260.882L196.405 261.672L194.566 264.714Z" fill="#FFE9E9"/>
        <path d="M215.475 269.976L218.389 273.385L219.782 274.127L230.681 264.267L230.232 261.295L219.782 269.976L217.375 267.761L215.475 269.976Z" fill="#FFE9E9"/>
        <path d="M230.388 264.314L235.067 262.714L236.003 261.793V259.951C236.003 259.951 235.535 259.03 235.067 259.03C234.599 259.03 230.388 260.872 230.388 260.872C230.388 260.872 229.92 262.254 229.92 262.714C229.92 263.175 230.388 264.314 230.388 264.314Z" fill="#FFE9E9"/>
        <path d="M232.198 254.501H235.247C235.665 254.501 236.003 254.84 236.003 255.258V262.803C236.003 263.22 235.665 263.559 235.247 263.559H232.198C231.78 263.559 231.441 263.22 231.441 262.803V255.258C231.441 254.84 231.78 254.501 232.198 254.501Z" fill="#E9E9E9"/>
        <path d="M230.41 259.156C230.41 259.156 232.373 258.275 232.863 258.275C233.354 258.275 231.392 260.163 231.392 260.163C231.392 260.163 231.392 262.05 230.41 262.05C229.429 262.05 230.41 259.156 230.41 259.156Z" fill="#FFE9E9"/>
        <path d="M218.67 267.333L215.648 271.107L213.489 269.12C213.489 269.12 214.388 274.986 214.785 277.901C215.181 280.816 214.785 285.593 214.785 285.593C214.785 285.593 209.681 286.458 206.582 286.687C203.483 286.915 199.073 285.516 199.073 285.516C199.073 285.516 197.839 276.391 199.073 267.195L193.806 265.259L196.087 261.017C196.087 261.017 197.839 261.672 199.889 261.888C201.939 262.105 203.691 261.888 203.691 261.888L209.393 261.294C209.393 261.294 213.104 261.486 213.955 262.328C214.806 263.17 218.67 267.333 218.67 267.333Z" fill="url(#paint14_linear_3569_72)"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M208.012 257.144H204.795V261.767V261.767H204.795C204.817 261.8 206.082 263.762 206.082 264.413C206.082 265.065 207.986 261.81 208.011 261.767H208.012V261.767V257.144Z" fill="#FECECD"/>
        <ellipse cx="206.218" cy="256.433" rx="2.88999" ry="4.5" fill="#FFE9E9"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M203.046 256.933C203.277 256.075 203.277 254.183 203.74 254.122C204.202 254.06 205.127 254.418 206.052 253.723C206.514 253.342 206.745 253.294 206.745 253.102C209.057 253.559 207.675 254.936 208.826 256.454C208.946 256.612 209.289 256.454 209.289 256.454C209.289 256.454 209.289 252.718 209.057 252.384C208.826 252.051 207.901 250.709 207.439 251.666C207.439 251.187 206.514 250.693 205.589 251.06C204.665 251.427 203.277 252.145 203.046 253.102C202.815 254.06 202.584 255.975 203.046 256.933Z" fill="#513450"/>
        <path d="M200.514 324.702L199.584 325.959C199.041 326.693 198.748 327.582 198.748 328.495C198.748 328.553 198.795 328.599 198.852 328.599H203.215C203.458 328.599 203.655 328.402 203.655 328.16C203.655 327.166 203.43 326.186 202.998 325.292L202.713 324.702H200.514Z" fill="#677285"/>
        <path d="M215.574 324.702L216.504 325.959C217.047 326.693 217.34 327.582 217.34 328.495C217.34 328.553 217.293 328.599 217.236 328.599H212.873C212.63 328.599 212.433 328.402 212.433 328.16C212.433 327.166 212.658 326.186 213.09 325.292L213.375 324.702H215.574Z" fill="#677285"/>
    </g>
    <circle cx="390" cy="-74" r="253.5" fill="white" stroke="#ECECEC"/>
    <circle cx="307" cy="-108" r="253.5" stroke="#ECECEC"/>
    <defs>
        <radialGradient id="paint0_radial_3569_72" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(138.187 331.007) rotate(-90) scale(51.3403 536.198)">
            <stop stop-color="#EBEDF0" stop-opacity="0.24"/>
            <stop offset="0.536775" stop-color="#EBEDF0" stop-opacity="0.845525"/>
            <stop offset="1" stop-color="#E0E4E7" stop-opacity="0.01"/>
        </radialGradient>
        <linearGradient id="paint1_linear_3569_72" x1="121.538" y1="339.372" x2="123.941" y2="344.51" gradientUnits="userSpaceOnUse">
            <stop stop-color="#E1E7EA"/>
            <stop offset="1" stop-color="#D0D6DC"/>
        </linearGradient>
        <linearGradient id="paint2_linear_3569_72" x1="201.61" y1="350.423" x2="206.006" y2="359.593" gradientUnits="userSpaceOnUse">
            <stop stop-color="#E1E7EA"/>
            <stop offset="1" stop-color="#D0D6DC"/>
        </linearGradient>
        <linearGradient id="paint3_linear_3569_72" x1="58.8465" y1="315.736" x2="61.3338" y2="325.646" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FBFBFB"/>
            <stop offset="1" stop-color="#D9DFE3"/>
        </linearGradient>
        <linearGradient id="paint4_linear_3569_72" x1="343.483" y1="323.379" x2="338.797" y2="242.938" gradientUnits="userSpaceOnUse">
            <stop stop-color="#D5E1F0" stop-opacity="0.01"/>
            <stop offset="1" stop-color="#D9DDE2"/>
        </linearGradient>
        <linearGradient id="paint5_linear_3569_72" x1="123.431" y1="296.907" x2="149.037" y2="308.038" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F8FBFF"/>
            <stop offset="1" stop-color="#D9DDE2"/>
        </linearGradient>
        <linearGradient id="paint6_linear_3569_72" x1="125.953" y1="313.406" x2="139.891" y2="301.472" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F8FBFF"/>
            <stop offset="1" stop-color="#D9DDE2"/>
        </linearGradient>
        <linearGradient id="paint7_linear_3569_72" x1="79.3044" y1="336.896" x2="196.675" y2="252.685" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F8FBFF"/>
            <stop offset="1" stop-color="#D9DDE2"/>
        </linearGradient>
        <linearGradient id="paint8_linear_3569_72" x1="93.4968" y1="108.932" x2="24.806" y2="134.849" gradientUnits="userSpaceOnUse">
            <stop stop-color="#E6ECF3"/>
            <stop offset="1" stop-color="#D9DDE2"/>
        </linearGradient>
        <linearGradient id="paint9_linear_3569_72" x1="98.2958" y1="249.216" x2="117.221" y2="234.787" gradientUnits="userSpaceOnUse">
            <stop stop-color="white"/>
            <stop offset="1" stop-color="#CCD7E7"/>
        </linearGradient>
        <linearGradient id="paint10_linear_3569_72" x1="74.0514" y1="215.521" x2="87.6108" y2="233.164" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FDFDFD"/>
            <stop offset="1" stop-color="#D7DBE0"/>
        </linearGradient>
        <linearGradient id="paint11_linear_3569_72" x1="107.867" y1="171.008" x2="70.2227" y2="152.146" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FF1C59"/>
            <stop offset="1" stop-color="#FF1C59"/>
        </linearGradient>
        <linearGradient id="paint12_linear_3569_72" x1="92.9216" y1="151.708" x2="69.4604" y2="135.448" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FF1C59"/>
            <stop offset="1" stop-color="#FF1C59"/>
        </linearGradient>
        <linearGradient id="paint13_linear_3569_72" x1="215.885" y1="324.957" x2="215.885" y2="283.761" gradientUnits="userSpaceOnUse">
            <stop stop-color="#A1A7B8"/>
            <stop offset="1" stop-color="#7B8195"/>
        </linearGradient>
        <linearGradient id="paint14_linear_3569_72" x1="231.248" y1="272.752" x2="209.711" y2="299.69" gradientUnits="userSpaceOnUse">
            <stop stop-color="#E5E9F0"/>
            <stop offset="1" stop-color="#D2DAE8"/>
        </linearGradient>
    </defs>
</svg>
<div class="wrapper">
    <h1>ارتباط برقرار نشد :(</h1>
    <h4>لطفا اتصال به اینترنت را بررسی و مجددا تلاش کنید</h4>

    <a href="." class="button main">تلاش مجدد</a>
    <a href="tel:<?=Reyhoon_Settings::get_setting('footer_footer_phone')?>" class="button" style="direction: ltr"><?=Reyhoon_Settings::get_setting('footer_footer_phone')?></a>
</div>
</body>
</html>
<?php
    return ob_get_clean();
}
