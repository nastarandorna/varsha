//FIXME remove /reyhoon
let staticItems = [
    "/wp-content/plugins/reyhoon-pro/inc/modules/pwa-pro/sample/offline.html",
    "/wp-content/plugins/reyhoon/assets/fonts/YekanBakhRegular.woff",
    "/wp-content/plugins/reyhoon/assets/fonts/YekanBakhMedium.woff",
    "/wp-content/plugins/reyhoon/assets/fonts/YekanBakhLight.woff",
    "/wp-content/plugins/reyhoon/assets/fonts/YekanBakhBold.woff",
    "/wp-content/plugins/reyhoon/assets/frontend/js/main.js",
    "/wp-content/plugins/reyhoon/assets/frontend/css/main-rtl.css",
]

let STATIC_CACHE = "ryn-cache"

const trimCache = (chachName, max)=>{
    caches.open(chachName).then(cache=>{
        return cache.keys().then(keys=>{
            if (keys.length > max) {
                cache.delete(keys[0]).then(()=>{
                    trimCache(chachName, max);
                })
            }
        })
    })
}

// install event -------------------------------------->>
self.addEventListener("install", function(e){
    console.log('install')
    e.waitUntil(
        caches.open(STATIC_CACHE).then(cache=>{
            cache.addAll(staticItems)
        })
    )
})


// activate event ------------------------------------>>
self.addEventListener("activate", function(e){

    e.waitUntil(
        caches.keys().then(keys=>{
            return Promise.all(
                keys.map(key=>{
                    if (key != STATIC_CACHE ) {
                        console.log("Deleting Cache:", key);
                        return caches.delete(key);
                    }
                })
            )
        })
    )
    return self.clients.claim()
})
// fetch event -------------------------------------->>
self.addEventListener("fetch", function(e){

    console.log('fetch...');
    e.respondWith(
        caches.match(e.request).then(res=>{
            return res || fetch(e.request)
                .catch(err=>{
                    console.log('no internet...')
                    return caches.open(STATIC_CACHE).then(cache=>{
                        if (e.request.headers.get("accept").includes("text/html")) {
                            return cache.match("/reyhoon/wp-content/plugins/reyhoon-pro/inc/modules/pwa-pro/sample/offline.html")
                        }
                    })
                })
        })
    )


})
