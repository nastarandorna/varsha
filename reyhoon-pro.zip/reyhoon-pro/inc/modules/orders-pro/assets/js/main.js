var sidebar = new StickySidebar('.woocommerce-orders-table__row',{
    resizeSensor: true,
});
