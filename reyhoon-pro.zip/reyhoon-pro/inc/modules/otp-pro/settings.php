<?php

namespace Reyhoon\OTP;

class Settings {

	public function __construct() {
		add_filter( 'reyhoon_default_settings', array( $this, 'default_settings' ) );
		add_filter( 'wpsf_register_settings_reyhoon', array( $this, 'register_settings' ), 20 );
	}

	/**
	 * Add default settings.
	 *
	 * @param array $default_settings
	 *
	 * @return array
	 */
	public function default_settings( $default_settings = array() ) {

		return $default_settings;
	}

	/**
	 * Register settings.
	 *
	 * @param array $settings
	 *
	 * @return array
	 */
	public function register_settings( $settings = array() ) {
		$settings['tabs'][] = array(
			'id'		 => 'otp',
			'title'		 => __("Login/Register",'reyhoon-pro'),
			'priority'	 => 20,
		);

		$settings['sections'][] = array(
			'tab_id'				 => 'otp',
			'section_id'			 => 'otp',
			'section_title'			 => __("Login/Register Setting",'reyhoon-pro'),
			'section_description'	 => '',
			'section_order'			 => 0,
			'fields'				 => array(
				array(
					'id'		 => 'onboarding_login',
					'title'		 => __("If the user had not logged in, as soon as they enter the site, the login and registration form will be displayed.",'reyhoon-pro'),
					'subtitle'	 => '',
					'type'		 => 'checkbox',
					'default'	 => '',
				),
                array(
                    'id'		 => 'panel_provider',
                    'title'		 => __("SMS Panel Username",'reyhoon-pro'),
                    'type'		 => 'select',
                    'choices'  => array(
                        'melipayamak' => __( 'ملی پیامک', 'reyhoon-pro' ),
                        'farazsms' => __( 'فراز اس ام اس', 'reyhoon-pro' ),
                        'kavenegar' => __( 'کاوه نگار', 'reyhoon-pro' ),
                        'limosms' => __( 'لیمو اس ام اس', 'reyhoon-pro' ),
                        'max-sms' => __( 'اس ام اس مکث', 'reyhoon-pro' ),
                        'messageway' => __( 'راه پیام', 'reyhoon-pro' ),
                        'parsgreen' => __( 'پارس گرین', 'reyhoon-pro' ),

                    ),
                    'default'	 => 'melipayamak',
                ),
                array(
                    'id'		 => 'user_name',
                    'title'		 => __("SMS Panel Username",'reyhoon-pro'),
                    'type'		 => 'text',
                    'default'	 => '',
                ),
                array(
                    'id'		 => 'password',
                    'title'		 => __("SMS Panel Password",'reyhoon-pro'),
                    'type'		 => 'text',
                    'default'	 => '',
                ),
                array(
                    'id'		 => 'pattern_id',
                    'title'		 => __("Text Code / Pattern Code",'reyhoon-pro'),
                    'type'		 => 'text',
                    'default'	 => '',
                ),
                array(
                    'id'		 => 'apikey',
                    'title'		 => __('Api key','reyhoon-pro'),
                    'type'		 => 'text',
                    'default'	 => '',
                ),
                array(
                    'id'		 => 'sender',
                    'title'		 => __("Sender Number",'reyhoon-pro'),
                    'type'		 => 'text',
                    'default'	 => '',
                ),
				array(
					'id'		 => 'onboarding_login_text_message',
					'title'		 => __("Parameters",'reyhoon-pro'),
					'subtitle'	 => __("Wherever you have used {otp}, the activation code will be displayed.",'reyhoon-pro'),
					'type'		 => 'text',
					'default'	 => '',
					'placeholder' => __("Example: Your verification code is {otp}.",'reyhoon-pro')
				),
			),
		);

		return $settings;
	}
}
