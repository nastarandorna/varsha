<?php
$data = array(
    'username' => Reyhoon_Settings::get_setting('otp_otp_user_name'),
    'password' => Reyhoon_Settings::get_setting('otp_otp_password'),
    'text' => $code . ';',
    'to' => $mobile,
    "bodyId" => Reyhoon_Settings::get_setting('otp_otp_pattern_id'),
);
$post_data = http_build_query($data);
$handle = curl_init('https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber');
curl_setopt($handle, CURLOPT_HTTPHEADER, array(
    'content-type' => 'application/x-www-form-urlencoded'
));
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($handle, CURLOPT_POST, true);
curl_setopt($handle, CURLOPT_POSTFIELDS, $post_data);
$response = curl_exec($handle);
$response = json_decode($response);
if ($response->RetStatus == 1) {
    $response->status = true;
    return $response;
}
$response->status = false;
return $response;
