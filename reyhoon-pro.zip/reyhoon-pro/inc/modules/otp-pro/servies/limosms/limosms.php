<?php
$api_key = Reyhoon_Settings::get_setting('otp_otp_apikey');
$url = 'https://api.limosms.com/api/sendpatternmessage';
$post_data = json_encode(array(
    'OtpId' => Reyhoon_Settings::get_setting('otp_otp_pattern_id'),
    'ReplaceToken' => [$code],
    'MobileNumber' => $mobile
));
$process = curl_init();
curl_setopt($process, CURLOPT_URL, $url);
curl_setopt($process, CURLOPT_TIMEOUT, 30);
curl_setopt($process, CURLOPT_POST, 1);
curl_setopt($process, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($process, CURLOPT_POSTFIELDS, $post_data);
curl_setopt($process, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($process, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($process, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($process, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($process, CURLOPT_HTTPHEADER, array('Content-Type: application/json'
, 'ApiKey:' . $api_key));
$response = curl_exec($process);
$httpcode = curl_getinfo($process, CURLINFO_HTTP_CODE);
$response = json_decode($response);
if ($response->success == true) {
    $response->status = true;
    return $response;
}
$response->status = false;
return $response;

