<?php
// افزودن کتابخانه وب سرویس
require_once 'lib/ConnectToApi.php';
// فراخوانی فایل اطلاعات وب سرویس
$apiKey = Reyhoon_Settings::get_setting('otp_otp_apikey');
$apiMainurl = 'http://sms.parsgreen.ir';

$myApi = new ConnectToApi($apiMainurl, $apiKey);

// ارسال کد فعال سازی
// جهت ارسال کد از همین متد استفاده کنید.
// ارسال پیامک فعال سازی از این متد به نسبت ارسال پیامک عادی سرعت بالاتری دارد.

// مدل ورودی
class SendOtp_Req
{
    public $Mobile;
    public $SmsCode;
    public $TemplateId;
    public $AddName;
}
$result = new stdClass();
// تعریف مدل ورودی
$req = new SendOtp_Req();
$req->Mobile = $mobile;
$req->SmsCode = $code;     // otp code
$req->TemplateId = 0; //0-6   activeating code , verify code , login code
$req->AddName = false;      // append company name end of sms

$res = $myApi->Exec("Message/SendOtp", $req);

// print json echo json_encode($res);

// وضعیت عملیات
$result->status = $res->R_Success;
// کد خروجی در صورتی که عملیات موفق نباشد
$result->body =  $res->R_Code;
// توضیحی در مورد عملیات
$result->message = $res->R_Message;

return $result;

