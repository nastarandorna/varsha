<?php

use IPPanel\Errors\Error;
use IPPanel\Errors\HttpException;
use IPPanel\Errors\ResponseCodes;

require 'lib/autoload.php';

// you api key that generated from panel
$apiKey = Reyhoon_Settings::get_setting('otp_otp_apikey');
$client = new \IPPanel\Client($apiKey);

//Send with pattern
$args = explode(':', $code);
$patternValues = [
    $args[0] => $args[1],
];
$result = new stdClass();
try {
    $messageId = $client->sendPattern(
        Reyhoon_Settings::get_setting('otp_otp_pattern_id'),
        // pattern code
        Reyhoon_Settings::get_setting('otp_otp_sender'),
        // originator
        $mobile,
        // recipient
        $patternValues, // pattern values
    );
    $result->status = true;
    $result->body = $messageId;
    return $result;
} catch (Error $e) { // ippanel error
    $result->body = json_encode($e->unwrap()); // get real content of error
    // wp_send_json(['resault' => $result],400);
    $result->status = false;
    return $result;
} catch (HttpException $e) {
    // http error
    $result->body = $e->getMessage(); // get stringified error
    // wp_send_json(['resault' => $result],400);
    $result->status = false;
    return $result;
}
