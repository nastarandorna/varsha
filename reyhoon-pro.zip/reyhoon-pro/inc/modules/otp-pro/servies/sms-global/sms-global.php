<?php

require_once 'lib/autoload.php' ;

// get your REST API keys from MXT https://mxt.smsglobal.com/integrations
\SMSGlobal\Credentials::set('1f5da79567ef5a2d769c36e07a9296a3', 'd0ae5bc3a934a349e681e32aa4f0dbf9');

$sms = new \SMSGlobal\Resource\Sms();

try {
    $response = $sms->sendToOne('DESTINATION_NUMBER', 'This is a test message.');
    print_r($response['messages']);
} catch (\Exception $e) {
    echo $e->getMessage();
}
