<?php
require 'MessageWayAPI.php';
use MessageWay\Api\MessageWayAPI;

// Get apiKey from https://MSGWay.com/dashboard/document/
$apiKey = Reyhoon_Settings::get_setting('otp_otp_apikey');
$templateID = Reyhoon_Settings::get_setting('otp_otp_pattern_id');
$messageWay = new MessageWayAPI($apiKey);

/* Send Message by SMS */
$apiKey = Reyhoon_Settings::get_setting('otp_otp_apikey');
$messageWay = new MessageWayAPI($apiKey);
$result = new stdClass();
try {
    $otp = $messageWay->setParams([
        $code,
    ])->sendViaSMS($mobile, $templateID);
    $result->status = true;
    $result->body = $otp;
    return $result;
} catch (Exception $e) {
    $result->status = false;
    $result->body = $e;
    return $result;
}

