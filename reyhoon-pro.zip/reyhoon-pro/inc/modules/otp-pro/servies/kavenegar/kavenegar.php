<?php
$api_key = Reyhoon_Settings::get_setting('otp_otp_apikey');
$url = 'https://api.kavenegar.com/v1/' . $api_key . '/verify/lookup.json';
$url = add_query_arg(array(
    'receptor' => $mobile,
    'token' => $code,
    'template' => Reyhoon_Settings::get_setting('otp_otp_pattern_id'),
), $url);

$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_SSL_VERIFYHOST=> false,
    CURLOPT_SSL_VERIFYPEER=> false,
));



$response = curl_exec($curl);
$response = json_decode($response);
if($response->return->status == 200){
    $response->return->status = true;
    return $response->return;
}
$response->return->status = false;
return $response->return;



