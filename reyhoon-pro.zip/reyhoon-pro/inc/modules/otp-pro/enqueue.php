<?php


namespace Reyhoon\OTP;

class Enqueue
{
    public function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'loadFrontEndScript'));
    }

    public function loadFrontEndScript()
    {
        $assets = REYHOON_PRO_URL . 'inc/modules/otp-pro/assets/';
        wp_enqueue_script('input-letter', $assets . 'inputLettering.min.js', array('jquery'), false, true);

        wp_enqueue_script('ryn-otp-script', $assets . 'otp-core.js', array('jquery'), REYHOON_PRO_VERSION, true);
        wp_localize_script('ryn-otp-script', 'R_OTP_DATA', array(
            'nonce'         => wp_create_nonce('reyhoon_ajax_nonce'),
            'ajaxUrl'      => admin_url('admin-ajax.php')
        ));
        $suffix_css = is_rtl() ? '-rtl' : '';
        wp_enqueue_style('ryn-otp-style', $assets . 'otp-core' . $suffix_css . '.css', array(), '', 'all');
    }
}
