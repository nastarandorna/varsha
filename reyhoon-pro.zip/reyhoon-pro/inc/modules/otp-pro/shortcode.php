<?php


namespace Reyhoon\OTP;

class shortcode
{
    public function __construct()
    {
        add_shortcode('reyhoon_otp', array( $this, 'render_otp_form' ));
    }

    public function require_shortcode_files()
    {
        require_once(REYHOON_PRO_MODULES_PATH . '/otp-pro/template/otp-drawer.php');
    }

    public function render_otp_form()
    {
        $this->require_shortcode_files();
    }
}
