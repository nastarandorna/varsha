<?php
/**
 * Module: OTP Login
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

class Reyhoon_Otp_Pro
{
    /**
     * Init.
     */




    public static function run()
    {

        if (!is_admin() && is_user_logged_in()) {
            return;
        }

        self::load_classes();

        add_action('wp_body_open', array(__CLASS__, 'onboarding_login'));

    }

    public static function send_pattern_otp_message($mobile, $code)
    {
        $panel = Reyhoon_Settings::get_setting('otp_otp_panel_provider') ? : 'melipayamak';
        $result =  include_once 'servies/'.$panel.'/'.$panel.'.php';
        return $result;
    }

    /**
     * Load classes for this module.
     */
    public static function load_classes()
    {

        require_once REYHOON_PRO_MODULES_PATH . 'otp-pro/settings.php';
        require_once REYHOON_PRO_MODULES_PATH . 'otp-pro/enqueue.php';
        require_once REYHOON_PRO_MODULES_PATH . 'otp-pro/shortcode.php';
        require_once REYHOON_PRO_MODULES_PATH . 'otp-pro/ajax.php';

        new Reyhoon\OTP\Settings();
        new Reyhoon\OTP\Enqueue();
        new Reyhoon\OTP\shortcode();
        new Reyhoon\OTP\ajax();
    }

    public static function create_save_send_otp($mobileno)
    {
        // if phone number exist just update row
        if (self::otp_exists($mobileno)) {
            return false;
        }

        $code = self::build_random_otp();

        $text_message = Reyhoon_Settings::get_setting('otp_otp_onboarding_login_text_message');

        $message = str_replace('{otp}', $code, $text_message);

        $send_message_reusalt = self::sms_otp($mobileno, $message);


        if ($send_message_reusalt->status == false) {
            return $send_message_reusalt;
        }

        $mobileVerificationCode = md5($code);

        global $wpdb;
        $table_name = $wpdb->prefix . "reyhoon_mobile_otp";

        $db = $wpdb->replace($table_name, array(
            'mobileno' => $mobileno,
            'otp' => $mobileVerificationCode,
            'time' => date("Y-m-d H:i:s", strtotime("now"))
        ), array(
                '%s',
                '%s',
                '%s'
            )
        );
        if (!$db) {
            return false;
        }

        return $send_message_reusalt;
    }

    public static function otp_exists($phone, $resend = false)
    {
        global $wpdb;
        $phone = filter_var($phone, FILTER_SANITIZE_NUMBER_INT);
        // wp_die($phone);
        $table_name = $wpdb->prefix . "reyhoon_mobile_otp";
        $usermerow = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . $table_name . ' WHERE mobileno= %s',
                $phone
            )
        );
        if ($usermerow) {
            $time = strtotime($usermerow->time);
            $current = strtotime("now");

            $t = 10;
            if ($resend) {
                $t = 20;
            }

            $diff = $current - $time;
            if ($diff > $t || $diff < 0) {
                $wpdb->delete($table_name, array(
                    'mobileno' => $phone
                ), array(
                        '%d'
                    )
                );

                return $resend;
            }

            return true;
        } else {
            return $resend;
        }
    }

    public static function build_random_otp($isPlaceHolder = false)
    {
        $dig_otp_size = 4;
        $code = "";
        for ($i = 0; $i < $dig_otp_size; $i++) {
            if (!$isPlaceHolder) {
                $code .= rand(0, 9);
            } else {
                $code .= '-';
            }

        }

        return $code;
    }

    public static function sms_otp($mobileno, $code)
    {
        return self::send_pattern_otp_message($mobileno, $code);
    }

    public static function safe_number($number)
    {
        if (!empty($number)) {
            return preg_replace('/^09/', '9', (filter_var(esc_sql($number), FILTER_SANITIZE_NUMBER_INT)));
        } else {
            return false;
        }

    }

    public static function verifyOTP($phoneNumber, $otp)
    {
        global $wpdb;

        $otp = md5($otp);
        $table_name = $wpdb->prefix . "reyhoon_mobile_otp";
        $usermerow = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . $table_name . '
                 WHERE mobileno= %s AND otp=%s ORDER BY time DESC LIMIT 1',
                $phoneNumber, $otp
            )
        );

        if ($usermerow) {

            $time = strtotime($usermerow->time);
            $current = strtotime("now");

            if ($current - $time > 600) {
                $wpdb->delete($table_name, array(
                    'mobileno' => $phoneNumber
                ), array(
                        '%s'
                    )
                );
                // Otp don't have اعتبار
                return false;
            }
            return true;
        } else {
            return false;
        }
    }

    public static function login_user_by_phone($user_id)
    {
        wp_clear_auth_cookie();
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);
    }
    
// کد جدید اجبار لاگین فقط در صفحه اصلی
    public static function onboarding_login()
    {
        if (!is_user_logged_in() && is_front_page() && Reyhoon_Settings::get_setting('otp_otp_onboarding_login')) {
            do_shortcode('[reyhoon_otp]');
        }
    }
    /*-- کد اصلی که کاربران اگر لاگین نکرده باشند به صفحه ورود می روند در تمام صفحات
        public static function onboarding_login()
        {
            if (Reyhoon_Settings::get_setting('otp_otp_onboarding_login')) {
                do_shortcode('[reyhoon_otp]');
            }
        }
    */
    //FIXME what is this ?????
    public static function enable_otp($active)
    {
        var_dump($active);
        wp_die();
        return false;
    }
}
