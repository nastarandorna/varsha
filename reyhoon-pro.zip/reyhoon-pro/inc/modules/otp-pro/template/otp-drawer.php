<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="reyhoon-drawer-overlay reyhoon-drawer-overlay--open" data-reyhoon-trigger="drawer.close"></div>
<div class="reyhoon-drawer otp reyhoon-drawer--open">
    <div class="reyhoon-otp-header">
        <h2><?php _e("Login and Registration",'reyhoon-pro'); ?></h2>
    </div>
    <div class="reyhoon-drawer__inner">

        <div id="otp-user-name-wrapper" class="otp-user-name-wrapper">
            <h3>
                <?php _e("Enter your name:",'reyhoon-pro'); ?>
            </h3>
            <div>

                <input class="otp-user-name-input" id="otp-user-name-input" type="text" name="otp-user-name-input" lang="fa" placeholder="لطفاً فقط فارسی بنویسید" oninput="validatePersianInput(this)" style="direction: rtl;">
                <script>
                    // تابع برای جلوگیری از تایپ کاراکترهای غیر فارسی
                    function validatePersianInput(input) {
                        input.value = input.value.replace(/[^\u0600-\u06FF\s]/g, ''); // فقط حروف فارسی را می‌پذیرد
                    }

                    // تنظیم زبان صفحه کلید به صورت پیش فرض روی فارسی
                    document.getElementById("otp-user-name-input").addEventListener("focus", function() {
                        this.setAttribute("lang", "fa");
                    });
                </script>

            </div>
        </div>

        <div id="otp-phone-wrapper" class="otp-phone-wrapper">
            <h3>
                <?php _e("Enter your number:",'reyhoon-pro'); ?>
            </h3>
            <div>
                <input class="otp-phone-input" id="otp-phone-input" type="tel" name="otp-phone-input">
                <div class="otp-error" id="otp-error"></div>
                <button type="button" class="otp-btn reyhoon-send-otp" id="reyhoon-send-otp">
                    <span class="otp-btn-text"><?php _e("Send Verification Code",'reyhoon-pro'); ?></span>
                    <span class="otp-mini-loader">
                        <span class="dot1"></span>
                        <span class="dot2"></span>
                        <span class="dot3"></span>
                    </span>
                </button>
                <?php if (is_front_page()) : ?>
                    <button class="reyhoon-drawer__close register-later" data-reyhoon-trigger="drawer.close">
                        <?php _e("I will register later.",'reyhoon-pro'); ?>
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <!-- end of otp phone number input area -->

        <div id="otp-code" class="otp-code-wrapper rh-hide">
            <h3>
                <?php _e("The verification code has been successfully sent to the number below.",'reyhoon-pro'); ?>
            </h3>
            <h2>
                <button id="change-number"></button>
                <span id="user-number-text"></span>
            </h2>
            <div class="otp-phone-code-input" id="otp-phone-code-input">
                <div class="otp-form-group">
                    <input type="text" name="letters[]" class="letter inputPassCode" pattern="[0-9]*"
                           inputmode="numeric" maxlength="1">
                    <input type="text" name="letters[]" class="letter inputPassCode" pattern="[0-9]*"
                           inputmode="numeric" maxlength="1">
                    <input type="text" name="letters[]" class="letter inputPassCode" pattern="[0-9]*"
                           inputmode="numeric" maxlength="1">
                    <input type="text" name="letters[]" class="letter inputPassCode" pattern="[0-9]*"
                           inputmode="numeric" maxlength="1">
                </div>
            </div>

            <!-- id otp-verify-section used in js for code letter input  -->
            <div class="otp-verify-section" id="otp-verify-section">
                <input type="hidden" name="otp-verify-phone" class="otp-verify-phone" id="otp-verify-phone">
                <button type="button" class="code-submit otp-btn otp-verify-button" id="otp-verify-button">
                    <span class="otp-btn-text">
                        <?php _e("Confirm",'reyhoon-pro'); ?>
                    </span>
                    <span class="otp-mini-loader">
                        <span class="dot1"></span>
                        <span class="dot2"></span>
                        <span class="dot3"></span>
                    </span>
                </button>
                <div class="otp-resend-code-container">
                    <div id="otp-resend-code-timer">
                        <span><?php _e("The code was not sent to you? Resend after:",'reyhoon-pro'); ?></span>
                        <span class="countdown"></span>
                    </div>
                    <button id="otp-resend-code-btn"><?php _e("Resend Code",'reyhoon-pro'); ?></button>
                </div>
            </div>
        </div>
        <!-- end of otp code & verify area -->

        <!-- error feedback section -->
        <div id="otp-modal-error" class="otp-modal-error"></div>

        <!-- success feedback section -->
        <div id="otp-modal-success" class="otp-modal-success otp-success-feedback">
            <div class="success-check-icon">
                <span class="icon-line line-tip"></span>
                <span class="icon-line line-long"></span>
                <div class="icon-circle"></div>
                <div class="icon-fix"></div>
            </div>
            <h3>
                <?php _e("You have successfully logged in.",'reyhoon-pro'); ?>
            </h3>
        </div>
    </div>
</div>
