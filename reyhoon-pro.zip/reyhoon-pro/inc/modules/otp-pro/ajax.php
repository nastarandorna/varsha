<?php

namespace Reyhoon\OTP;

use Reyhoon_Otp_Pro;

class ajax
{
    /**
     * Action argument used by the nonce validating the AJAX request.
     *
     * @var string
     */
    const NONCE = 'reyhoon_ajax_nonce';

    /**
     * AsyncHandler constructor.
     */
    public function __construct()
    {

        add_action('wp_ajax_reyhoon_send_otp_ajax', array($this, 'send_otp'));
        add_action('wp_ajax_nopriv_reyhoon_send_otp_ajax', array($this, 'send_otp'));

        add_action('wp_ajax_reyhoon_otp_ajax', array($this, 'otp_verify_and_login'));
        add_action('wp_ajax_nopriv_reyhoon_otp_ajax', array($this, 'otp_verify_and_login'));
    }

    public function send_otp()
    {
        check_ajax_referer(self::NONCE, 'nonce');

        $safe_number = Reyhoon_Otp_Pro::safe_number($_POST['phone_number']);

        if (!$safe_number) {
            wp_send_json_error();
        }else {
            $result = Reyhoon_Otp_Pro::create_save_send_otp($safe_number);
            if ($result->status) {
                wp_send_json(
                    $result
                );
            } else {
                wp_send_json(
                    $result ,400
                );
            }
        }

        wp_die();
    }

    public function otp_verify_and_login()
    {
        check_ajax_referer(self::NONCE, 'nonce');

        $phoneNumber = Reyhoon_Otp_Pro::safe_number($_POST['phone_number']);
		//FIXME باگ: اگر کد otp اولش 09 باشه این قسمت مشکل ساز میشه
            $otp = sanitize_text_field($_POST['otp']);
		$user_name = $_POST['user_name'];

        if($phoneNumber && $otp) {
            if(!Reyhoon_Otp_Pro::verifyOTP($phoneNumber, $otp)) {
                wp_send_json_error(__("The verification code is incorrect or has expired.",'reyhoon-pro'));
            }

            $user = get_user_by('login', $phoneNumber);

            if (!empty($user)) {
                /** user available */
                Reyhoon_Otp_Pro::login_user_by_phone($user->ID);

            } else {
                // user is not available // insert user
                $userdata = array(
                    'user_login' => $phoneNumber,
                    'user_email' => $phoneNumber . '@test.com',
                    'user_pass' => null, // When creating an user, `user_pass` is expected.
                    'role' => 'customer',
	                'first_name' => $user_name,
                    'display_name' => $user_name
                );

                $user_id = wp_insert_user($userdata);

                if (!is_wp_error($user_id)) {
                    add_user_meta($user_id, 'billing_phone', sanitize_text_field($phoneNumber));
                    add_user_meta($user_id, 'billing_first_name', sanitize_text_field($user_name));
                    Reyhoon_Otp_Pro::login_user_by_phone($user_id);
                }
            }

            wp_send_json_success();

        }else {
            wp_send_json_error(__("Error in input parameters.",'reyhoon-pro'));
        }

        wp_die();
    }
}
