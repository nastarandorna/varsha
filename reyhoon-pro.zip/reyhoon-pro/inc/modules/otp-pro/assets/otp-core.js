(function ($) {
	'use strict';
	jQuery(document).ready(function ($) {
		init();
		var userPhone,userName;
		function init() {
			var otpWrapper = document.querySelector('.otp-phone-wrapper');
			if (otpWrapper) {
				inputLetteringInitialize();
				inputPassCodePaste();
				sendOtpLogin();
				OtpVerification();
				changeNumber();
				resendOtpCode();
				$( 'body' ).addClass( 'reyhoon-drawer-open' );
			}
		}

		/**
		 * Initialize input lettering
		 */
		function inputLetteringInitialize() {
			$('#otp-phone-code-input').letteringInput({
				inputClass: 'letter',
				hiddenInputWrapperID: 'otp-verify-section',
				hiddenInputName: 'otp-verify-phone',
			});
		}

		function inputPassCodePaste() {
			const $inp = $('.inputPassCode');
			$inp.on({
				paste(ev) {
					// Handle Pasting
					const clip = ev.originalEvent.clipboardData.getData('text').trim();
					// Allow numbers only
					if (!/\d{6}/.test(clip)) return ev.preventDefault(); // Invalid. Exit here
					// Split string to Array or characters
					const s = [...clip];
					// Populate inputs. Focus last input.
					$inp
						.val((i) => s[i])
						.eq(5)
						.focus();
					$inp.trigger('keydown');
				},
				input(ev) {
					// Handle typing
					const i = $inp.index(this);
					if (this.value) $inp.eq(i + 1).focus();
				},
				keydown(ev) {
					// Handle Deleting
					const i = $inp.index(this);
					if (!this.value && ev.key === 'Backspace' && i)
						$inp.eq(i - 1).focus();
				},
			});

		}

		function validPhoneNumber(phoneNumber) {
			var regex = new RegExp('(0|98|0098|98)?([ ]|-|[()]){0,2}9[0-9]([ ]|-|[()]){0,2}(?:[0-9]([ ]|-|[()]){0,2}){8}');
			var result = regex.test(phoneNumber);
			if (result == true) {
				return true;
			} else {
				return false;
			}
		}

		/**
		 * Send OTP to the phone number
		 */
		function sendOtpLogin() {
			$('#reyhoon-send-otp').click(function (e) {
				userPhone = $('#otp-phone-input').val();
				userName = $('#otp-user-name-input').val();

				if (!userPhone || !validPhoneNumber(userPhone)) {
					$('#otp-error').text('شماره موبایل وارد شده صحیح نیست.');
				}else {
					// start loader
					$('#reyhoon-send-otp').addClass('has-spinner');

					// define function here
					$.ajax({
						type: 'post',
						dataType: 'json',
						url: R_OTP_DATA.ajaxUrl,
						data: {
							action: 'reyhoon_send_otp_ajax',
							nonce: R_OTP_DATA.nonce,
							phone_number: userPhone
						},
						success: function (response) {
							$('#reyhoon-send-otp').removeClass('has-spinner');
							if(response.status) {
								$('#change-number').html('تغییر شماره');
								$('#user-number-text').html(userPhone);
								$('#otp-phone-wrapper').addClass('rh-hide');
								$('#otp-phone-wrapper').removeClass('rh-show');
								$('#otp-user-name-wrapper').addClass('rh-hide');
								$('#otp-user-name-wrapper').removeClass('rh-show');

								$('#otp-code').removeClass('rh-hide');
								$('#otp-code').addClass('rh-show');

								timer();
							}else  {
								// Error; SMS not sent
								$('#otp-error').text('ارسال پیام با شکست مواجه شد. مجدد امتحان کنید.');
							}
						},
						error: function (request, status, error) {
							$('#reyhoon-send-otp').removeClass('has-spinner');
							$('#otp-error' + ' div').html('');
							$('#otp-error').text('متاسفانه مشکلی بوجود آمده است. مجدد امتحان کنید.');
						},
					});
				}
			});
		}

		function changeNumber(){
			$('#change-number').click(function () {
				$('#otp-phone-wrapper').addClass('rh-show');
				$('#otp-phone-wrapper').removeClass('rh-hide');
				$('#otp-user-name-wrapper').addClass('rh-show');
				$('#otp-user-name-wrapper').removeClass('rh-hide');

				$('#otp-code').removeClass('rh-show');
				$('#otp-code').addClass('rh-hide');
			})
		}

		function timer(){
			var timer2 = "02:01";
			$('#otp-resend-code-timer').show();
			$('#otp-resend-code-btn').hide();
			$('#otp-resend-code-btn').prop('disabled', true);
			var interval = setInterval(function() {
				var timer = timer2.split(':');
				//by parsing integer, I avoid all extra string processing
				var minutes = parseInt(timer[0], 10);
				var seconds = parseInt(timer[1], 10);
				--seconds;
				minutes = (seconds < 0) ? --minutes : minutes;
				seconds = (seconds < 0) ? 59 : seconds;
				seconds = (seconds < 10) ? '0' + seconds : seconds;
				//minutes = (minutes < 10) ?  minutes : minutes;
				$('.countdown').html(minutes + ':' + seconds);
				if (minutes < 0) clearInterval(interval);
				//check if both minutes and seconds are 0
				if ((seconds <= 0) && (minutes <= 0)) {
					clearInterval(interval);
					$('#otp-resend-code-timer').hide();
					$('#otp-resend-code-btn').show();
					$('#otp-resend-code-btn').prop('disabled', false);
				}
				timer2 = minutes + ':' + seconds;
			}, 1000);
		}

		function resendOtpCode(){
			$('#otp-resend-code-btn').click(function (){
				$('#reyhoon-send-otp').click();
			})
		}

		/**
		 * Confirm OTP & Login
		 */
		function OtpVerification() {
			$('.otp-verify-button').click(function (e) {
				var code = $('#otp-verify-phone').val();
				code = code.toEnDigit();

				if (code) {
					// start loader
					$('#otp-verify-button').addClass('has-spinner');

					// define function here
					$.ajax({
						type: 'post',
						dataType: 'json',
						url: R_OTP_DATA.ajaxUrl,
						data: {
							action: 'reyhoon_otp_ajax',
							nonce: R_OTP_DATA.nonce,
							phone_number: userPhone,
							otp: code,
							user_name : userName,
						},
						success: function (response) {
							$('#otp-verify-button').removeClass('has-spinner');

							if(response.success) {
								$('#otp-modal-success').addClass('otp-success');
								window.location.reload();
							} else {
								$('#otp-modal-error').text(response.data);
							}

						},
						error: function (request, status, error) {
							$('#otp-modal-error').text('خطای درخواست! لطفا کمی بعد تلاش کنید.');
							$('#otp-verify-button').removeClass('has-spinner');
						},
					});

				}else {
					$('#otp-modal-error').text('ابتدا کد تایید را وارد کنید.');
				}
			});
		}
		String.prototype.toEnDigit = function() {
			return this.replace(/[\u06F0-\u06F9]+/g, function(digit) {
				var ret = '';
				for (var i = 0, len = digit.length; i < len; i++) {
					ret += String.fromCharCode(digit.charCodeAt(i) - 1728);
				}

				return ret;
			});
		};

	});
})(jQuery);
