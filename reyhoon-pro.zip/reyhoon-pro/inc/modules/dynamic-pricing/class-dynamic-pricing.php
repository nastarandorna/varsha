<?php

/**
 * Module: Dynamic Pricing.
 *
 * @package Reyhoon/Classes
 */

use Wdr\App\Models\DBTable;

defined('ABSPATH') || exit;


class Reyhoon_Dynamic_Pricing
{
    /**
     * Init.
     */
    public static function run()
    {
        add_action('reyhoon_main_before_sections', [__CLASS__, 'render_dynamic_rules']);
        add_action('wp_enqueue_scripts',[__CLASS__,'load_assets']);
    }

    public static function load_assets() {
     //   wp_enqueue_script('ryn-popup',REYHOON_PRO_URL . 'inc/modules/popup-pro/assets/js/popup.js',array(),REYHOON_PRO_VERSION );
     //  wp_enqueue_script('ryn-event',REYHOON_PRO_URL . 'inc/modules/popup-pro/assets/js/events.js',array('ryn-popup'),REYHOON_PRO_VERSION);
        wp_enqueue_style('ryn-dynamic-pricing',REYHOON_PRO_URL . 'inc/modules/dynamic-pricing/assets/css/dynamic-pricing.css',array(),REYHOON_PRO_VERSION,'all');
    }
    public static function render_dynamic_rules()
    {

        $rules = DBTable::getRules();
        ?>
        <section class="reyhoon_main__rules">
            <ul class="reyhoon-main__tabs">
                <?php
                foreach ($rules as $rule) {
                    $rule_title = $rule->title;
                    $rule_desc = json_decode($rule->advanced_discount_message)->badge_text;
                    ?>

                    <li class="reyhoon-tabs__item">
                        <p><?php echo $rule_title; ?></p>
                        <p><?php echo $rule_desc; ?></p>
                    </li>

                    <?php

                }
                ?>
            </ul>
        </section>
        <?php
    }
}
