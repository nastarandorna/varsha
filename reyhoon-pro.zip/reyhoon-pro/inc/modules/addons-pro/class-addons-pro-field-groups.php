<?php
/**
 * Module: Addons.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Addons module Field Group class.
 */
class Reyhoon_Addons_Pro_Field_Groups {
	/**
	 * Initialize.
	 */
	public static function run() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'load-post.php', array( __CLASS__, 'init_metabox' ) );
		add_action( 'load-post-new.php', array( __CLASS__, 'init_metabox' ) );
		add_action( 'save_post', array( __CLASS__, 'save_metabox' ) );
	}

	/**
	 * Register post type.
	 */
	public static function register_post_type() {
		$labels = array(
			'plural'   => __( 'Product Addons', 'reyhoon-pro' ),
			'singular' => __( 'Product Addon', 'reyhoon-pro' ),
		);

		$args = array(
			'labels'              => Reyhoon_Helpers::prepare_post_type_labels( $labels ),
			'supports'            => array( 'title' ),
			'hierarchical'        => false,
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => 'reyhoon',
			'menu_position'       => 10,
			'show_in_admin_bar'   => true,
			'show_in_nav_menus'   => true,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'capability_type'     => 'product',
		);

		register_post_type( 'reyhoon_addons', $args );
	}

	/**
	 * Initialize meta boxes.
	 */
	public static function init_metabox() {
		add_meta_box(
			'reyhoon-fields-metabox',
			__( 'Fields', 'reyhoon-pro' ),
			array( __CLASS__, 'render_fields_metabox' ),
			'reyhoon_addons',
			'advanced',
			'default'
		);

		add_meta_box(
			'reyhoon-conditions-metabox',
			__( 'Conditions', 'reyhoon-pro' ),
			array( __CLASS__, 'render_conditions_metabox' ),
			'reyhoon_addons',
			'advanced',
			'default'
		);
	}

	/**
	 * Render Fields metabox.
	 *
	 * @param WP_Post $post WP_Post object.
	 *
	 * @return void
	 */
	public static function render_fields_metabox( $post ) {
		$fields_json = self::get_group_data_json( $post->ID );

		include REYHOON_PRO_PATH . 'inc/modules/addons-pro/templates/admin/fields-metabox.php';
	}

	/**
	 * Render Conditions Metabox.
	 *
	 * @param WP_Post $post WP_Post object.
	 *
	 * @return void
	 */
	public static function render_conditions_metabox( $post ) {
		$conditions_json = self::get_group_data_json( $post->ID, 'conditions' );

		$messages = array(
			'no_condition'      => __( 'If you do not add any conditions, this field group will appear for all products.', 'reyhoon-pro' ),
			'rules_description' => __( 'Add a set of rules to determine when this field group should appear.', 'reyhoon-pro' ),
		);

		include REYHOON_PRO_PATH . 'templates/admin/conditions-metabox.php';
	}

	/**
	 * Save metabox data.
	 *
	 * @param int $post_id Post ID.
	 *
	 * @return void
	 */
	public static function save_metabox( $post_id ) {
		$fields_data = filter_input( INPUT_POST, 'reyhoon-addon-fields' );
		if ( $fields_data ) {
			// Todo security.
			$fields_data = json_decode( $fields_data, true );
			update_post_meta( $post_id, '_reyhoon_addon_fields', $fields_data );
		}

		$conditions_data = filter_input( INPUT_POST, 'reyhoon-pro-conditions' );
		if ( $conditions_data ) {
			// Todo security.
			$conditions_data = json_decode( $conditions_data, true );
			update_post_meta( $post_id, '_reyhoon_addon_conditions', $conditions_data );
		}
	}

	/**
	 * Get group data for the given group ID.
	 *
	 * @param int    $group_id Field group post ID.
	 * @param string $type     Type of data to fetch (fields|conditions)
	 *
	 * @return array
	 */
	public static function get_group_data( $group_id, $type = 'fields' ) {
		$key  = sprintf( '_reyhoon_addon_%s', $type );
		$data = get_post_meta( $group_id, $key, true );

		if ( ! empty( $data ) ) {
			$data = is_string( $data ) ? json_decode( $data, true ) : $data;
		}

		return apply_filters( 'reyhoon_get_group_data', $data, $group_id, $type );
	}

	/**
	 * Get group data json for the given group ID.
	 *
	 * @param int    $group_id Field group post ID.
	 * @param string $type     Type of data to fetch (fields|conditions)
	 *
	 * @return string
	 */
	public static function get_group_data_json( $group_id, $type = 'fields' ) {
		$data = self::get_group_data( $group_id, $type );
		$json = json_encode( $data );

		return apply_filters( 'reyhoon_get_group_data_json', $json, $group_id, $data );
	}

	/**
	 * Get data of a particular field.
	 *
	 * @param int $field_id Field ID.
	 * @param int $group_id Group ID.
	 *
	 * @return array
	 */
	public static function get_field_data( $field_id, $group_id ) {
		$fields = self::get_group_data( $group_id );

		if ( ! is_array( $fields ) ) {
			return false;
		}

		foreach ( $fields as $field ) {
			if ( $field['id'] === (int) $field_id ) {
				return $field;
			}
		}

		return false;
	}
}
