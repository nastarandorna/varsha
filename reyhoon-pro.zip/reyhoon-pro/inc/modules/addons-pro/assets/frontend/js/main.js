(function( $, document ) {
	"use strict";

	var reyhoon_addons = {
		/**
		 * On ready.
		 */
		on_ready: function () {
			reyhoon_addons.init_visual_fields();

			// Update Fees.
			$( '.reyhoon-product-fields input, .reyhoon-product-fields select' ).change( function () {
				reyhoon_addons.update_price( $( this ) );
			} );

			// Run update_price() on page load.
			$( '.reyhoon-product-fields-group' ).each( function () {
				var $input = $( this ).find( 'input,select' ).eq( 0 );
				reyhoon_addons.update_price( $input );
			} );
		},

		/**
		 * Initialise visual fields.
		 */
		init_visual_fields: function () {
			$( ".reyhoon-product-fields--visual .reyhoon-product-option" ).click( function () {
				var $input = $( this ).find( "input" );
				$input.prop( 'checked', !$input.prop( 'checked' ) );
				$input.trigger( 'change' );
			} );

			$( ".reyhoon-product-option__hidden-field" ).change( reyhoon_addons.select_deselect_visual_field );
			
			$( ".reyhoon-product-option__hidden-field" ).each( function() {
				reyhoon_addons.select_deselect_visual_field( this );
			} );
		},

		/**
		 * Select/Deselect visual fields.
		 *
		 * @param Element _this (Optional) HTML DOM element for checkbox or 
		 * radio input which was changed. If not passed, will get from $(this).
		 */
		select_deselect_visual_field: function ( _this ) {
			var this_field = _this instanceof Element ? $( _this ) : $( this );
			var $field_parent = this_field.closest( '.reyhoon-product-fields__field' );
			
			if ( ! $field_parent ) {
				return;
			}

			$field_parent.find( ".reyhoon-product-option" ).each( function () {
				var $option = $( this );
				var $input  = $option.find( ".reyhoon-product-option__hidden-field" );
				if ( $input.is( ":checked" ) ) {
					$option.addClass( 'reyhoon-product-option--checked' );
				} else {
					$option.removeClass( 'reyhoon-product-option--checked' );
				}

			} );
		},

		/**
		 * Update Price when a field is changed.
		 *
		 * @param {jQuery Object} $field jQuery instance of the Field which was changed.
		 */
		update_price: function ( $field ) {
			var $field_group = $field.closest( '.reyhoon-product-fields-group' ),
				$product = $field.closest( '.reyhoon-product, .product' ),
				$price = $product.find( '.reyhoon-product__actions-price, p.price' ),
				price = parseFloat( $field_group.data( 'price' ) ),
				regular_price = parseFloat( $field_group.data( 'regular-price' ) ),
				fees = reyhoon_addons.calculate_price( $field_group ),
				is_sale = price !== regular_price,
				new_sale_price = price + fees;

			price = accounting.formatMoney( new_sale_price, {
				symbol: '<span class="woocommerce-Price-currencySymbol">' + reyhoon_addons_pro_params.currency.format_symbol + '</span>',
				decimal: reyhoon_addons_pro_params.currency.format_decimal_sep,
				thousand: reyhoon_addons_pro_params.currency.format_thousand_sep,
				precision: reyhoon_addons_pro_params.currency.format_num_decimals,
				format: reyhoon_addons_pro_params.currency.format
			} );
			
			if ( is_sale ) {
				var new_regular_price = fees + regular_price;

				new_regular_price = accounting.formatMoney( new_regular_price, {
					symbol: '<span class="woocommerce-Price-currencySymbol">' + reyhoon_addons_pro_params.currency.format_symbol + '</span>',
					decimal: reyhoon_addons_pro_params.currency.format_decimal_sep,
					thousand: reyhoon_addons_pro_params.currency.format_thousand_sep,
					precision: reyhoon_addons_pro_params.currency.format_num_decimals,
					format: reyhoon_addons_pro_params.currency.format
				} );

				$price.find( 'del bdi' ).replaceWith( '<bdi>' + new_regular_price + '</bdi>' );
				$price.find( 'ins bdi' ).replaceWith( '<bdi>' + price + '</bdi>' );
			} else {
				$price.find( 'bdi' ).replaceWith( '<bdi>' + price + '</bdi>' );
			}
		},

		/**
		 * Calculate fees/price as per selected addons.
		 *
		 * @param {jQuery Object} $field_group jQuery Instance of '.reyhoon-product-fields-group'
		 * We pass this argument so we can handle conditions where we have multilpe field groups 
		 * on a same page. Example: Bundled products plugin.
		 */
		calculate_price: function ( $field_group ) {
			var fees_sum = 0;

			// Loop through all the field.
			$field_group.find( '.reyhoon-product-fields' ).each( function () {
				// Loop through all the options in field.
				$( this ).find( "[data-product-option]" ).each( function () {
					var $option = $( this );
					// Add fees to the sum if option is selected.
					if ( reyhoon_addons.is_option_selected( $option ) ) {
						var this_fees = $( this ).data( 'fees' );
						if ( this_fees && ! isNaN( this_fees ) ) {
							fees_sum += parseFloat( this_fees );
						}
					}
				} );
			} );

			return fees_sum;
		},

		/**
		 * Is option selected?
		 *
		 * @param {jQuery Object} $option Option can be <option> or .reyhoon-product-option
		 */
		is_option_selected: function ( $option ) {
			if ( !$option ) {
				return false;
			}

			if ( $option.is( 'div' ) ) {
				return $option.hasClass( 'reyhoon-product-option--checked' );
			}
			else if ( $option.is( 'option' ) ) {
				return $option.is( ':selected' );
			}
		}

	};

	/**
	 * Field validation related functions.
	 */
	var field_validator = {
		/**
		 * On ready.
		 */
		on_ready: function () {
			var debounced_validate = field_validator.debounce( field_validator.validate, 300 );
			$( '.reyhoon-product-fields input, .reyhoon-product-fields select, .reyhoon-product-fields textarea' ).change( debounced_validate );
			$( '.reyhoon-product-fields input, .reyhoon-product-fields select, .reyhoon-product-fields textarea' ).keyup( debounced_validate );
			field_validator.validate();
		},

		/**
		 * Run validation.
		 */
		validate: function () {
			$( '.reyhoon-product-fields--required' ).each( function () {
				var $field_wrap = $( this ).hasClass( 'reyhoon-product-fields--visual' ) ? $( this ) : $( this ).find( 'select, input, textarea' );
				if ( !field_validator.validate_field( $( this ) ) ) {
					$field_wrap.addClass( 'reyhoon-field--invalid' );
				} else {
					$field_wrap.removeClass( 'reyhoon-field--invalid' );
				}
			} );
		},

		/**
		 * Check if the field is valid.
		 *
		 * @param {jQuery Object} $field_wrap jQuery Instance of .reyhoon-product-fields
		 */
		 validate_field: function ( $field_wrap ) {
			// If field is not 'required' then return true.
			if ( !$field_wrap.hasClass( 'reyhoon-product-fields--required' ) ) {
				return true;
			}
			
			if ( $field_wrap.hasClass( 'reyhoon-product-fields--visual_radio' ) || $field_wrap.hasClass( 'reyhoon-product-fields--visual_checkbox' ) ) {
				// If there is one checked input then this field is fine, else return false.
				return $field_wrap.find( 'input:checked' ).length;
			}

			if ( $field_wrap.hasClass( 'reyhoon-product-fields--select' ) ) {
				return '' === $field_wrap.find( 'select' ).val() ? false : true;
			}

			if ( $field_wrap.hasClass( 'reyhoon-product-fields--select' ) || $field_wrap.hasClass( 'reyhoon-product-fields--text' ) ) {
				return '' === $field_wrap.find( 'select, input, textarea' ).val() ? false : true;
			}
		},

		/**
		 * Debounce function.
		 *
		 * @param function func Function to debounce.
		 * @param int wait Time to wait in milliseconds. 
		 * @param boolean immediate Trigger the function on the leading edge, instead of the trailing. 
		 * @returns 
		 */
		debounce: function( func, wait, immediate ) {
			var timeout;
			return function() {
				var context = this, args = arguments;
				var later = function() {
					timeout = null;
					if (!immediate) func.apply(context, args);
				};
				var callNow = immediate && !timeout;
				clearTimeout(timeout);
				timeout = setTimeout(later, wait);
				if (callNow) func.apply(context, args);
			};
		},
		 
	};

	$( document.body ).on( 'reyhoon-drawer.opened', reyhoon_addons.on_ready );
	$( document.body ).on( 'reyhoon-drawer.opened', field_validator.on_ready );
	$( document ).ready( reyhoon_addons.on_ready );
	$( document ).ready( field_validator.on_ready );
}( jQuery, document ));