<?php
/**
 * Module: Addons.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Addons module Field Group class.
 */
class Reyhoon_Addons_Pro_Fields {
	/**
	 * Initialize.
	 */
	public static function run() {
		add_action( 'init', array( __CLASS__, 'hooks' ) );
		add_filter( 'woocommerce_add_cart_item_data', array( __CLASS__, 'save_fields_data_to_order_item_data' ), 10, 2 );
		add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'display_field_value_on_cart' ), 10, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'add_order_line_item_meta' ), 10, 4 );
	}

	/**
	 * Hooks.
	 */
	public static function hooks() {
		add_action( 'woocommerce_before_add_to_cart_button', array( __CLASS__, 'show_product_fields' ) );
		add_action( 'reyhoon_side_menu_before_product_options', array( __CLASS__, 'show_product_fields' ) );
		add_filter( 'reyhoon_add_to_cart_button_args', array( __CLASS__, 'maybe_modify_add_to_cart_args' ), 10, 2 );
	}

	/**
	 * Display fields.
	 */
	public static function show_product_fields( $product = false ) {
		if ( empty( $product ) ) {
			global $product;
		}

		$group_ids = Reyhoon_Pro_Conditions_Matcher::get_applicable_cpt( 'reyhoon_addons', $product );

		foreach ( $group_ids as $group_id ) {
			?>
			<div class="reyhoon-product-fields-group reyhoon-product__options" data-product-id="<?php echo esc_attr( $product->get_ID() ); ?>" data-price="<?php echo esc_attr( $product->get_price() ); ?>" data-regular-price="<?php echo esc_attr( $product->get_regular_price() ); ?>">
				<?php
				$fields = Reyhoon_Addons_Pro_Field_Groups::get_group_data( $group_id );

				foreach ( $fields as $field ) {
					$is_visual      = ( 'visual_radio' === $field['type'] || 'visual_checkbox' === $field['type'] ) ? true : false;
					$visual_class   = $is_visual ? 'reyhoon-product-fields--visual' : '';
					$required_class = $field['required'] ? 'reyhoon-product-fields--required' : '';

					echo sprintf( '<div class="reyhoon-product-fields reyhoon-product-fields--%s %s %s" data-field-name="%s">', esc_attr( $field['type'] ), esc_attr( $visual_class ), esc_attr( $required_class ), esc_attr( $field['title'] ) );

					switch ( $field['type'] ) {
						case 'select':
							self::generate_field_select( $field, $group_id );
							break;
						case 'visual_checkbox':
						case 'visual_radio':
							self::generate_field_visual( $field, $group_id );
							break;
						case 'text':
							self::generate_field_text( $field, $group_id );
							break;
					}

					echo '</div>'; // .reyhoon-product-fields
				}
				?>
			</div>
			<?php
		}
	}

	/**
	 * Undocumented function
	 *
	 * @param array      $args
	 * @param WC_Product $product
	 *
	 * @return array
	 */
	public static function maybe_modify_add_to_cart_args( $args, $product ) {
		$group_ids = Reyhoon_Pro_Conditions_Matcher::get_applicable_cpt( 'reyhoon_addons', $product );

		if ( empty( $group_ids ) ) {
			return $args;
		}

		global $reyhoon_single_product;

		$args['trigger'] = 'product-options';
		$args['text']    = empty( $reyhoon_single_product ) ? __( 'Select', 'reyhoon-pro' ) : __( 'Add', 'reyhoon-pro' );

		return $args;
	}

	/**
	 * Save Fields data to WC order item data.
	 *
	 * @return array
	 */
	public static function save_fields_data_to_order_item_data( $item_data, $cart_item ) {
		$posted_field_group = filter_input( INPUT_POST, 'reyhoon_fields', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );

		if ( empty( $posted_field_group ) ) {
			return $item_data;
		}

		$reyhoon_item_data = array();
		foreach ( $posted_field_group as $group_id => $posted_fields ) {
			foreach ( $posted_fields as $field_id => $posted_field ) {
				$field_setting = Reyhoon_Addons_Pro_Field_Groups::get_field_data( $field_id, $group_id );
				$fees          = Reyhoon_Addons_Pro_Fees::calculate_fees( $posted_field, $field_id, $group_id );

				$reyhoon_item_data[ $field_id ] = array(
					'id'       => $field_id,
					'value'    => $posted_field,
					'label'    => $field_setting['title'],
					'group_id' => $group_id,
					'fees'     => $fees,
				);
			}
		}

		$item_data['reyhoon_fields'] = $reyhoon_item_data;

		return $item_data;
	}

	/**
	 * Add fields data to item data so it can appear in cart.
	 *
	 * @param array $item_data Item data.
	 * @param array $cart_item Cart Item.
	 *
	 * @return array
	 */
	public static function display_field_value_on_cart( $item_data, $cart_item ) {
		if ( empty( $cart_item['reyhoon_fields'] ) ) {
			return $item_data;
		}

		foreach ( $cart_item['reyhoon_fields'] as $field ) {
			if ( empty( $field['value'] ) ) {
				continue;
			}

			$value = is_array( $field['value'] ) ? implode( ', ', $field['value'] ) : $field['value'];

			if ( $field['fees'] ) {
				$value = sprintf( '%s (%s)', $value, wc_price( $field['fees'] ) );
			}

			$item_data[] = array(
				'key'   => $field['label'],
				'value' => $value,
			);
		}

		return $item_data;
	}

	/**
	 * Add fields data to order line item meta
	 * so it can appear in order completion page
	 * and admin order edit page.
	 *
	 * @param object $item          Order line item object.
	 * @param string $cart_item_key Cart item key.
	 * @param array  $values        Cart data.
	 * @param object $order         Order object.
	 */
	public static function add_order_line_item_meta( $item, $cart_item_key, $values, $order ) {
		if ( empty( $values['reyhoon_fields'] ) ) {
			return $item;
		}

		foreach ( $values['reyhoon_fields'] as $field ) {
			$value = is_array( $field['value'] ) ? implode( ', ', $field['value'] ) : $field['value'];
			$item->add_meta_data( $field['label'], $value );
		}
	}

	/**
	 * Generate Select field.
	 *
	 * @param array $field    Field's data.
	 * @param int   $group_id Field Group's post ID.
	 */
	public static function generate_field_select( $field, $group_id ) {
		$name     = sprintf( 'reyhoon_fields[%s][%s]', $group_id, $field['id'] );
		$required = $field['required'] ? 'required' : '';
		?>
		<h4 class="reyhoon-product-fields__title"><?php echo esc_html( $field['title'] ); ?></h4>
		<div class="reyhoon-product-fields__field">
			<select name="<?php echo esc_attr( $name ); ?>" class="reyhoon-input reyhoon-input--addon reyhoon-input--select" <?php echo esc_attr( $required ); ?>>
				<?php
				foreach ( $field['options'] as $option ) {
					$label = $option['label'];

					if ( ! empty( $option['price'] ) ) {
						$label .= sprintf( ' (+%s)', wp_strip_all_tags( wc_price( $option['price'] ) ) );
					}
					?>
					<option data-product-option data-fees="<?php echo esc_attr( $option['price'] ); ?>" value="<?php echo esc_attr( $option['label'] ); ?>" <?php selected( "1", $option['selected'] ); ?>>
						<?php echo esc_html( apply_filters( 'reyhoon_product_addon_select_label', $label, $option, $field, $group_id ) ); ?>
					</option>
					<?php
				}
				?>
			</select>
		</div>
		<?php
	}

	/**
	 * Generate Select field.
	 *
	 * @param array $field Field's data.
	 */
	public static function generate_field_visual( $field, $group_id ) {
		$type = 'visual_checkbox' === $field['type'] ? 'checkbox' : 'radio';
		$name = sprintf( 'reyhoon_fields[%s][%s]', $group_id, $field['id'] );

		if ( 'visual_checkbox' === $field['type'] ) {
			$name .= '[]';
		}
		?>
		<h4 class="reyhoon-product-fields__title"><?php echo esc_html( $field['title'] ); ?></h4>
		<div class="reyhoon-product-fields__field reyhoon-product-fields__field--<?php echo esc_attr( $field['type'] ); ?>">
			<?php
			foreach ( $field['options'] as $option ) {
				?>
				<div class="reyhoon-product-option reyhoon-product-option--visual reyhoon-product-option--<?php echo esc_attr( $option['visual_type'] ); ?>" data-product-option data-fees="<?php echo esc_attr( $option['price'] ); ?>">
					<?php self::generate_visual_option( $option ); ?>
					<div class="reyhoon-product-option__label">
						<input
							type="<?php echo esc_attr( $type ); ?>"
							class="reyhoon-product-option__hidden-field reyhoon-input--addon"
							name='<?php echo esc_attr( $name ); ?>'
							value="<?php echo esc_attr( $option['label'] ); ?>"
							id='reyhoon_field_<?php echo esc_attr( $option['id'] ); ?>'
							<?php checked( '1', $option['selected'] ); ?>
						/>
                        <div class="reyhoon-product-option__state-lable-container">
                            <span class="reyhoon-product-option__label-state"></span>
                            <span class="reyhoon-product-option__label-text"><?php echo esc_html( $option['label'] ); ?></span>
                        </div>
						<span class="reyhoon-product-option__label-data">
							<?php if ( ! empty( $option['price'] ) ) { ?>
								<span class="reyhoon-product-option__label-fee"><?php echo wc_price( $option['price'] ); ?></span>
							<?php } ?>
						</span>
					</div>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	}

	/**
	 * Generate text field.
	 *
	 * @param array $field Field Data.
	 * @param int   $group_id Group ID.
	 */
	public static function generate_field_text( $field, $group_id ) {
		$name     = sprintf( 'reyhoon_fields[%s][%s]', $group_id, $field['id'] );
		$required = $field['required'] ? 'required' : '';

		?>
		<h4 class="reyhoon-product-fields__title"><?php echo esc_html( $field['title'] ); ?></h4>
		<div class="reyhoon-product-fields__field reyhoon-product-fields__field--<?php echo esc_attr( $field['type'] ); ?>">
			<?php

			if ( $field['is_multiline'] ) {
				echo sprintf( '<textarea %s class="reyhoon-input reyhoon-input--addon field reyhoon-input--text" name="%s" placeholder="%s">%s</textarea>', esc_attr( $required ), esc_attr( $name ), esc_attr( $field['placeholder'] ), esc_attr( $field['default'] ) );
			} else {
				echo sprintf( '<input %s type="text" class="reyhoon-input reyhoon-input--addon reyhoon-input--text" name="%s" placeholder="%s" value="%s" />', esc_attr( $required ), esc_attr( $name ), esc_attr( $field['placeholder'] ), esc_attr( $field['default'] ) );
			}
			?>
		</div>
		<?php
	}

	/**
	 * Generate visual part: Image or Color or an option in Chekbox or Radio field.
	 *
	 * @param array $option Option data.
	 *
	 * @return void
	 */
	public static function generate_visual_option( $option ) {
		if ( 'none' === $option['visual_type'] || ( empty( $option['color'] ) && empty( $option['image'] ) ) ) {
			return;
		}
		?>
		<div class="reyhoon-product-option__swatch">
			<?php if ( 'color' === $option['visual_type'] && $option['color'] ) { ?>
				<div class="reyhoon-product-option__swatch-graphic reyhoon-product-option__swatch-graphic--color" style="background-color:<?php echo esc_attr( $option['color'] ); ?>"></div>
			<?php } elseif ( 'image' === $option['visual_type'] && $option['image'] ) {
				echo wp_get_attachment_image( $option['image']['id'], 'thumbnail', false, array(
					'class' => 'reyhoon-product-option__swatch-graphic reyhoon-product-option__swatch-graphic--image',
				) );
			} ?>
		</div>
		<?php
	}
}
