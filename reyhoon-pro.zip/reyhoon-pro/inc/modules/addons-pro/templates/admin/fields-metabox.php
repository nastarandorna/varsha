<div id="reyhoon-fields-app" data-fields="<?php echo wc_esc_json( $fields_json ); ?>" v-cloak>
	<div v-if="fields.length" class="reyhoon-addon-fields reyhoon-addon-fields--have-fields">
		<draggable v-model="fields" @start="drag=true" @end="drag=false" handle=".reyhoon-fields-row__header-drag">
			<div :class="{ 'reyhoon-fields-row': true, 'reyhoon-fields-row--open': field.open }" v-for="( field, index ) in fields">

				<!-- Header Starts -->
				<div class="reyhoon-fields-row__header">
					<span class="reyhoon-fields-row__header-drag dashicons dashicons-menu reyhoon-dashicons reyhoon-dashicons--menu"></span>
					<div class="reyhoon-fields-row__header-title" @click="field.open = ! field.open">
						<h3>{{field.title}}</h3>
						<div class="reyhoon-fields-row__header-title-sub">
							<span>ID: {{field.id}}</span>
						</div>
					</div>
					<div class="reyhoon-fields-row__header-action">
						<span class="dashicons dashicons-admin-page reyhoon-dashicons reyhoon-dashicons--admin-page" @click='duplicateField( index, field )'></span>
						<span class="dashicons dashicons-trash reyhoon-dashicons reyhoon-dashicons--trash" @click='deleteField( index )'></span>
					</div>
				</div>
				<!-- Header ends -->

				<!-- Body starts -->
				<div class="reyhoon-fields-row__body">
					<div class="reyhoon-fields-row__body-row">
						<div class="reyhoon-fields-row__body-row-left">
							<h3><?php esc_html_e( 'Type', 'reyhoon-pro' ); ?></h3>
							<p><?php esc_html_e( 'What type of field should this be?', 'reyhoon-pro' ); ?></p>
						</div>
						<div class="reyhoon-fields-row__body-row-right">
							<select v-model='field.type'>
								<option value="text"><?php esc_html_e( 'Text', 'reyhoon-pro' ); ?></option>
								<option value="select"><?php esc_html_e( 'Dropdown', 'reyhoon-pro' ); ?></option>
								<option value="visual_checkbox"><?php esc_html_e( 'Checkbox', 'reyhoon-pro' ); ?></option>
								<option value="visual_radio"><?php esc_html_e( 'Radio', 'reyhoon-pro' ); ?></option>
							</select>
						</div>
					</div>

					<!-- Title row -->
					<div class="reyhoon-fields-row__body-row">
						<div class="reyhoon-fields-row__body-row-left">
							<h3><?php esc_html_e( 'Title/Label', 'reyhoon-pro' ); ?></h3>
							<p><?php esc_html_e( 'The front-facing title/label for the field.', 'reyhoon-pro' ); ?></p>
						</div>
						<div class="reyhoon-fields-row__body-row-right">
							<input type="text" v-model="field.title">
						</div>
					</div>

					<!-- Description Row -->
					<div class="reyhoon-fields-row__body-row">
						<div class="reyhoon-fields-row__body-row-left">
							<h3><?php esc_html_e( 'Description', 'reyhoon-pro' ); ?></h3>
							<p><?php esc_html_e( 'The front-facing description of this field.', 'reyhoon-pro' ); ?></p>
						</div>
						<div class="reyhoon-fields-row__body-row-right">
							<textarea type="text" v-model="field.description"></textarea>
						</div>
					</div>

					<!-- Required row -->
					<div class="reyhoon-fields-row__body-row">
						<div class="reyhoon-fields-row__body-row-left">
							<h3><?php esc_html_e( 'Required', 'reyhoon-pro' ); ?></h3>
							<p><?php esc_html_e( 'Is this field required?', 'reyhoon-pro' ); ?></p>
						</div>
						<div class="reyhoon-fields-row__body-row-right">
							<input type='checkbox' v-model="field.required"></input>
						</div>
					</div>

					<!-- Options row -->
					<div class="reyhoon-fields-row__body-row" v-if='field.type !== "text"'>
						<div class="reyhoon-fields-row__body-row-left">
							<h3><?php esc_html_e( 'Options', 'reyhoon-pro' ); ?></h3>
							<p><?php esc_html_e( 'Enter the options for the field. Add new options by clicking "Add Option".', 'reyhoon-pro' ); ?></p>
						</div>
						<div class="reyhoon-fields-row__body-row-right">
							<?php 
								require REYHOON_PRO_PATH . 'inc/modules/addons-pro/templates/admin/fields-options.php';
							?>
						</div>
					</div>

					<div class="reyhoon-fields-row__body-row" v-if='field.type === "text"'>
						<div class="reyhoon-fields-row__body-row-left">
							<h3><?php esc_html_e( 'Multi-Line', 'reyhoon-pro' ); ?></h3>
							<p><?php esc_html_e( 'Enable to allow the user to enter multiple lines of text.', 'reyhoon-pro' ); ?></p>
						</div>
						<div class="reyhoon-fields-row__body-row-right">
							<input type='checkbox' v-model="field.is_multiline"></input>
						</div>
					</div>

					<div class="reyhoon-fields-row__body-row" v-if='field.type === "text"'>
						<div class="reyhoon-fields-row__body-row-left">
							<h3><?php esc_html_e( 'Placeholder', 'reyhoon-pro' ); ?></h3>
							<p><?php esc_html_e( 'Placeholder for the field.', 'reyhoon-pro' ); ?></p>
						</div>
						<div class="reyhoon-fields-row__body-row-right">
							<input type='text' v-model="field.placeholder"></input>
						</div>
					</div>

					<div class="reyhoon-fields-row__body-row" v-if='field.type === "text"'>
						<div class="reyhoon-fields-row__body-row-left">
							<h3><?php esc_html_e( 'Default value', 'reyhoon-pro' ); ?></h3>
							<p><?php esc_html_e( 'Default value for the field.', 'reyhoon-pro' ); ?></p>
						</div>
						<div class="reyhoon-fields-row__body-row-right">
							<input type='text' v-model="field.default"></input>
						</div>
					</div>
				</div>
				<!-- Body ends -->
			</div> <!-- .reyhoon-fields-row -->
		</draggable>

		<button type="button" class="reyhoon-admin-button" @click.prevent="newField()"><?php esc_html_e( 'Add Field', 'reyhoon-pro' ); ?></button>
	</div> <!-- .reyhoon-fields__have-fields -->

	<div v-else class="reyhoon-addon-fields reyhoon-addon-fields--no-fields">
		<button type="button" class="reyhoon-admin-button" @click.prevent="newField()"><?php esc_html_e( 'Add Your First Field', 'reyhoon-pro' ); ?></button>
		<p><?php esc_html_e( 'Start adding product addon fields for your products.', 'reyhoon-pro' ); ?></p>
	</div>

	<input type="hidden" v-model='fieldsJson' name='reyhoon-addon-fields' />
</div> <!-- app -->
