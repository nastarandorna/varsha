<div class="reyhoon-fields-options">
	<div class="reyhoon-fields-options__body">
		<draggable v-model="field.options" handle=".reyhoon-fields-options__row-handle">
			<div class="reyhoon-fields-options__row" v-for="( option, optionIndex ) in field.options" :class="'select' === field.type && 'reyhoon-fields-options__grid--select'">
				<div class="reyhoon-fields-options__row-drag">
					<span class="reyhoon-fields-options__row-handle dashicons dashicons-menu reyhoon-dashicons reyhoon-dashicons--menu"></span>
				</div>
				<div class="reyhoon-fields-options__row-fields">

					<div class="reyhoon-fields-options__row-fields-row">
						<div class="reyhoon-fields-options__row-field reyhoon-fields-options__row-label" :class="'select' === field.type && 'reyhoon-fields-options__row-field--full'">
							<label for="" class="reyhoon-fields-options__row-field-label"><?php esc_html_e( 'Label', 'reyhoon-pro' ); ?></label>
							<input type="text" v-model='option.label'>
						</div>
						<div class="reyhoon-fields-options__row-field reyhoon-fields-options__row-field--visual" v-show="'select' != field.type">
							<div class="reyhoon-fields-options__row-type">
								<label for="" class="reyhoon-fields-options__row-field-label"><?php esc_html_e( 'Visual', 'reyhoon-pro' ); ?></label>
								<select v-model='option.visual_type'>
									<option value="none"><?php esc_html_e( 'None', 'reyhoon-pro' ); ?></option>
									<option value="image"><?php esc_html_e( 'Image', 'reyhoon-pro' ); ?></option>
									<option value="color"><?php esc_html_e( 'Color', 'reyhoon-pro' ); ?></option>
								</select>
							</div>
							<div class="reyhoon-fields-options__row-visual" v-show="'select' != field.type">
								<div class='reyhoon-fields-options__row-visual-image' v-if='"image" === option.visual_type'>
									<div class="reyhoon-fields-option-img">
										<div v-if="option.image" class="reyhoon-fields-option-img__img-wrapper">
											<img class="reyhoon-fields-option-img__img" :src="option.image.thumbnail">
											<span class="dashicons dashicons-trash reyhoon-dashicons reyhoon-dashicons--trash reyhoon-fields-option-img__delete" @click="removeImage(option)"></span>
										</div>
										<span v-else class="dashicons dashicons-format-image reyhoon-dashicons reyhoon-dashicons--format-image reyhoon-fields-option-img__dummy" @click='addImage(option)'></span>
									</div>
								</div>
								<div class='reyhoon-fields-options__row-visual-color' v-else-if='"color" === option.visual_type'>
									<input class="reyhoon-fields-option-color" type="color" v-model='option.color' />
								</div>
								<div class='reyhoon-fields-options__row-visual-color' v-else>
									<span class="reyhoon-fields-option__empty"></span>
								</div>
							</div>
						</div>
					</div>

					<div class="reyhoon-fields-options__row-fields-row">
						<div class="reyhoon-fields-options__row-field reyhoon-fields-options__row-price">
							<label for="" class="reyhoon-fields-options__row-field-label"><?php esc_html_e( 'Price', 'reyhoon-pro' ); ?></label>
							<input type="number" step="0.01" v-model="option.price">
						</div>
						<div class="reyhoon-fields-options__row-field reyhoon-fields-options__row-selected">
							<label for="" class="reyhoon-fields-options__row-field-label"><?php esc_html_e( 'Selected', 'reyhoon-pro' ); ?></label>
							<div class="reyhoon-fields-options__row-field-spacer">
								<input :type="selected_input_type(field)" :name="'reyhoon_field_' + field.id" value="1" v-model="option.selected" @change='deselectOtherRadio( option, optionIndex, field )'>
							</div>
						</div>
					</div>

				</div>
				<div class="reyhoon-fields-options__row-action">
					<span class="dashicons dashicons-trash reyhoon-dashicons reyhoon-dashicons--trash" @click='deleteOption(optionIndex, field)'></span>
				</div>
			</div>
		</draggable>
	</div> <!-- .reyhoon-fields-options__body -->

	<div class="reyhoon-fields-options__btn_wrap">
		<button type="button" class="reyhoon-admin-button" @click='addOption( field, index )'><?php esc_html_e( 'Add Option', 'reyhoon-pro' ); ?></button>
	</div>

</div>
