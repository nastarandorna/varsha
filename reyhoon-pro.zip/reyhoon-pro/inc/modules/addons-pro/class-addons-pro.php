<?php
/**
 * Module: Addons.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

/**
 * Addons module class.
 */
class Reyhoon_Addons_Pro
{
    /**
     * Init.
     */
    public static function run()
    {
        $layout = Reyhoon_Settings::get_setting('store_general_product_layout');
        if (isset($layout) && $layout === 'variable') {
            return;
        }
        self::load_classes();

        add_filter('reyhoon_is_settings_page', array(__CLASS__, 'is_product_addon_edit_page'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'admin_assets'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'frontend_assets'));
        remove_action('admin_menu', array('Reyhoon_Addons', 'add_settings_page'));
    }

    /**
     * Load classes.
     *
     * @return void
     */
    public static function load_classes()
    {
        include_once 'class-addons-pro-field-groups.php';
        include_once 'class-addons-pro-fields.php';
        include_once 'class-addons-pro-fees.php';

        Reyhoon_Addons_Pro_Field_Groups::run();
        Reyhoon_Addons_Pro_Fields::run();
        Reyhoon_Addons_Pro_Fees::run();
    }

    /**
     * Determine if is product addon edit page.
     *
     * @param bool $is_settings_page Bool passed when hooking into `is_settings_page()`.
     *
     * @return bool
     */
    public static function is_product_addon_edit_page($is_settings_page = false)
    {
        if (!is_admin() || !function_exists('get_current_screen')) {
            return $is_settings_page;
        }

        $screen = get_current_screen();

        if (!$screen || 'post' !== $screen->base || 'reyhoon_addons' !== $screen->post_type) {
            return $is_settings_page;
        }

        return true;
    }

    /**
     * Enqueue admin assets.
     */
    public static function admin_assets()
    {
        if (!self::is_product_addon_edit_page()) {
            return;
        }

        //$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
        $suffix = '';

        // Styles.
        wp_enqueue_style('reyhoon-addons-pro', REYHOON_PRO_URL . 'inc/modules/addons-pro/assets/admin/css/addons' . $suffix . '.css', array(), REYHOON_PRO_VERSION);
        wp_enqueue_style('reyhoon-pro-vselect', REYHOON_PRO_ASSETS_URL . 'vendor/vue-select.min.css', array(), REYHOON_PRO_VERSION);

        // Scripts.
        wp_enqueue_script('reyhoon-pro-vuejs', REYHOON_PRO_ASSETS_URL . 'vendor/vue.js', array('jquery'), REYHOON_PRO_VERSION, true);
        wp_enqueue_script('reyhoon-pro-sortable', REYHOON_PRO_ASSETS_URL . 'vendor/Sortable.min.js', array('jquery'), REYHOON_PRO_VERSION, true);
        wp_enqueue_script('reyhoon-pro-vuedraggable', REYHOON_PRO_ASSETS_URL . 'vendor/vuedraggable.umd.min.js', array('jquery'), REYHOON_PRO_VERSION, true);
        wp_enqueue_script('reyhoon-pro-vselect', REYHOON_PRO_ASSETS_URL . 'vendor/vue-select.min.js', array('jquery'), REYHOON_PRO_VERSION, true);
        wp_enqueue_script('reyhoon-pro-main', REYHOON_PRO_ASSETS_URL . 'admin/js/main' . $suffix . '.js', array('jquery'), REYHOON_PRO_VERSION, true);


        wp_enqueue_script('reyhoon-addons-pro', REYHOON_PRO_URL . 'inc/modules/addons-pro/assets/admin/js/main' . $suffix . '.js', array(
            'jquery',
            'reyhoon-pro-vuejs',
            'reyhoon-pro-sortable',
            'reyhoon-pro-sortable',
            'reyhoon-pro-vselect',
        ), REYHOON_PRO_VERSION, true);

        wp_localize_script(
            'reyhoon-addons-pro',
            'reyhoon_pro_conditions_params',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'search_products_nonce' => wp_create_nonce('search-products'),
                'search_categories_nonce' => wp_create_nonce('search-categories'),
            )
        );
    }

    /**
     * Enqueue frontend assets.
     */
    public static function frontend_assets()
    {
        if (is_admin()) {
            return;
        }

        $suffix_css = is_rtl() ? '-rtl' : '';

        // Styles.
        wp_enqueue_style('reyhoon-addons-pro', REYHOON_PRO_URL . 'inc/modules/addons-pro/assets/frontend/css/addons' . $suffix_css . '.css', array(), REYHOON_PRO_VERSION);

        // Scripts.
        wp_enqueue_script('reyhoon-addons-pro', REYHOON_PRO_URL . 'inc/modules/addons-pro/assets/frontend/js/main.js', array('jquery', 'accounting'), REYHOON_PRO_VERSION, true);

        wp_localize_script(
            'reyhoon-addons-pro',
            'reyhoon_addons_pro_params',
            array(
                'i18n' => array(
                    // Translators: Field name.
                    'field_required' => __('%s is a required field', 'reyhoon-pro'),
                ),
                'currency' => array(
                    'format_num_decimals' => wc_get_price_decimals(),
                    'format_symbol' => get_woocommerce_currency_symbol(),
                    'format_decimal_sep' => esc_attr(wc_get_price_decimal_separator()),
                    'format_thousand_sep' => esc_attr(wc_get_price_thousand_separator()),
                    'format' => esc_attr(str_replace(array('%1$s', '%2$s'), array('%s', '%v'), get_woocommerce_price_format())),
                ),
            )
        );
    }
}
