<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.4
 * @ Decoder version: 1.0.2
 * @ Release: 10/08/2022
 */

// Decoded file for php version 74.
class Avin extends AVN_License
{
    private $productId = NULL;
    private static $instance = NULL;
    public function __construct($arg)
    {
        parent::__construct($arg);
        $this->productId = $arg["productId"];
        $action = $this->product;
        add_action("reyhoon_lic", [$this, "check_license_before_render"]);
        add_action("wp_ajax_install_license_" . $action, [$this, "ajax_install_license"]);
    }
    public static function instance($args)
    {
        if (self::$instance == NULL) {
            self::$instance = new self($args);
        }
        return self::$instance;
    }
    public function check_license_before_render()
    {
        $this->render_license_form($this->has_license());
    }
    public function has_license()
    {
        if ($_SERVER["HTTP_HOST"] == "localhost" || $_SERVER["HTTP_HOST"] == "127.0.0.1") {
            return true;
        }
        $encrypt = get_option($this->wp_option, false);
        $decrypt = $this->decrypt($encrypt, $this->salt);
        if (!$decrypt) {
            return false;
        }
        $decrypt = explode("_|_", $decrypt);
        list($license, $lastTimeSave) = $decrypt;
        $remaingDay = (time() - $lastTimeSave) / 86400;
        if ($remaingDay < 5) {
            return true;
        }
        $result_ret = $this->retrieve($license);
        if ($result_ret->status && $result_ret->timesActivated == 1) {
            $text = $license . "_|_" . time();
            $encrypt = $this->encrypt($text, $this->salt);
            update_option($this->wp_option, $encrypt);
            return true;
        }
        return false;
    }
    private function retrieve($license_token)
    {
        $result = $this->sendRequest("retrieve-license", ["lic" => $license_token, "pid" => $this->productId]);
        return $result;
    }
    private function sendRequest($method, $params = [])
    {
        $param_string = http_build_query($params);
        if ($method == "install-license") {
            $content = $this->curl($this->check_url . "/wp-json/license/v1/lic?" . $param_string);
        } else {
            if ($method == "retrieve-license") {
                $content = $this->curl($this->check_url . "/wp-json/license/v1/ret?" . $param_string);
            }
        }
        return json_decode($content);
    }
    private function curl($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, $url);
        $content = curl_exec($ch);
        if (!$content) {
            ini_set("allow_url_fopen", 1);
            $content = @file_get_contents($url);
        }
        return $content;
    }
    public function ajax_install_license()
    {
        $license = sanitize_text_field($_POST["license"]);
        if (empty($license)) {
            wp_send_json_error(["title" => "خطا!", "text" => "لطفا یک مقدار معتبر برای لایسنس وارد کنید", "icon" => "error", "confirmButtonText" => "باشه"]);
        }
        $retrieve = $this->retrieve($license)->status;
        if (!$retrieve) {
            wp_send_json_error(["title" => "خطا!", "text" => "لایسنس نامعتبر می باشد!", "icon" => "error", "confirmButtonText" => "باشه"]);
        }
        $result = $this->install($license);
        if ($result->success) {
            $text = $license . "_|_" . time();
            $encrypt = $this->encrypt($text, $this->salt);
            update_option($this->wp_option, $encrypt);
            wp_send_json_success(["title" => "تبریک!", "text" => "لایسنس شما با موفقیت فعال شد.صفحه را بروزرسانی کنید.", "icon" => "success", "confirmButtonText" => "باشه", "timer" => 5000, "timerProgressBar" => true]);
        } else {
            if (!is_object($result->message)) {
                wp_send_json_error(["title" => "خطا!", "text" => $result->message, "icon" => "error", "confirmButtonText" => "باشه"]);
            } else {
                $output = "";
                foreach ($result->message as $message) {
                    foreach ($message as $msg) {
                        $output .= $msg . " - ";
                    }
                }
                wp_send_json_error(["title" => "خطا!", "text" => $output, "icon" => "error", "confirmButtonText" => "باشه"]);
            }
        }
    }
    private function install($license_token)
    {
        $result = $this->sendRequest("install-license", ["lic" => $license_token, "domain" => $this->getHost()]);
        return $result;
    }
}
class Zhaket extends AVN_License
{
    private $token = NULL;
    private static $instance = NULL;
    public function __construct($arg)
    {
        $this->token = $arg["token"];
        parent::__construct($arg);
        $action = $this->product;
        add_action("reyhoon_lic", [$this, "check_license_before_render"]);
        add_action("wp_ajax_install_license_" . $action, [$this, "ajax_install_license"]);
    }
    public static function instance($args)
    {
        if (self::$instance == NULL) {
            self::$instance = new self($args);
        }
        return self::$instance;
    }
    public function check_license_before_render()
    {
        $this->render_license_form($this->has_license());
    }
    public function has_license()
    {
        if ($_SERVER["HTTP_HOST"] == "localhost" || $_SERVER["HTTP_HOST"] == "127.0.0.1") {
            return true;
        }
        $encrypt = get_option($this->wp_option, false);
        $decrypt = $this->decrypt($encrypt, $this->salt);
        if (!$decrypt) {
            return false;
        }
        $decrypt = explode("_|_", $decrypt);
        list($license, $lastTimeSave) = $decrypt;
        $remaingDay = (time() - $lastTimeSave) / 86400;
        if ($remaingDay < 5) {
            return true;
        }
        $result = $this->isValid($license);
        if ($result->status == "successful") {
            $text = $license . "_|_" . time();
            $encrypt = $this->encrypt($text, $this->salt);
            update_option($this->wp_option, $encrypt);
            return true;
        }
        return false;
    }
    private function isValid($license_token)
    {
        $result = $this->sendRequest("validation-license", ["token" => $license_token, "domain" => $this->getHost()]);
        return $result;
    }
    private function sendRequest($method, $params = [])
    {
        $param_string = http_build_query($params);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, $this->check_url . $method . "?" . $param_string);
        $content = curl_exec($ch);
        return json_decode($content);
    }
    public function ajax_install_license()
    {
        $license = sanitize_text_field($_POST["license"]);
        $token = $this->token;
        if (empty($license)) {
            wp_send_json_error(["title" => "خطا!", "text" => "لطفا یک مقدار معتبر برای لایسنس وارد کنید", "icon" => "error", "confirmButtonText" => "باشه"]);
        }
        $result = $this->install($license, $token);
        if ($result->status == "successful") {
            $text = $license . "_|_" . time();
            $encrypt = $this->encrypt($text, $this->salt);
            update_option($this->wp_option, $encrypt);
            wp_send_json_success(["title" => "تبریک!", "text" => "لایسنس شما با موفقیت فعال شد.صفحه را بروزرسانی کنید.", "icon" => "success", "confirmButtonText" => "باشه", "timer" => 5000, "timerProgressBar" => true]);
        } else {
            if (!is_object($result->message)) {
                wp_send_json_error(["title" => "خطا!", "text" => $result->message, "icon" => "error", "confirmButtonText" => "باشه"]);
            } else {
                $output = "";
                foreach ($result->message as $message) {
                    foreach ($message as $msg) {
                        $output .= $msg . " - ";
                    }
                }
                wp_send_json_error(["title" => "خطا!", "text" => $output, "icon" => "error", "confirmButtonText" => "باشه"]);
            }
        }
    }
    private function install($license_token, $product_token)
    {
        $result = $this->sendRequest("install-license", ["product_token" => $product_token, "token" => $license_token, "domain" => $this->getHost()]);
        return $result;
    }
}
class AVN_Lic_Controller
{
    private $salt = NULL;
    public function __construct($salt)
    {
        $this->salt = $salt;
    }
    public function get_License($args)
    {
        $obj = $args["seller"]::instance($args);
        return $obj->has_license();
    }
    public function salt()
    {
        return $this->salt;
    }
}
class AVN_License
{
    protected $check_url = NULL;
    protected $seller = NULL;
    protected $product = NULL;
    protected $wp_option = NULL;
    protected $parent_menu = NULL;
    protected $menu_title = NULL;
    protected $salt = NULL;
    public function __construct($args)
    {
        $this->set_property($args);
        add_action("reyhoon_lic", [$this, "avin_dashboard"], 999);
    }
    public function set_property($args)
    {
        extract($args);
        $this->seller = $seller;
        $this->check_url = $this->seller == "zhaket" ? "http://guard.zhaket.com/api/" : "https://www.avnlic.ir";
        $this->product = $product;
        $this->wp_option = $wp_option;
        $this->parent_menu = $parent_menu;
        $this->menu_title = $menu_title;
        $this->salt = $salt;
    }
    public function avin_dashboard()
    {
        wp_enqueue_style("avin_dashboard", plugin_dir_url(__FILE__) . "/templates/dashboard/dashboard-styles.css");
        wp_enqueue_script("avin_dashboard", plugin_dir_url(__FILE__) . "/templates/dashboard/dashboard.js", ["jquery"]);
    }
    public function render_license_form($hasLicense = TRUE)
    {
        echo "        <!-- License Start -->\r\n        ";
        if ($hasLicense) {
            echo "        <svg width=\"57\" height=\"57\" class=\"mx-auto mb-8\" viewBox=\"0 0 24 24\" fill=\"#27d39b\"\r\n             xmlns=\"http://www.w3.org/2000/svg\">\r\n            <path d=\"M12.0004 22.7599C10.9104 22.7599 9.83039 22.4399 8.98039 21.8099L4.68039 18.5999C3.54039 17.7499 2.65039 15.9699 2.65039 14.5599V7.11994C2.65039 5.57994 3.78039 3.93994 5.23039 3.39994L10.2204 1.52994C11.2104 1.15994 12.7704 1.15994 13.7604 1.52994L18.7504 3.39994C20.2004 3.93994 21.3304 5.57994 21.3304 7.11994V14.5499C21.3304 15.9699 20.4404 17.7399 19.3004 18.5899L15.0004 21.7999C14.1704 22.4399 13.0904 22.7599 12.0004 22.7599ZM10.7504 2.93994L5.76039 4.80994C4.91039 5.12994 4.16039 6.20994 4.16039 7.12994V14.5599C4.16039 15.5099 4.83039 16.8399 5.58039 17.3999L9.88039 20.6099C11.0304 21.4699 12.9704 21.4699 14.1304 20.6099L18.4304 17.3999C19.1904 16.8299 19.8504 15.5099 19.8504 14.5599V7.11994C19.8504 6.20994 19.1004 5.12994 18.2504 4.79994L13.2604 2.92994C12.5804 2.68994 11.4204 2.68994 10.7504 2.93994Z\"\r\n                  fill=\"#27d39b\"/>\r\n            <path d=\"M10.6602 14.2301C10.4702 14.2301 10.2802 14.1601 10.1302 14.0101L8.52023 12.4001C8.23023 12.1101 8.23023 11.6301 8.52023 11.3401C8.81023 11.0501 9.29023 11.0501 9.58023 11.3401L10.6602 12.4201L14.4302 8.65012C14.7202 8.36012 15.2002 8.36012 15.4902 8.65012C15.7802 8.94012 15.7802 9.42012 15.4902 9.71012L11.1902 14.0101C11.0402 14.1601 10.8502 14.2301 10.6602 14.2301Z\"\r\n                  fill=\"#27d39b\"/>\r\n        </svg>\r\n        <h3 class=\"text-lg text-green mb-8\">لایسنس شما فعال است</h3>\r\n        <p class=\"text-base mb-2\"> لایسنس فعلی شما :<code>";
            echo $this->getUserLic();
            echo "</code></p>\r\n        <button class=\"transform transition px-9 py-3 bg-gray-dark rounded-xl text-white mt-8 hover:-translate-y-1\"\r\n                id=\"new_lic\">ثبت لایسنس جدید\r\n        </button>\r\n    ";
        } else {
            echo "        <svg width=\"57\" height=\"57\" class=\"mx-auto mb-8\" viewBox=\"0 0 24 24\" fill=\"#F30A49\"\r\n             xmlns=\"http://www.w3.org/2000/svg\">\r\n            <path\r\n                d=\"M12.0004 22.7599C10.9104 22.7599 9.83039 22.4399 8.98039 21.8099L4.68039 18.5999C3.54039 17.7499 2.65039 15.9699 2.65039 14.5599V7.11994C2.65039 5.57994 3.78039 3.93994 5.23039 3.39994L10.2204 1.52994C11.2104 1.15994 12.7704 1.15994 13.7604 1.52994L18.7504 3.39994C20.2004 3.93994 21.3304 5.57994 21.3304 7.11994V14.5499C21.3304 15.9699 20.4404 17.7399 19.3004 18.5899L15.0004 21.7999C14.1704 22.4399 13.0904 22.7599 12.0004 22.7599ZM10.7504 2.93994L5.76039 4.80994C4.91039 5.12994 4.16039 6.20994 4.16039 7.12994V14.5599C4.16039 15.5099 4.83039 16.8399 5.58039 17.3999L9.88039 20.6099C11.0304 21.4699 12.9704 21.4699 14.1304 20.6099L18.4304 17.3999C19.1904 16.8299 19.8504 15.5099 19.8504 14.5599V7.11994C19.8504 6.20994 19.1004 5.12994 18.2504 4.79994L13.2604 2.92994C12.5804 2.68994 11.4204 2.68994 10.7504 2.93994Z\"/>\r\n            <path\r\n                d=\"M14.1498 14.1899C13.9598 14.1899 13.7698 14.1199 13.6198 13.9699L9.36984 9.71988C9.07984 9.42988 9.07984 8.94988 9.36984 8.65988C9.65984 8.36988 10.1398 8.36988 10.4298 8.65988L14.6798 12.9099C14.9698 13.1999 14.9698 13.6799 14.6798 13.9699C14.5298 14.1099 14.3398 14.1899 14.1498 14.1899Z\"/>\r\n            <path\r\n                d=\"M9.84906 14.2299C9.65906 14.2299 9.46906 14.1599 9.31906 14.0099C9.02906 13.7199 9.02906 13.2399 9.31906 12.9499L13.5691 8.69992C13.8591 8.40992 14.3391 8.40992 14.6291 8.69992C14.9191 8.98992 14.9191 9.46992 14.6291 9.75992L10.3791 14.0099C10.2391 14.1599 10.0391 14.2299 9.84906 14.2299Z\"/>\r\n        </svg>\r\n        <h3 class=\"text-lg text-red mb-2\">لایسنس شما فعال نیست</h3>\r\n        ";
            $lic = !strpos($this->seller, "avin") ? "آوین" : "ژاکت";
            echo "        <p class=\"text-base mb-8\">ابتدا از طریق سایت ";
            echo $lic;
            echo " کد لایسنس را دریافت کرده و لایسنس خود را فعال\r\n            کنید.</p>\r\n    ";
        }
        echo "\r\n        <div class=\"mt-4\"  id=\"install_license\" ";
        echo $hasLicense ? "style=\"display:none\"" : "";
        echo ">\r\n            <input class=\"license form-input rounded-xl shadow-2xl w-full border-0 py-3\" type='text'\r\n                   name=\"license_token\"\r\n     value=\"123456\"\r\n              placeholder=\"کد لایسنس خود را وارد کنید.\"/>\r\n            <button type=\"button\"\r\n                    class=\"transform transition px-9 py-3 bg-green rounded-xl text-white mt-4 hover:-translate-y-1\">ثبت\r\n                لایسنس\r\n            </button>\r\n\r\n        </div>\r\n\r\n        <!-- License End -->\r\n        <script>\r\n            jQuery(document).ready(function (\$) {\r\n                var ajax_url = \"";
        echo admin_url("admin-ajax.php");
        echo "\";\r\n                \$(document).on('click', '#install_license button', function (event) {\r\n                    event.preventDefault();\r\n\r\n                    license = \$(this).siblings('input.license').val();\r\n\r\n                    \$('#install_license').addClass('waiting');\r\n                    \$.ajax({\r\n                        url: ajax_url,\r\n                        type: 'POST',\r\n                        dataType: 'json',\r\n                        data: {\r\n                            action: 'install_license_";
        echo $this->product;
        echo "',\r\n                            license: license\r\n                        },\r\n                    })\r\n                        .done(function (result) {\r\n                            Swal.fire(result.data).then((result) => {\r\n                            location.reload();\r\n                            });\r\n                        })\r\n                        .fail(function () {\r\n                            Swal.fire({\r\n                                title: 'خطا!',\r\n                                text: 'متاسفانه مشکلی پیش آمده. صفحه را بروزرسانی کنید و مجدد تست کنید.',\r\n                                icon: 'error',\r\n                                confirmButtonText: 'باشه'\r\n                            })\r\n                        })\r\n                        .always(function () {\r\n                            \$('#install_license').removeClass('waiting');\r\n                        });\r\n                });\r\n\r\n                \$('#new_lic').click(function (e) {\r\n                    e.preventDefault();\r\n                    \$('#install_license').slideDown(300);\r\n                    \$(this).slideUp(300)\r\n                })\r\n            });\r\n        </script>\r\n        ";
    }
    protected function getUserLic()
    {
        $encrypt = get_option($this->wp_option, false);
        $decrypt = $this->decrypt($encrypt, $this->salt);
        if (!$decrypt) {
            return "";
        }
        $decrypt = explode("_|_", $decrypt);
        $license = $decrypt[0];
        return $license;
    }
    protected function decrypt($msg_encrypted_bundle, $password)
    {
    	$decrypted_msg="";
        $password = sha1($password);
        $components = explode(":", $msg_encrypted_bundle);
        $iv = $components[0];
        $salt = @hash("sha256", $password . $components[1]);
        if(isset($components[2])){
			 $encrypted_msg = $components[2];
			 $decrypted_msg = openssl_decrypt($encrypted_msg, "aes-256-cbc", $salt, NULL, $iv);
		}
       
        
        if ($decrypted_msg === false) {
            return false;
        }
        return $decrypted_msg;
    }
    protected function getHost()
    {
        $possibleHostSources = ["HTTP_X_FORWARDED_HOST", "HTTP_HOST", "SERVER_NAME", "SERVER_ADDR"];
        $sourceTransformations = ["HTTP_X_FORWARDED_HOST" => function ($value) {
            $elements = explode(",", $value);
            return trim(end($elements));
        }];
        $host = "";
        foreach ($possibleHostSources as $source) {
            if (!empty($host)) {
                $host = preg_replace("/:\\d+\$/", "", $host);
                $host = str_ireplace("www.", "", $host);
                return trim($host);
            }
            if (!empty($_SERVER[$source])) {
                $host = $_SERVER[$source];
                if (array_key_exists($source, $sourceTransformations)) {
                    $host = $sourceTransformations[$source]($host);
                }
            }
        }
    }
    protected function encrypt($data, $password)
    {
        $iv = substr(sha1(mt_rand()), 0, 16);
        $password = sha1($password);
        $salt = sha1(mt_rand());
        $saltWithPassword = hash("sha256", $password . $salt);
        $encrypted = openssl_encrypt((int) $data, "aes-256-cbc", (int) $saltWithPassword, NULL, $iv);
        $msg_encrypted_bundle = $iv . ":" . $salt . ":" . $encrypted;
        return $msg_encrypted_bundle;
    }
}

?>