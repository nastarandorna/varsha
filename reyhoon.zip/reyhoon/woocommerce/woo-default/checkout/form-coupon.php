<?php
/**
 * Checkout coupon form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-coupon.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.4.4
 */

defined( 'ABSPATH' ) || exit;

if ( ! wc_coupons_enabled() ) { // @codingStandardsIgnoreLine.
	return;
}

?>

<form class="checkout_coupon woocommerce-form-coupon" method="post" >

	<svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
		<g clip-path="url(#clip0_392_173)">
			<path d="M17.5 5.83325V8.16659" stroke="#737373" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
			<path d="M17.5 12.8333V15.1666" stroke="#737373" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
			<path d="M17.5 19.8333V22.1666" stroke="#737373" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
			<path d="M5.83333 5.83325H22.1667C22.7855 5.83325 23.379 6.07908 23.8166 6.51667C24.2542 6.95425 24.5 7.54775 24.5 8.16659V11.6666C23.8812 11.6666 23.2877 11.9124 22.8501 12.35C22.4125 12.7876 22.1667 13.3811 22.1667 13.9999C22.1667 14.6188 22.4125 15.2122 22.8501 15.6498C23.2877 16.0874 23.8812 16.3333 24.5 16.3333V19.8333C24.5 20.4521 24.2542 21.0456 23.8166 21.4832C23.379 21.9208 22.7855 22.1666 22.1667 22.1666H5.83333C5.21449 22.1666 4.621 21.9208 4.18342 21.4832C3.74583 21.0456 3.5 20.4521 3.5 19.8333V16.3333C4.11884 16.3333 4.71233 16.0874 5.14992 15.6498C5.5875 15.2122 5.83333 14.6188 5.83333 13.9999C5.83333 13.3811 5.5875 12.7876 5.14992 12.35C4.71233 11.9124 4.11884 11.6666 3.5 11.6666V8.16659C3.5 7.54775 3.74583 6.95425 4.18342 6.51667C4.621 6.07908 5.21449 5.83325 5.83333 5.83325" stroke="#737373" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
		</g>
		<defs>
			<clipPath id="clip0_392_173">
				<rect width="28" height="28" fill="white"/>
			</clipPath>
		</defs>
	</svg>
	<input type="text" name="coupon_code" class="input-text" placeholder="<?php esc_attr_e( 'Add coupon', 'woocommerce' ); ?>" id="coupon_code" value="" />
	<button type="submit" class="button" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'woocommerce' ); ?>"><?php _e( 'Apply coupon', 'reyhoon' );?></button>

</form>
