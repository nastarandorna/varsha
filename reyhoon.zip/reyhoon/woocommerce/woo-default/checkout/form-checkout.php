<?php
/**
 * Checkout Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-checkout.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_user_logged_in() ) {
	echo do_shortcode( '[reyhoon_otp]' ); ?>

	<div class="blur-background-image-container">
		<img src="<?php echo REYHOON_ASSETS_URL . 'img/blur-background-no-login.jpg' ?>" alt="image">
		<div>
			<h3>
				<?php _e("To complete your order, please log in or register.",'reyhoon'); ?>
			</h3>
			<button onclick="showPhoneLoginModal()"><?php _e('login and register','reyhoon'); ?></button>
		</div>
	</div>

	<script>
        function showPhoneLoginModal() {
            jQuery(function ($) {
                $('.reyhoon-drawer-overlay').addClass('reyhoon-drawer-overlay--open');
                $('.reyhoon-drawer.otp').addClass('reyhoon-drawer--open');
                $('body').addClass('reyhoon-drawer-open');
            });
        }
	</script>

	<?php

} else {
	?>

	<div class="ghab-steps">
		<a href="<?= home_url(); ?>" class="checkout-back-btn">
			<svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
				<g clip-path="url(#clip0_1380_2224)">
					<path d="M22.1665 14H5.83317" stroke="#071117" stroke-width="1.5" stroke-linecap="round"
					      stroke-linejoin="round"/>
					<path d="M22.1665 14L15.1665 21" stroke="#071117" stroke-width="1.5" stroke-linecap="round"
					      stroke-linejoin="round"/>
					<path d="M22.1665 14L15.1665 7" stroke="#071117" stroke-width="1.5" stroke-linecap="round"
					      stroke-linejoin="round"/>
				</g>
				<defs>
					<clipPath id="clip0_1380_2224">
						<rect width="28" height="28" fill="white" transform="matrix(-1 0 0 1 28 0)"/>
					</clipPath>
				</defs>
			</svg>
			<?php _e("Return to Homepage",'reyhoon'); ?>
		</a>
	</div>

	<?php

	do_action( 'woocommerce_before_checkout_form', $checkout );

// If checkout registration is disabled and not logged in, the user cannot checkout.
	if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
		echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) );

		return;
	}

	?>

	<?php

	if ( WC()->cart->needs_shipping() ) { ?>
		<div id="delivery-addr" class="white-box">
			<?php
			$customer = new WC_Customer( get_current_user_id() );
			if ( $customer->has_shipping_address() ) {
				$billing_first_name = $customer->get_billing_first_name();
				$billing_last_name  = $customer->get_billing_last_name();
				$billing_address_1  = $customer->get_billing_address_1();
				$billing_address_2  = $customer->get_billing_address_2();
				$billing_city       = ( class_exists( 'PWS_Core' ) ) ? PWS_Core::get_city( $customer->get_billing_city() ) : $customer->get_billing_city();
				$billing_state      = $customer->get_billing_state();
				$billing_phone      = $customer->get_billing_phone();
				?>
				<div class="user-info">
					<div class="addr-box">
						<div class="icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="18.759" height="21.51"
							     viewBox="0 0 18.759 21.51">
								<g id="location" transform="translate(-2.623 -1.25)">
									<path id="Path_276" data-name="Path 276"
									      d="M12,14.17a3.865,3.865,0,1,1,3.87-3.86A3.873,3.873,0,0,1,12,14.17Zm0-6.23a2.37,2.37,0,1,0,2.37,2.37A2.375,2.375,0,0,0,12,7.94Z"
									      fill="#8995a6"/>
									<path id="Path_277" data-name="Path 277"
									      d="M12,22.76a5.971,5.971,0,0,1-4.13-1.67C4.92,18.25,1.66,13.72,2.89,8.33A9.116,9.116,0,0,1,12,1.25h.01a9.115,9.115,0,0,1,9.11,7.09c1.22,5.39-2.04,9.91-4.99,12.75A5.971,5.971,0,0,1,12,22.76ZM12,2.75A7.552,7.552,0,0,0,4.36,8.66C3.28,13.37,6.24,17.43,8.92,20a4.426,4.426,0,0,0,6.17,0c2.67-2.57,5.63-6.63,4.57-11.34A7.58,7.58,0,0,0,12,2.75Z"
									      fill="#8995a6"/>
								</g>
							</svg>
						</div>
						<div class="addr">
							<p><?php echo $billing_first_name . ' ' . $billing_last_name; ?></p>
							<h3><?php echo $billing_city . ', ' . $billing_address_1 . ' ' . $billing_address_2; ?></h3>
							<p><?php echo $billing_phone; ?>
								<button onClick='showBillingForm()'><?php _e('edit address','reyhoon'); ?></button>
							</p>
						</div>
					</div>
				</div>
			<?php } else { ?>
				<div class="no-addr">
					<svg xmlns="http://www.w3.org/2000/svg" width="32.88" height="37.701" viewBox="0 0 32.88 37.701">
						<g id="location-cross" transform="translate(-2.623 -1.25)">
							<path id="Path_280" data-name="Path 280"
							      d="M19.058,38.951a10.465,10.465,0,0,1-7.239-2.927C6.648,31.046.935,23.106,3.09,13.659,5.036,5.088,12.52,1.25,19.058,1.25h.018c6.538,0,14.022,3.838,15.967,12.427,2.138,9.447-3.576,17.369-8.746,22.347A10.465,10.465,0,0,1,19.058,38.951Zm0-35.072C13.957,3.879,7.4,6.6,5.667,14.238c-1.893,8.255,3.3,15.371,7.992,19.876a7.757,7.757,0,0,0,10.814,0c4.68-4.5,9.868-11.62,8.01-19.876C30.731,6.6,24.158,3.879,19.058,3.879Z"
							      transform="translate(0)" fill="#8995a6"/>
							<path id="Path_281" data-name="Path 281"
							      d="M17.544,17.818a1.3,1.3,0,0,1-.929-.386L9.674,10.492a1.314,1.314,0,0,1,1.858-1.858l6.941,6.941a1.322,1.322,0,0,1,0,1.858A1.377,1.377,0,0,1,17.544,17.818Z"
							      transform="translate(5.021 5.271)" fill="#8995a6"/>
							<path id="Path_282" data-name="Path 282"
							      d="M10.562,17.858a1.3,1.3,0,0,1-.929-.386,1.322,1.322,0,0,1,0-1.858l6.941-6.941a1.314,1.314,0,0,1,1.858,1.858l-6.941,6.941A1.3,1.3,0,0,1,10.562,17.858Z"
							      transform="translate(4.99 5.301)" fill="#8995a6"/>
						</g>
					</svg>
					<div><?php _e("You haven't registered an address yet.",'reyhoon'); ?></div>
					<button onClick='showBillingForm()'><?php _e("Add Address",'reyhoon'); ?></button>
				</div>
			<?php } ?>
		</div>

	<?php } ?>


	<form name="checkout" method="post" class="checkout woocommerce-checkout woo-def-checkout"
	      action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">

		<?php if ( $checkout->get_checkout_fields() ) : ?>

			<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

			<?php
			$class = WC()->cart->needs_shipping() ? '' : 'download';
			?>

			<div class="col2-set <?php echo $class; ?>" id="customer_details">
				<div id="billing-form" class="col-1 billing-form">
					<?php do_action( 'woocommerce_checkout_billing' ); ?>
				</div>

				<div class="col-2 shipping-form">
					<?php do_action( 'woocommerce_checkout_shipping' ); ?>
				</div>

				<button type="button" class="fixed-btn" onClick='hideBillingForm()'><?php _e('save address','reyhoon'); ?></button>
			</div>

			<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

		<?php endif; ?>

		<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>

		<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

		<?php do_action( 'woocommerce_checkout_order_review' ); ?>

		<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

	</form>

	<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>

	<div id="backdrop" onClick='hideBillingForm()'></div>
<?php } ?>
