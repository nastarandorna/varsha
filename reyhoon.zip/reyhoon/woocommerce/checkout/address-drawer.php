<?php
?>

<div class="reyhoon-drawer-overlay" data-reyhoon-trigger="drawer.close"></div>
<div id="address_drawer" class="reyhoon-drawer">
    <button type="button" class="reyhoon-drawer__close" data-reyhoon-trigger="drawer.close">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clip-path="url(#clip0_126_225)">
                <path d="M18 6L6 18" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M6 6L18 18" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </g>
            <defs>
                <clipPath id="clip0_126_225">
                    <rect width="24" height="24" fill="white"/>
                </clipPath>
            </defs>
        </svg>
    </button>
    <?php if (!empty(Reyhoon_Settings::get_setting('store_general_map_api')) && Reyhoon_Settings::get_setting('store_general_map_api') != '') { ?>
        <div class="reyhoon-address-drawer-map-container">
            <div id="app">
                <div id="center-marker"></div>
            </div>
            <div id="message"></div>
            <button id="confirm_location" class="button-location" type="button">
            <span class="confirm-location-button">
                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_972_69)">
                        <path d="M5.20825 12.5001L10.4166 17.7084L20.8333 7.29175" stroke="white" stroke-width="1.7"
                              stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_972_69">
                            <rect width="25" height="25" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
                <?php _e("Confirm Location",'reyhoon'); ?>
            </span>
                <span class="edit-location-button">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_976_754)">
                        <path d="M3.66675 18.3333H7.33341L16.9584 8.70829C17.4446 8.22206 17.7178 7.56259 17.7178 6.87495C17.7178 6.18732 17.4446 5.52785 16.9584 5.04162C16.4722 4.55539 15.8127 4.28223 15.1251 4.28223C14.4374 4.28223 13.778 4.55539 13.2917 5.04162L3.66675 14.6666V18.3333Z"
                              stroke="#036666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12.375 5.95837L16.0417 9.62504" stroke="#036666" stroke-width="1.5"
                              stroke-linecap="round"
                              stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_976_754">
                            <rect width="22" height="22" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
                <?php _e("Edit Location",'reyhoon'); ?>
            </span>
            </button>

        </div>
    <?php } else {
        echo '<p>'.__('The map API has not been entered.','reyhoon').'</p>';
    } ?>
    <div class="reyhoon-drawer__inner">

        <div class="reyhoon-addres-drawer-svg">
            <?php Reyhoon_Helpers::echo_svg('addres-drawer-svg') ?>
        </div>

        <div class="reyhoon-address-drawer-attention">
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_976_760)">
                    <path d="M18 31.5C25.4558 31.5 31.5 25.4558 31.5 18C31.5 10.5442 25.4558 4.5 18 4.5C10.5442 4.5 4.5 10.5442 4.5 18C4.5 25.4558 10.5442 31.5 18 31.5Z"
                          stroke="#FFB901" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M18 12H18.015" stroke="#FFB901" stroke-width="2" stroke-linecap="round"
                          stroke-linejoin="round"/>
                    <path d="M16.5 18H18V24H19.5" stroke="#FFB901" stroke-width="2" stroke-linecap="round"
                          stroke-linejoin="round"/>
                </g>
                <defs>
                    <clipPath id="clip0_976_760">
                        <rect width="36" height="36" fill="white"/>
                    </clipPath>
                </defs>
            </svg>
            <p><?php _e("For assurance, please verify the address, and if it doesn't match, correct it.",'reyhoon'); ?></p>
        </div>

        <?php do_action('woocommerce_checkout_before_customer_details'); ?>

        <div class="reyhoon-placeholder reyhoon-placeholder--billing">
            <div class="reyhoon-checkout-section reyhoon-checkout-section--billing">
                <?php do_action('woocommerce_checkout_billing'); ?>
            </div>
        </div>

        <?php do_action('woocommerce_checkout_after_customer_details'); ?>

        <button type="button" class="reyhoon-address-drawer-accept-address">
            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_972_69)">
                    <path d="M5.20825 12.5001L10.4166 17.7084L20.8333 7.29175" stroke="white" stroke-width="1.7"
                          stroke-linecap="round" stroke-linejoin="round"/>
                </g>
                <defs>
                    <clipPath id="clip0_972_69">
                        <rect width="25" height="25" fill="white"/>
                    </clipPath>
                </defs>
            </svg>
            <?php _e("Confirm Address",'reyhoon'); ?>
        </button>

    </div>
</div>
