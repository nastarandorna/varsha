<?php

$method = Reyhoon_Services::get_selected_service( true, true );
$style1 = $method === 'reyhoon_motorcycle' ? 'display:block' : 'display:none';
$style2 = $method === 'reyhoon_local_pickup' || 'reyhoon_serving' ? 'display:block' : 'display:none';

?>

<div class="ghab-steps">
    <a href="<?= home_url(); ?>" class="checkout-back-btn">
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clip-path="url(#clip0_1380_2224)">
                <path d="M22.1665 14H5.83317" stroke="#071117" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M22.1665 14L15.1665 21" stroke="#071117" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M22.1665 14L15.1665 7" stroke="#071117" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </g>
            <defs>
                <clipPath id="clip0_1380_2224">
                    <rect width="28" height="28" fill="white" transform="matrix(-1 0 0 1 28 0)"/>
                </clipPath>
            </defs>
        </svg>
        <?php _e("Return to Homepage",'reyhoon'); ?>
    </a>
</div>

<div class="reyhoon-checkout">

    <?php do_action( 'woocommerce_before_checkout_form', $checkout ); ?>

    <form name="checkout" method="post" class="checkout woocommerce-checkout"
          action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">
        <div class="reyhoon-checkout__form">


            <?php wc_get_template( 'checkout/address-drawer.php' ); ?>


            <div class="checkout_left_section">
                <div class="reyhoon-checkout-section reyhoon-checkout-section--customer-details"
                     id="customer_details">
                    <!-- روش های حمل و نقل با جاوا اسکریپت در بالای این کامنت اضافه میشود-->
                    <div id="user_adress" class="method-motorcycle-container" style="<?= $style1 ?>">
                        <div class="method-motorcycle-price">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_1380_2115)">
                                    <path d="M12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21Z"
                                          stroke="#FFB901" stroke-width="2" stroke-linecap="round"
                                          stroke-linejoin="round"/>
                                    <path d="M12 8H12.01" stroke="#FFB901" stroke-width="2" stroke-linecap="round"
                                          stroke-linejoin="round"/>
                                    <path d="M11 12H12V16H13" stroke="#FFB901" stroke-width="2" stroke-linecap="round"
                                          stroke-linejoin="round"/>
                                </g>
                                <defs>
                                    <clipPath id="clip0_1380_2115">
                                        <rect width="24" height="24" fill="white"/>
                                    </clipPath>
                                </defs>
                            </svg>
                            <span>هزینه ارسال بر اساس تعرفه اتوپیک تپسی محاسبه شده و بر عهده مشتری است. </span>
                        </div>
                        <div class="method-motorcycle-map">
                            <?php
                            $customer = new WC_Customer( get_current_user_id() );
                            if ( $customer->get_billing_address_1() != '' ) {
                                $billing_address_1 = $customer->get_billing_address_1();
                                $billing_address_2 = $customer->get_billing_address_2();
                                $user_lng = get_user_meta($customer->get_id(),'user_lng',true);
                                $user_lat = get_user_meta($customer->get_id(),'user_lat',true);
                                ?>
                                <div data-lat="<?php echo $user_lng; ?>" data-lng="<?php echo $user_lat; ?>" class="map-with-address">
                                    <?php if(!$user_lng || !$user_lat){?>
                                        <p> <?=$billing_address_1 ?></p>
                                        <button type="button" class="user-address-btn add-address">
                                            ویرایش آدرس
                                        </button>
                                    <?php } ?>
                                </div>
                                <?php
                            } else { ?>
                                <div class="map-no-address">
                                    <p><?php _e("You haven't entered any address.",'reyhoon'); ?></p>
                                    <button type="button" class="user-address-btn user-address-add-btn"><?php _e("Add Address",'reyhoon'); ?></button>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                    <div id="resturant_location"
                         style="height: 200px;margin: 8px;border-radius: 8px; <?= $style2 ?>">
                        <iframe width="100%" height="200" src="https://map.ir/lat/<?=get_option('lat')?>/lng/<?=get_option('lng')?>/z/13/p/ما اینجاییم" style="border: unset;border-radius: 16px"></iframe>
                    </div>
                </div>


                <?php do_action( 'reyhon_after_customer_details' ); ?>


            </div>


            <div id="order_review"
                 class="reyhoon-checkout-section checkout_right_section woocommerce-checkout-review-order">
                <?php do_action( 'woocommerce_review_order_after_submit' ); ?>


                <?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>


                <?php do_action( 'woocommerce_checkout_before_order_review' ); ?>


                <?php do_action( 'woocommerce_checkout_order_review' ); ?>


                <?php do_action( 'woocommerce_checkout_after_order_review' ); ?>


            </div>

        </div>

        <div class="clear clearfix"></div>
    </form>


    <?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>

</div>
