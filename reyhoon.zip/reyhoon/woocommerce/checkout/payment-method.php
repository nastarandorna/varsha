<?php
/**
 * Output a single payment method
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/payment-method.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<li class="wc_payment_method payment_method_<?php echo esc_attr( $gateway->id );?>">
    <input id="payment_method_<?php echo esc_attr( $gateway->id ); ?>" type="radio" class="input-radio"
           name="payment_method"
           value="<?php echo esc_attr( $gateway->id ); ?>" <?php checked( $gateway->chosen, true ); ?>
           data-order_button_text="<?php echo esc_attr( $gateway->order_button_text ); ?>"/>

    <label for="payment_method_<?php echo esc_attr( $gateway->id ); ?>">
		<span>
            <div class="payment-method-desc">
                <?php echo $gateway->get_title(); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?>
                <?php if ( $gateway->has_fields() || $gateway->get_description() ) : ?>
                    <div class="payment_box payment_method_<?php echo esc_attr( $gateway->id ); ?>"
                         <?php if ( ! $gateway->chosen ) : /* phpcs:ignore Squiz.ControlStructures.ControlSignature.NewlineAfterOpenBrace */ ?>style="display:none;"<?php endif; /* phpcs:ignore Squiz.ControlStructures.ControlSignature.NewlineAfterOpenBrace */ ?>>
			<?php $gateway->payment_fields(); ?>
		</div>
                <?php endif; ?>
            </div>
             <?php if(esc_attr( $gateway->id )  =="WC_ZPal") {
                 echo '<img style="max-width: 48px;" src="https://uonfood.ir/wp-content/plugins/reyhoon/assets/img/zarinpal16.png" alt="" />';
             }elseif (esc_attr( $gateway->id ) =="WC_Sep_Payment_Gateway" ){
                 echo '<img style="max-width: 48px;" src="https://papichfood.com/vm-arsha/plugins/reyhoon/assets/img/gateway-saman.png" alt="" />';
             }elseif (esc_attr( $gateway->id ) =="wc_zibal" ){
                 echo '<img style="max-width: 48px;" src="https://uonfood.ir/wp-content/plugins/reyhoon/assets/img/zibal16.jpg" alt="" />';
             }elseif (esc_attr( $gateway->id ) =="WC_Gateway_SnappPay" ){
                 echo '<img style="max-width: 48px;" src="https://uonfood.ir/wp-content/plugins/reyhoon/assets/img/Shetab.png" alt="" />';
             }
             elseif (esc_attr( $gateway->id ) =="WCDigiPay" ){
                 echo '<img style="max-width: 48px;" src="https://papichfood.com/vm-arsha/plugins/reyhoon/assets/img/digipay_logoo.png" alt="" />';
             }
             else{
                 echo $gateway->get_icon();
             }
             ?>
        </span>
    </label>
</li>
