<?php
/**
 * Checkout Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-checkout.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.5.0
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!is_user_logged_in()) {
    echo do_shortcode('[reyhoon_otp]'); ?>

    <div class="blur-background-image-container">
        <img src="<?php echo REYHOON_ASSETS_URL . 'img/blur-background-no-login.jpg' ?>" alt="image">
        <div>
            <h3>
                برای تکمیل سفارش، وارد شوید یا ثبت نام کنید.
            </h3>
            <button onclick="showPhoneLoginModal()">ورود و ثبت نام</button>
        </div>
    </div>

    <script>
        function showPhoneLoginModal() {
            jQuery(function ($) {
                $('.reyhoon-drawer-overlay').addClass('reyhoon-drawer-overlay--open');
                $('.reyhoon-drawer.otp').addClass('reyhoon-drawer--open');
                $('body').addClass('reyhoon-drawer-open');
            });
        }
    </script>

    <?php

} else {
        $user = wp_get_current_user();
    $user_role = $user->roles;
    if (in_array('smart_table',$user_role) ) {
        include 'smart-table-checkout.php';
    } else {
        include 'default-checkout.php';
    }
}
