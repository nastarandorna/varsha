<?php
/**
 * Review order div
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/review-order.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 5.2.0
 */
defined('ABSPATH') || exit;
?>
<div id="order_review" class="reyhoon-checkout__order-review woocommerce-checkout-review-order-table">
    <?php if (WC()->cart->needs_shipping() && WC()->cart->show_shipping()) : ?>
        <div class="reyhoon-checkout__shipping-table">
            <?php do_action('woocommerce_review_order_before_shipping'); ?>
            <?php wc_cart_totals_shipping_html(); ?>
            <?php do_action('woocommerce_review_order_after_shipping'); ?>
        </div>
    <?php endif; ?>

    <div>
        <?php
        do_action('woocommerce_review_order_before_cart_contents');

        // Get a clean loop with only valid cart items.
        $valid_cart_items = array();

        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
            $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);

            if ($_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_checkout_cart_item_visible', true, $cart_item, $cart_item_key)) {
                $valid_cart_items[$cart_item_key] = $cart_item;
            }
        }

        $valid_cart_items_count = count($valid_cart_items);
        $cart_items_i = 0;

        // Now loop the clean array of cart items.
        foreach ($valid_cart_items as $cart_item_key => $cart_item) {
            $classes = array(
                apply_filters('woocommerce_cart_item_class', 'cart-item', $cart_item, $cart_item_key),
            );

            if (0 === $cart_items_i) {
                $classes[] = 'cart-item--first';
            }

            if ($valid_cart_items_count - 1 === $cart_items_i) {
                $classes[] = 'cart-item--last';
            }

            $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
            ?>
            <div class="<?php echo esc_attr(implode(' ', $classes)); ?>">
                <div class="product-name">
                    <div class="reyhoon-checkout__cart-item">
                        <div class="reyhoon-checkout__cart-item-image">
                            <?php echo wp_kses_post($cart_item['data']->get_image()); ?>
                        </div>
                        <div class="reyhoon-checkout__cart-item-data">
                            <strong><?php echo wp_kses_post(apply_filters('woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key)); ?></strong>
                            <div class="product-total">
		                        <?php echo apply_filters('woocommerce_checkout_cart_item_quantity', ' <span class="product-quantity">' . sprintf('(%s عدد )', $cart_item['quantity']) . '</span>', $cart_item, $cart_item_key); ?>
                            </div>
                        </div>
                        <?php echo apply_filters('woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal($_product, $cart_item['quantity']), $cart_item, $cart_item_key); ?>
                    </div>
	                <?php echo wc_get_formatted_cart_item_data($cart_item); ?>
                </div>
            </div>
            <?php
            $cart_items_i++;
        }

        do_action('woocommerce_review_order_after_cart_contents');
        ?>
    </div>
    <div class="reyhoon-checkout__footer">
        <div class="reyhoon-checkout__cart-subtotal">
            <div><?php esc_html_e(' جمع غذاها', 'woocommerce') ?> (<?php echo WC()->cart->get_cart_contents_count() ?> عدد )</div>
            <div><?php wc_cart_totals_subtotal_html(); ?></div>
        </div>


        <?php foreach (WC()->cart->get_coupons() as $code => $coupon) : ?>
            <div class="cart-discount cart-discount--<?php echo esc_attr(sanitize_title($code)); ?>">
                <div><?php wc_cart_totals_coupon_label($coupon); ?></div>
                <div><?php wc_cart_totals_coupon_html($coupon); ?></div>
            </div>
        <?php endforeach; ?>

        <?php foreach (WC()->cart->get_fees() as $fee) : ?>
            <div class="fee">
                <div><?php echo esc_html($fee->name); ?></div>
                <div><?php wc_cart_totals_fee_html($fee); ?></div>
            </div>
        <?php endforeach; ?>

        <?php if (wc_tax_enabled() && !WC()->cart->display_prices_including_tax()) : ?>
            <?php if ('itemized' === get_option('woocommerce_tax_total_display')) : ?>
                <?php foreach (WC()->cart->get_tax_totals() as $code => $tax) : ?>
                    <div class="tax-rate tax-rate--<?php echo esc_attr(sanitize_title($code)); ?>">
                        <div><?php echo esc_html($tax->label); ?></div>
                        <div><?php echo wp_kses_post($tax->formatted_amount); ?></div>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="tax-total">
                    <div><?php echo esc_html(WC()->countries->tax_or_vat()); ?></div>
                    <div><?php wc_cart_totals_taxes_total_html(); ?></div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <?php if (WC()->cart->needs_shipping() && WC()->cart->show_shipping()) : ?>
            <div class="shipping-total">
                <div><?php esc_html_e('shipping cost', 'reyhoon'); ?></div>
                <div><?php echo wc_price(WC()->cart->get_shipping_total()); ?></div>
            </div>
        <?php endif; ?>

        <?php do_action('woocommerce_review_order_before_order_total'); ?>

        <div class="order-total">
            <div><?php esc_html_e('Total', 'woocommerce'); ?></div>
            <div><?php wc_cart_totals_order_total_html(); ?></div>
        </div>

        <?php do_action('woocommerce_review_order_after_order_total'); ?>
    </div>
    <div class="woocommerce-additional-fields">
		<?php do_action( 'woocommerce_before_order_notes', $checkout ); ?>
        <div class="woocommerce-additional-fields__field-wrapper">
			<?php foreach ( $checkout->get_checkout_fields( 'order' ) as $key => $field ) : ?>
				<?php woocommerce_form_field( $key, $field, $checkout->get_value( $key ) ); ?>
			<?php endforeach; ?>
        </div>
		<?php do_action( 'woocommerce_after_order_notes', $checkout ); ?>
    </div>

    <?php echo apply_filters( 'woocommerce_order_button_html', '<button type="submit" class="button alt" name="woocommerce_checkout_place_order" id="place_order" value="ثبت سفارش" data-value="ثبت سفارش">' . '</button>' ); // @codingStandardsIgnoreLine ?>

</div>
