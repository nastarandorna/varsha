<?php
/**
 * Mini-cart
 *
 * Contains the markup for the mini-cart, used by the cart widget.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/mini-cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 5.2.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_mini_cart' ); ?>

<?php if ( isset( WC()->cart ) && ! WC()->cart->is_empty() ) : ?>
	<div class="reyhoon-sb-container" data-reyhoon-scroll-id="cart">
		<ul class="reyhoon-mini-cart <?php echo esc_attr( $args['list_class'] ); ?>">
			<?php
			do_action( 'woocommerce_before_mini_cart_contents' );

			foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
				$_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
				$product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

				if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
					$product_name        = apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key );
					$thumbnail           = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );
					$product_price       = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
					$product_permalink   = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
					$formatted_cart_data = wc_get_formatted_cart_item_data( $cart_item, false );
					?>
					<li class="reyhoon-mini-cart-item <?php echo esc_attr( apply_filters( 'woocommerce_mini_cart_item_class', 'mini_cart_item', $cart_item, $cart_item_key ) ); ?>">
						<div class="reyhoon-mini-cart-header">
							<?php if ( 'variation' === $_product->get_type() || ! empty( $cart_item['reyhoon_fields'] ) ) : ?>
                                <button
                                        class="reyhoon-button reyhoon-edit-cart-item__button reyhoon-button--filled"
                                        data-reyhoon-trigger="edit-cart-item"
                                        data-reyhoon-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>"
                                >
                                    <svg style="vertical-align: middle" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_111_141)">
                                            <path d="M4 20H8L18.5 9.5C19.0304 8.96956 19.3284 8.25014 19.3284 7.5C19.3284 6.74985 19.0304 6.03043 18.5 5.5C17.9696 4.96956 17.2501 4.67157 16.5 4.67157C15.7499 4.67157 15.0304 4.96956 14.5 5.5L4 16V20Z" stroke="#036666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M13.5 6.5L17.5 10.5" stroke="#036666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_111_141">
                                                <rect width="24" height="24" fill="white"/>
                                            </clipPath>
                                        </defs>
                                    </svg>

                                    <?php echo esc_html__( 'Edit', 'reyhoon' ); ?>
                                </button>
							<?php endif; ?>
                        </div>

                        <div class="reyhoon-mini-cart-content">
                            <div class="reyhoon-product__hero">
		                        <?php
		                        echo $thumbnail;
		                        ?>
                            </div>
                            <strong><?php echo wp_kses_post( $product_name ); ?></strong>



	                        <?php if ( ! empty( $formatted_cart_data ) ) { ?>
                                <div><?php echo wp_kses_post( nl2br( $formatted_cart_data ) ); ?></div>
	                        <?php } ?>

                            <div class="reyhoon-quantity-roller">
                            <span class="reyhoon-quantity-roller__price"><?php echo wp_kses_post( $product_price ); ?></span>
							<span class="reyhoon-quantity-roller__roller">
                                <button class="reyhoon-quantity-roller__button reyhoon-quantity-roller__button--increase" data-reyhoon-trigger="increase-quantity" data-reyhoon-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>" data-reyhoon-product-id="<?php echo esc_attr( $product_id ); ?>" data-reyhoon-quantity="<?php echo esc_attr( $cart_item['quantity'] ); ?>" data-max="<?= $_product->get_manage_stock() ? $_product->get_stock_quantity() :'' ?>">+</button>
								<span
                                        class="reyhoon-quantity-roller__quantity"
                                        contenteditable="true"
                                        inputmode="numeric"
                                        data-reyhoon-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>"
                                        data-reyhoon-product-id="<?php echo esc_attr( $product_id ); ?>"
                                >
									<?php echo esc_html( $cart_item['quantity'] ); ?>
								</span>
								<button class="reyhoon-quantity-roller__button reyhoon-quantity-roller__button--decrease <?php echo $cart_item['quantity'] == 1 ? 'recycle' : ''; ?>" data-reyhoon-trigger="decrease-quantity" data-reyhoon-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>" data-reyhoon-product-id="<?php echo esc_attr( $product_id ); ?>" data-reyhoon-quantity="<?php echo esc_attr( $cart_item['quantity'] ); ?>">-</button>
							</span>
                            </div>
                        </div>
					</li>
					<?php
				}
			}


			?>
		</ul>
        <?php do_action( 'woocommerce_mini_cart_contents' );?>
        <div class="cart_totals <?php echo ( WC()->customer->has_calculated_shipping() ) ? 'calculated_shipping' : ''; ?>">

			<?php do_action( 'woocommerce_before_cart_totals' ); ?>

            <!--        <h2>--><?php //esc_html_e( 'Cart totals', 'woocommerce' ); ?><!--</h2>-->

            <div class="shop_table shop_table_responsive">

                <div class="cart-subtotal">
                    <div><?php esc_html_e( 'Subtotal', 'woocommerce' ); ?></div>
                    <div data-title="<?php esc_attr_e( 'Subtotal', 'woocommerce' ); ?>"><?php wc_cart_totals_subtotal_html(); ?></div>
                </div>

                <div class="cart-static-sent">
                    <div class="cart-static-sent-pay"><?php _e("Delivery cost",'reyhoon') ?></div>
                    <div class="cart-static-sent-status"><?php _e("Unknown",'reyhoon') ?></div>
                    <div class="cart-static-sent-discription"><?php _e("هزینه ارسال کالا بر اساس تعرفه اتوپیک تپسی محاسبه شده و بر عهده مشتری می‌باشد.",'reyhoon') ?></div>
                </div>

				<?php foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>
                    <div class="cart-discount coupon-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
                        <div><?php wc_cart_totals_coupon_label( $coupon ); ?></div>
                        <div data-title="<?php echo esc_attr( wc_cart_totals_coupon_label( $coupon, false ) ); ?>"><?php wc_cart_totals_coupon_html( $coupon ); ?></div>
                    </div>
				<?php endforeach; ?>


				<?php foreach ( WC()->cart->get_fees() as $fee ) : ?>
                    <div class="fee">
                        <div><?php echo esc_html( $fee->name ); ?></div>
                        <div data-title="<?php echo esc_attr( $fee->name ); ?>"><?php wc_cart_totals_fee_html( $fee ); ?></div>
                    </div>
				<?php endforeach; ?>

				<?php
				if ( wc_tax_enabled() && ! WC()->cart->display_prices_including_tax() ) {
					$taxable_address = WC()->customer->get_taxable_address();
					$estimated_text  = '';

					if ( WC()->customer->is_customer_outside_base() && ! WC()->customer->has_calculated_shipping() ) {
						/* translators: %s location. */
						$estimated_text = sprintf( ' <small>' . esc_html__( '(estimated for %s)', 'woocommerce' ) . '</small>', WC()->countries->estimated_for_prefix( $taxable_address[0] ) . WC()->countries->countries[ $taxable_address[0] ] );
					}

					if ( 'itemized' === get_option( 'woocommerce_tax_total_display' ) ) {
						foreach ( WC()->cart->get_tax_totals() as $code => $tax ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
							?>
                            <div class="tax-rate tax-rate-<?php echo esc_attr( sanitize_title( $code ) ); ?>">
                                <div><?php echo esc_html( $tax->label ) . $estimated_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                                <div data-title="<?php echo esc_attr( $tax->label ); ?>"><?php echo wp_kses_post( $tax->formatted_amount ); ?></div>
                            </div>
							<?php
						}
					} else {
						?>
                        <div class="tax-total">
                            <div><?php echo esc_html( WC()->countries->tax_or_vat() ) . $estimated_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                            <div data-title="<?php echo esc_attr( WC()->countries->tax_or_vat() ); ?>"><?php wc_cart_totals_taxes_total_html(); ?></div>
                        </div>
						<?php
					}
				}
				?>

				<?php do_action( 'woocommerce_cart_totals_before_order_total' ); ?>

                <div class="order-total">
                    <div><?php esc_html_e( 'Total', 'woocommerce' ); ?></div>
                    <div data-title="<?php esc_attr_e( 'Total', 'woocommerce' ); ?>"><?php wc_cart_totals_order_total_html(); ?></div>
                </div>

				<?php do_action( 'woocommerce_cart_totals_after_order_total' ); ?>

            </div>

			<?php do_action( 'woocommerce_after_cart_totals' ); ?>

        </div>
	</div>

	<?php if ( Reyhoon_Helpers::has_notices() ) { ?>
		<div class="reyhoon-mini-cart__notices">
			<?php wc_print_notices(); ?>
		</div>
	<?php } ?>

	<?php do_action( 'woocommerce_widget_shopping_cart_before_total' ); ?>




	<?php do_action( 'woocommerce_widget_shopping_cart_before_buttons' ); ?>
	<?php do_action( 'woocommerce_widget_shopping_cart_after_buttons' ); ?>


    <a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="checkout-button button alt wc-forward">
        <div>
	        <?php
            echo '<strong> '.__("Total bill",'reyhoon').' </strong> ' . WC()->cart->get_cart_subtotal(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	        ?>
        </div>
	    <div>
		    <span><?php __("Complete purchase",'reyhoon') ?></span>
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_126_207)">
                    <path d="M9 18H30" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M9 18L15 24" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M9 18L15 12" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </g>
                <defs>
                    <clipPath id="clip0_126_207">
                        <rect width="36" height="36" fill="white"/>
                    </clipPath>
                </defs>
            </svg>
        </div>

    </a>



<?php else : ?>

	<p class="reyhoon-mini-cart__empty-message">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clip-path="url(#clip0_1397_52)">
                <path d="M12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21Z" stroke="#FFB901" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M12 8H12.01" stroke="#FFB901" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M11 12H12V16H13" stroke="#FFB901" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </g>
            <defs>
                <clipPath id="clip0_1397_52">
                    <rect width="24" height="24" fill="white"/>
                </clipPath>
            </defs>
        </svg>
        <?php _e("You haven't placed an order yet.",'reyhoon') ?>
    </p>

    <div class="cart-empty-background">
        <?php
        $upload_img=Reyhoon_Settings::get_setting('translate_translate_upload_img');
        echo $upload_img ? "<img src='$upload_img' style='max-width:765px;'>" :   Reyhoon_Helpers::echo_svg('cart-empty-background');
        ?>
    </div>

    <a href="<?= home_url(); ?>" class="empty-cart-btn"><?php _e("Return to the main menu",'reyhoon') ?></a>

<?php endif; ?>

<?php do_action( 'woocommerce_after_mini_cart' ); ?>
