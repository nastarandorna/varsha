<?php
/**
 * Template: Product Card Content.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/card-content.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 *
 * @var WC_Product_Variable $product Product.
 */

defined( 'ABSPATH' ) || exit;

$short_description = wp_strip_all_tags( apply_filters( 'reyhoon_short_description', $product->get_description(), $product ) );
$linkstat = rwmb_meta( 'linkstatselect_linke', array( 'object_type' => 'post' ), $product->get_id() );
if(!isset($linkstat)){
    $linkstat=0;
}
?>

<div class="reyhoon-product__content"
    <?php if ( ! empty( $args['card_click'] ) ) { ?>
        data-reyhoon-trigger="<?php echo esc_attr( $args['card_click'] ); ?>"
        data-reyhoon-product-id="<?php echo esc_attr($product->is_type('variation') ? $product->get_parent_id() : $product->get_id()); ?>"
    <?php } ?>
>
    <?php if($linkstat == 1) { ?>
        <?php $plink = "http://papichfood.com/?p=" . $product->get_id(); ?>
        <a href='<?php echo esc_url($plink); ?>' class="reyhoon-product__title-link">
            <h2 class="reyhoon-product__title"><?php echo esc_html($product->get_name()); ?></h2>
        </a>
    <?php } else { ?>
        <h2 class="reyhoon-product__title reyhoon-product__title-link"><?php echo esc_html($product->get_name()); ?></h2>
    <?php } ?>

    <?php if ( ! empty( $short_description ) && '&nbsp;' !== $short_description ) { ?>

    <?php } ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.reyhoon-product__title-link').forEach(function(title) {
                title.addEventListener('click', function() {
                

                });
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.reyhoon-product__title').forEach(function(title) {
                const maxCharacters = 25; // تعداد کاراکترهای مجاز برای عنوان کامل
                const originalFontSize = 20; // اندازه فونت اولیه

                // بررسی طول متن عنوان
                if (title.textContent.length > maxCharacters) {
                    title.style.fontSize = `${originalFontSize - 5}px`; // کاهش اندازه فونت
                }
            });
        });
    </script>


</div>
