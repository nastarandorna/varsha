<?php
/**
 * Template: Product Actions.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/actions.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 *
 * @var WC_Product_Variable $product Product.
 */

defined('ABSPATH') || exit;
?>
<?php if ($product->is_type('variable')) { ?>
    <div class="<?php echo empty($cart_item_key) ? 'reyhoon-product__actions' : 'reyhoon-product__actions__update'; ?> variable">
        <?php
        $available_variations = $product->get_available_variations();
        foreach ($available_variations as $key) {
            $variation = new WC_Product_Variation($key['variation_id']); ?>
            <div class="reyhoon-variable__actions">
                <?php if (empty($cart_item_key)) { ?>
                    <div class="reyhoon-product__actions-price">
                        <span class="variation-name"><?php echo wc_get_formatted_variation($variation, true, false, false); ?></span>
                        <?php echo $variation->get_price_html(); ?>
                    </div>
                <?php } ?>
                <div class="reyhoon-product__actions-button">
                    <?php
                    if (empty($cart_item_key)) {
                        echo Reyhoon_Products::get_add_to_cart_button($variation, 'reyhoon-product__add-to-order');
                    } else {
                        echo Reyhoon_Products::get_update_cart_item_button($cart_item_key, $variation, 'reyhoon-product__update-cart-item reyhoon-button--filled');
                    }
                    ?>
                </div>
            </div>
        <?php } ?>
    </div>
<?php } else {
    include Reyhoon_Helpers::get_template_path('templates/product/actions.php');
}


