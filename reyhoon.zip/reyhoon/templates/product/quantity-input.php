<span class="reyhoon-quantity-roller__roller">
                                <button class="reyhoon-quantity-roller__button reyhoon-quantity-roller__button--increase"
                                        data-type="increase"
										data-reyhoon-trigger="increase-quantity"
										data-reyhoon-quantity="<?= $in_cart_value > 0 ? $in_cart_value : 0 ?>"
										data-reyhoon-cart-item-key="<?php echo esc_attr( $item_key ); ?>"
										data-reyhoon-product-id="<?php echo esc_attr( $product_id ); ?>"
										data-max="<?= $product->get_manage_stock() ? $product->get_stock_quantity() :'' ?>"
								>+</button>
								<span class="reyhoon-quantity-roller__quantity"
									  contenteditable="true"
									  inputmode="numeric"

									  data-reyhoon-product-id="<?php echo esc_attr( $product_id ); ?>"
									  data-reyhoon-cart-item-key="<?php echo esc_attr( $item_key ); ?>"
								>
									<?php echo esc_html($in_cart_value); ?>
								</span>
								<button class="reyhoon-quantity-roller__button reyhoon-quantity-roller__button--decrease <?php echo $in_cart_value == 1 ? 'recycle' : ''; ?>"
                                        data-type="decrease"
										data-reyhoon-trigger="decrease-quantity"
										data-reyhoon-quantity="<?= $in_cart_value > 0 ? $in_cart_value : 0 ?>"
										data-reyhoon-cart-item-key="<?php echo esc_attr( $item_key ); ?>"
										data-reyhoon-product-id="<?php echo esc_attr( $product_id ); ?>"
								>-</button>
</span>
