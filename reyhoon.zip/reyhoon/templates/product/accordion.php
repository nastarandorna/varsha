<?php
/**
 * Template: Pro modal.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/accordion.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 *
 * @var WC_Product_Variable $product Product.
 * @var array               $args    Array of args.
 */

defined( 'ABSPATH' ) || exit;


if ( empty( $product->get_description() ) ) {
	return;
}
?>

<div class="reyhoon-accordion">
    <?php echo do_shortcode($product->get_description()) ?>
</div>
