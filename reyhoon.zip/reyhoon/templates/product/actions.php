<?php
/**
 * Template: Product Actions.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/actions.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 *
 * @var WC_Product_Variable $product Product.
 */

defined( 'ABSPATH' ) || exit;


?>

<div class="<?php echo empty( $cart_item_key ) ?  'reyhoon-product__actions' :  'reyhoon-product__actions__update'; ?>">
    <?php
    if ( empty( $cart_item_key ) ) {?>
        <div class="reyhoon-product__actions-price">
            <?php echo $product->get_price_html(); ?>
        </div>

        <?php
    }
    ?>
    <div class="reyhoon-product__actions-button">
        <?php
        if ( empty( $cart_item_key ) ) {
            echo Reyhoon_Products::get_add_to_cart_button( $product, 'reyhoon-product__add-to-order');
        } else {
            echo Reyhoon_Products::get_update_cart_item_button( $cart_item_key, $product, 'reyhoon-product__update-cart-item reyhoon-button--filled' );
        }
        ?>
    </div>

</div>
<?php


$vs ="DAILY";
$value = rwmb_meta( 'vahidselectselect_stat', array( 'object_type' => 'post' ), $product->get_id() );
if(isset($value) && $value =="vip"){
    $vs ="بزرگ";
    echo '<div class="arsha-product-stat1">';
    echo '<i class="qtip tip-right" data-tip="پارتی پک بزرگ مخصوص">';
    echo $vs;
    echo '</i>';
    echo "</div>";
}elseif (isset($value) && $value =="eco"){
    $vs ="کوچک";
    echo '<div class="arsha-product-stat2">';
    echo '<i class="qtip tip-right" data-tip="پارتی پک کوچک مقرون به صرفه">';
    echo $vs;
    echo '</i>';
    echo "</div>";
}elseif (isset($value) && $value =="daily"){
    $vs ="روزانه";
    echo '<div class="arsha-product-stat">';
    echo '<i class="qtip tip-right" data-tip="پارتی پک های فینگر فود پر قروش روزانه">';
    echo $vs;
    echo '</i>';
    echo "</div>";


}elseif (isset($value) && $value =="s1"){
    $vs ="تک نفره";
    echo '<div class="arsha-product-stat">';
    echo '<i class="qtip tip-right" data-tip="این محصول برای یک نفر مناسب میباشد">';
    echo $vs;
    echo '</i>';
    echo "</div>";


}elseif (isset($value) && $value =="s2"){
    $vs ="دو نفره";
    echo '<div class="arsha-product-stat1">';
    echo '<i class="qtip tip-right" data-tip="پارتی پک بزرگ مخصوص">';
    echo $vs;
    echo '</i>';
    echo "</div>";


}elseif (isset($value) && $value =="s3"){
    $vs ="خانوادگی";
    echo '<div class="arsha-product-stat2">';
    echo '<i class="qtip tip-right" data-tip="غذای پرسی مناسب برای خانواده>';
    echo $vs;
    echo '</i>';
    echo "</div>";


}else{
    $vs ="روزانه";
    echo '<div class="arsha-product-stat">';
    echo '<i class="qtip tip-right" data-tip="پارتی پک فینگر فود پر قروش روزانه">';
    echo $vs;
    echo '</i>';
    echo "</div>";

}
?>



