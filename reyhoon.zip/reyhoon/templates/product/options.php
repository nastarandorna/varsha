<?php
/**
 * Template: Product Options.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/options.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 *
 * @var WC_Product $product Product.
 * @var bool $reyhoon_single_product Determines whether it's possible to add to cart (i.e. a single product view).
 * @var array $args Array of args.
 */

defined('ABSPATH') || exit;

global $reyhoon_single_product;

$reyhoon_single_product = true; ?>
<button class="reyhoon-drawer__close" data-reyhoon-trigger="drawer.close">
    <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g clip-path="url(#clip0_64_27)">
            <path d="M7.5 18H28.5" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M7.5 18L16.5 27" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M7.5 18L16.5 9" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        <defs>
            <clipPath id="clip0_64_27">
                <rect width="36" height="36" fill="white"/>
            </clipPath>
        </defs>
    </svg>
</button>

<div class="reyhoon-product reyhoon-product--options reyhoon-product--image-cropped">


    <div class="reyhoon-sb-container" data-reyhoon-scroll-id="product">

        <?php include Reyhoon_Helpers::get_template_path('templates/product/hero.php'); ?>

        <?php do_action('reyhoon_side_menu_before_product_title', $product, $args); ?>

        <h2 class="reyhoon-product__title"><?php echo wp_kses_post($product->get_name()); ?></h2>

        <?php do_action('reyhoon_side_menu_before_product_options_wrapper', $product, $args); ?>

        <div class="reyhoon-product__options-wrap">
            <?php do_action('reyhoon_side_menu_before_product_options', $product, $args); ?>

            <?php if (!empty($attributes)) { ?>
                <table class="reyhoon-product__options" cellspacing="0" cellpadding="0">
                    <?php foreach ($attributes as $attribute_name => $options) : ?>
                        <tr class="reyhoon-product__option">
                            <th class="reyhoon-product__option-label">
                                <label
                                    for="<?php echo esc_attr(sanitize_title($attribute_name)); ?>"><?php echo wc_attribute_label($attribute_name); // WPCS: XSS ok. ?></label>
                            </th>
                            <td class="reyhoon-product__option-select">
                                <?php
                                wc_dropdown_variation_attribute_options(
                                    array(
                                        'options' => $options,
                                        'attribute' => $attribute_name,
                                        'selected' => empty($selected[wc_variation_attribute_name($attribute_name)]) ? false : $selected[wc_variation_attribute_name($attribute_name)],
                                        'product' => $product,
                                        'class' => 'reyhoon-input reyhoon-input--select reyhoon-input--validate',
                                    )
                                ); ?>
                                <div class="ryn-variations">
                                    <?php
                                    Reyhoon_Helpers::reyhoon_swach(
                                        array(
                                            'options' => $options,
                                            'attribute' => $attribute_name,
                                            'product' => $product,
                                            'class' => 'ryn-variations-container'
                                        ));
                                    ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php } ?>

            <?php do_action('reyhoon_side_menu_after_product_options', $product, $args); ?>

            <div class="reyhoon-product__messages">
            </div>

            <?php if (!empty($variations_json)) : ?>
                <script class="reyhoon-product__variations"
                        type="application/json"><?php echo $variations_json; ?></script>
            <?php endif; ?>
        </div>

        <div class="reyhoon-attr">
            <?php wc_display_product_attributes($product); ?>
        </div>

    </div>

    <?php do_action('reyhoon_side_menu_after_product_options_wrapper', $product, $args); ?>

    <?php include Reyhoon_Helpers::get_template_path('templates/product/actions.php'); ?>
</div>
