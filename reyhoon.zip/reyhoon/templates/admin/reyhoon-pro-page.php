<link rel="stylesheet" href="<?php echo esc_attr( REYHOON_ASSETS_URL ); ?>/admin/css/upgrade-pro.css">

<div class="in-pro">
    <div class="side-right">
        <div class="side-right-hero">
            <svg class="Crown" width="67" height="67" viewBox="0 0 67 67" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_1898_496)">
                    <path d="M33.5 16.75L44.6667 33.5L58.625 22.3333L53.0417 50.25H13.9583L8.375 22.3333L22.3333 33.5L33.5 16.75Z" stroke="white" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                </g>
                <defs>
                    <clipPath id="clip0_1898_496">
                        <rect width="67" height="67" fill="white"/>
                    </clipPath>
                </defs>
            </svg>
            <svg class="line" width="237" height="190" viewBox="0 0 237 190" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path opacity="0.25" d="M1 0C1 0 1 71.7666 77.4962 146.544C147.445 214.922 236 180.169 236 180.169" stroke="white"/>
            </svg>
            <span><?php _e("For those looking for better management",'reyhoon'); ?></span>
            <button type="button">
                <a href="https://reyhoon.avin-tarh.ir/pricing"><?php _e("Upgrade to the Professional Version",'reyhoon'); ?></a>
            </button>
        </div>
    </div>
    <div class="side-left">
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1798_524)">
                        <path
                                d="M24.0003 10.6665H13.3337C11.8609 10.6665 10.667 11.8604 10.667 13.3332V23.9998C10.667 25.4726 11.8609 26.6665 13.3337 26.6665H24.0003C25.4731 26.6665 26.667 25.4726 26.667 23.9998V13.3332C26.667 11.8604 25.4731 10.6665 24.0003 10.6665Z"
                                stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M18.667 45.3335V45.3602" stroke="#49B965" stroke-width="5" stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path
                                d="M50.6663 10.6665H39.9997C38.5269 10.6665 37.333 11.8604 37.333 13.3332V23.9998C37.333 25.4726 38.5269 26.6665 39.9997 26.6665H50.6663C52.1391 26.6665 53.333 25.4726 53.333 23.9998V13.3332C53.333 11.8604 52.1391 10.6665 50.6663 10.6665Z"
                                stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M18.667 18.6665V18.6932" stroke="#49B965" stroke-width="5" stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path
                                d="M24.0003 37.3335H13.3337C11.8609 37.3335 10.667 38.5274 10.667 40.0002V50.6668C10.667 52.1396 11.8609 53.3335 13.3337 53.3335H24.0003C25.4731 53.3335 26.667 52.1396 26.667 50.6668V40.0002C26.667 38.5274 25.4731 37.3335 24.0003 37.3335Z"
                                stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M45.333 18.6665V18.6932" stroke="#49B965" stroke-width="5" stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path d="M37.333 37.3335H45.333" stroke="#49B965" stroke-width="5" stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path d="M53.333 37.3335V37.3602" stroke="#49B965" stroke-width="5" stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path d="M37.333 37.3335V45.3335" stroke="#49B965" stroke-width="5" stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path d="M37.333 53.3335H45.333" stroke="#49B965" stroke-width="5" stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path d="M45.333 45.3335H53.333" stroke="#49B965" stroke-width="5" stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path d="M53.333 45.3335V53.3335" stroke="#49B965" stroke-width="5" stroke-linecap="round"
                              stroke-linejoin="round" />
                    </g>
                    <defs>
                        <clipPath id="clip0_1798_524">
                            <rect width="64" height="64" fill="white" />
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Scan from the table",'reyhoon'); ?> </p>
                <p><?php _e("(Smart Order Registration)",'reyhoon'); ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1798_558)">
                        <path d="M10.667 53.3335H53.3337" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M25.0664 26.6665H38.9331" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M20.7998 40H43.1998" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M16 53.3335L29.3333 13.3335H34.6667L48 53.3335" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_1798_558">
                            <rect width="64" height="64" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Delivery Range",'reyhoon'); ?></p>
                <p><?php _e("(Disallowing Orders Outside Delivery Range)",'reyhoon'); ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1798_583)">
                        <path d="M56 50.6665H55.9733" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M45.3333 50.6667C45.3333 47.8377 46.4571 45.1246 48.4575 43.1242C50.4579 41.1238 53.171 40 56 40" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M34.6667 50.6668C34.6667 45.0089 36.9143 39.5827 40.9151 35.5819C44.9158 31.5811 50.342 29.3335 56 29.3335" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M24.0001 50.6668H16.0001C13.8784 50.6668 11.8436 49.824 10.3433 48.3237C8.84299 46.8234 8.00014 44.7886 8.00014 42.6668V21.3335C8.00014 19.2118 8.84299 17.1769 10.3433 15.6766C11.8436 14.1764 13.8784 13.3335 16.0001 13.3335H48.0001C49.6415 13.3491 51.2384 13.8692 52.5741 14.8233C53.9098 15.7773 54.9197 17.1192 55.4668 18.6668" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_1798_583">
                            <rect width="64" height="64" fill="white" transform="matrix(-1 0 0 1 64 0)"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Displaying Live Orders",'reyhoon'); ?></p>
                <p><?php _e("(Sound Alert for Cashier)",'reyhoon'); ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1798_618)">
                        <path d="M29.334 8H56.0006V29.3333H48.0006L37.334 34.6667V29.3333H29.334V8Z" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M40.0006 42.6668V53.3335C40.0006 54.0407 39.7197 54.719 39.2196 55.2191C38.7195 55.7192 38.0412 56.0002 37.334 56.0002H16.0007C15.2934 56.0002 14.6151 55.7192 14.115 55.2191C13.6149 54.719 13.334 54.0407 13.334 53.3335V16.0002C13.334 15.2929 13.6149 14.6146 14.115 14.1145C14.6151 13.6144 15.2934 13.3335 16.0007 13.3335H21.334" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M26.666 48V48.0267" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_1798_618">
                            <rect width="64" height="64" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Mobile Login (OTP)",'reyhoon'); ?></p>
                <p><?php _e("(One-Click Login and Registration)",'reyhoon'); ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1950_474)">
                        <path d="M16.242 14.7418C17.0813 13.9028 17.6529 12.8337 17.8846 11.6697C18.1162 10.5058 17.9975 9.29932 17.5435 8.20285C17.0894 7.10639 16.3203 6.16921 15.3336 5.50984C14.3469 4.85047 13.1868 4.49854 12 4.49854C10.8132 4.49854 9.65313 4.85047 8.66639 5.50984C7.67966 6.16921 6.91062 7.10639 6.45655 8.20285C6.00248 9.29932 5.88377 10.5058 6.11542 11.6697C6.34708 12.8337 6.91871 13.9028 7.758 14.7418L12 18.9853L16.242 14.7418Z" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12 10.5V10.515" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M28.242 26.7418C29.0813 25.9028 29.6529 24.8337 29.8846 23.6697C30.1162 22.5058 29.9975 21.2993 29.5435 20.2029C29.0894 19.1064 28.3203 18.1692 27.3336 17.5098C26.3469 16.8505 25.1868 16.4985 24 16.4985C22.8132 16.4985 21.6531 16.8505 20.6664 17.5098C19.6797 18.1692 18.9106 19.1064 18.4566 20.2029C18.0025 21.2993 17.8838 22.5058 18.1154 23.6697C18.3471 24.8337 18.9187 25.9028 19.758 26.7418L24 30.9853L28.242 26.7418Z" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M24 22.5V22.515" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_1950_474">
                            <rect width="36" height="36" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Multiple Branches",'reyhoon'); ?></p>
                <p><?php _e("(Coming soon)",'reyhoon'); ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1933_530)">
                        <path d="M12 4.5H24C24.7956 4.5 25.5587 4.81607 26.1213 5.37868C26.6839 5.94129 27 6.70435 27 7.5V10.23C27.0001 11.3943 27.2712 12.5426 27.792 13.584L29.208 16.416C29.7288 17.4574 29.9999 18.6057 30 19.77V28.5C30 29.2956 29.6839 30.0587 29.1213 30.6213C28.5587 31.1839 27.7956 31.5 27 31.5H9C8.20435 31.5 7.44129 31.1839 6.87868 30.6213C6.31607 30.0587 6 29.2956 6 28.5V19.77C6.00008 18.6057 6.27124 17.4574 6.792 16.416L9 12V7.5C9 6.70435 9.31607 5.94129 9.87868 5.37868C10.4413 4.81607 11.2044 4.5 12 4.5V4.5Z" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M21 25.5C22.6569 25.5 24 24.1569 24 22.5C24 20.8431 22.6569 19.5 21 19.5C19.3431 19.5 18 20.8431 18 22.5C18 24.1569 19.3431 25.5 21 25.5Z" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M9 31.5C9.79565 31.5 10.5587 31.1839 11.1213 30.6213C11.6839 30.0587 12 29.2956 12 28.5V19.77C11.9999 18.6057 11.7288 17.4574 11.208 16.416L9 12" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M16.5 10.5H19.5" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <g clip-path="url(#clip1_1933_530)">
                            <path d="M27.5 33.875C31.0208 33.875 33.875 31.0208 33.875 27.5C33.875 23.9792 31.0208 21.125 27.5 21.125C23.9792 21.125 21.125 23.9792 21.125 27.5C21.125 31.0208 23.9792 33.875 27.5 33.875Z" fill="white" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M27.5 27.5H29.9792" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M27.5 23.9585V27.5002" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        </g>
                    </g>
                    <defs>
                        <clipPath id="clip0_1933_530">
                            <rect width="36" height="36" fill="white"/>
                        </clipPath>
                        <clipPath id="clip1_1933_530">
                            <rect width="17" height="17" fill="white" transform="translate(19 19)"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Latest Active Order on the Homepage",'reyhoon'); ?></p>
                <p><?php _e("(Quickly View and Track the Latest Order Placed)",'reyhoon'); ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1950_489)">
                        <path d="M20.4297 12.5731L23.3787 9.62262C23.0298 9.27383 22.7723 8.84438 22.629 8.37231C22.4857 7.90024 22.4611 7.40012 22.5572 6.91625C22.6534 6.43238 22.8674 5.97968 23.1803 5.59827C23.4932 5.21685 23.8953 4.91848 24.351 4.72959C24.8068 4.5407 25.3021 4.46711 25.793 4.51535C26.284 4.56359 26.7555 4.73217 27.1658 5.00615C27.576 5.28013 27.9124 5.65105 28.1451 6.08607C28.3777 6.52109 28.4995 7.00678 28.4997 7.50012C28.9932 7.49977 29.4791 7.62114 29.9144 7.8535C30.3498 8.08585 30.721 8.422 30.9954 8.83217C31.2698 9.24233 31.4387 9.71384 31.4873 10.2049C31.5358 10.696 31.4625 11.1914 31.2738 11.6474C31.0851 12.1033 30.7868 12.5057 30.4054 12.8188C30.024 13.1319 29.5713 13.3461 29.0873 13.4424C28.6033 13.5387 28.1031 13.5142 27.6309 13.3709C27.1586 13.2276 26.7291 12.9701 26.3802 12.6211L23.6502 15.3526" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M8.85565 27.8941C12.9551 31.9951 17.7056 33.8941 19.4606 32.1376C21.2186 30.3796 19.3197 25.6306 15.2187 21.5311C11.1192 17.4301 6.36865 15.5311 4.61365 17.2876C2.85565 19.0456 4.75465 23.7946 8.85565 27.8941Z" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M11.25 24L12.75 25.5" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M19.4628 32.1375C25.3203 26.2785 26.7453 18.2055 22.6443 14.106C18.5448 10.005 10.4718 11.43 4.61426 17.2875" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <g clip-path="url(#clip1_1950_489)">
                            <path d="M28 25.3335V34.6668" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M23.333 30H32.6663" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        </g>
                    </g>
                    <defs>
                        <clipPath id="clip0_1950_489">
                            <rect width="36" height="36" fill="white"/>
                        </clipPath>
                        <clipPath id="clip1_1950_489">
                            <rect width="16" height="16" fill="white" transform="translate(20 22)"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Product Add-Ons",'reyhoon'); ?></p>
                <p><?php _e("(Infinite Additional Services)",'reyhoon'); ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1950_525)">
                        <path d="M6 15V24" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M30 15V24" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M10.5 13.5H25.5V25.5C25.5 25.8978 25.342 26.2794 25.0607 26.5607C24.7794 26.842 24.3978 27 24 27H12C11.6022 27 11.2206 26.842 10.9393 26.5607C10.658 26.2794 10.5 25.8978 10.5 25.5V13.5ZM10.5 13.5C10.5 11.5109 11.2902 9.60322 12.6967 8.1967C14.1032 6.79018 16.0109 6 18 6C19.9891 6 21.8968 6.79018 23.3033 8.1967C24.7098 9.60322 25.5 11.5109 25.5 13.5" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12 4.5L13.5 7.5" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M24 4.5L22.5 7.5" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M13.5 27V31.5" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M22.5 27V31.5" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_1950_525">
                            <rect width="36" height="36" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Android App",'reyhoon'); ?></p>
                <p><?php _e("(Coming soon)",'reyhoon'); ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1950_546)">
                        <path d="M12 4.5H24C24.7956 4.5 25.5587 4.81607 26.1213 5.37868C26.6839 5.94129 27 6.70435 27 7.5V10.23C27.0001 11.3943 27.2712 12.5426 27.792 13.584L29.208 16.416C29.7288 17.4574 29.9999 18.6057 30 19.77V28.5C30 29.2956 29.6839 30.0587 29.1213 30.6213C28.5587 31.1839 27.7956 31.5 27 31.5H9C8.20435 31.5 7.44129 31.1839 6.87868 30.6213C6.31607 30.0587 6 29.2956 6 28.5V19.77C6.00008 18.6057 6.27124 17.4574 6.792 16.416L9 12V7.5C9 6.70435 9.31607 5.94129 9.87868 5.37868C10.4413 4.81607 11.2044 4.5 12 4.5V4.5Z" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M21 25.5C22.6569 25.5 24 24.1569 24 22.5C24 20.8431 22.6569 19.5 21 19.5C19.3431 19.5 18 20.8431 18 22.5C18 24.1569 19.3431 25.5 21 25.5Z" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M9 31.5C9.79565 31.5 10.5587 31.1839 11.1213 30.6213C11.6839 30.0587 12 29.2956 12 28.5V19.77C11.9999 18.6057 11.7288 17.4574 11.208 16.416L9 12" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M16.5 10.5H19.5" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_1950_546">
                            <rect width="36" height="36" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Packing Cost",'reyhoon'); ?></p>
                <p><?php _e("(Setting a Fixed Rate for Product Packaging)",'reyhoon'); ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1933_512)">
                        <path d="M27 7.5H9C7.34315 7.5 6 8.84315 6 10.5V28.5C6 30.1569 7.34315 31.5 9 31.5H27C28.6569 31.5 30 30.1569 30 28.5V10.5C30 8.84315 28.6569 7.5 27 7.5Z" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M24 4.5V10.5" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12 4.5V10.5" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M6 16.5H30" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M15 22.5H12V25.5H15V22.5Z" stroke="#49B965" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_1933_512">
                            <rect width="36" height="36" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Setting Holidays",'reyhoon'); ?></p>
                <p><?php _e("(Automatic Order Rejection)",'reyhoon') ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1798_524)">
                        <path d="M23.9993 10.6665H13.3327C11.8599 10.6665 10.666 11.8604 10.666 13.3332V23.9998C10.666 25.4726 11.8599 26.6665 13.3327 26.6665H23.9993C25.4721 26.6665 26.666 25.4726 26.666 23.9998V13.3332C26.666 11.8604 25.4721 10.6665 23.9993 10.6665Z" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M18.666 45.3335V45.3602" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M50.6673 10.6665H40.0007C38.5279 10.6665 37.334 11.8604 37.334 13.3332V23.9998C37.334 25.4726 38.5279 26.6665 40.0007 26.6665H50.6673C52.1401 26.6665 53.334 25.4726 53.334 23.9998V13.3332C53.334 11.8604 52.1401 10.6665 50.6673 10.6665Z" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M18.666 18.6665V18.6932" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M23.9993 37.3335H13.3327C11.8599 37.3335 10.666 38.5274 10.666 40.0002V50.6668C10.666 52.1396 11.8599 53.3335 13.3327 53.3335H23.9993C25.4721 53.3335 26.666 52.1396 26.666 50.6668V40.0002C26.666 38.5274 25.4721 37.3335 23.9993 37.3335Z" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M45.334 18.6665V18.6932" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M37.334 37.3335H45.334" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M53.334 37.3335V37.3602" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M37.334 37.3335V45.3335" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M37.334 53.3335H45.334" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M45.334 45.3335H53.334" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M53.334 45.3335V53.3335" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_1798_524">
                            <rect width="64" height="64" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Daily Special",'reyhoon'); ?></p>
                <p><?php _e("(Limiting Food to Specific Days)",'reyhoon'); ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1798_607)">
                        <path d="M34.6667 29.3335C34.6667 35.2268 28.696 40.0002 21.3333 40.0002C13.9707 40.0002 8 35.2268 8 29.3335C8 34.9914 10.2476 40.4177 14.2484 44.4184C18.2492 48.4192 23.6754 50.6668 29.3333 50.6668C34.9913 50.6668 40.4175 48.4192 44.4183 44.4184C48.4191 40.4177 50.6667 34.9914 50.6667 29.3335C50.6667 27.2118 49.8238 25.1769 48.3235 23.6766C46.8232 22.1763 44.7884 21.3335 42.6667 21.3335C40.5449 21.3335 38.5101 22.1763 37.0098 23.6766C35.5095 25.1769 34.6667 27.2118 34.6667 29.3335Z" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M42.667 21.3332C42.667 15.9998 48.0003 10.6665 53.3337 10.6665" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_1798_607">
                            <rect width="64" height="64" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Extra Food Service",'reyhoon'); ?></p>
                <p><?php _e("(Defining Custom Fields for Products)",'reyhoon'); ?></p>
            </div>
        </div>
        <div class="box-icon">
            <div class="icon-container">
                <svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_1798_571)">
                        <path d="M13.334 29.3335H50.6673V21.3335H13.334V29.3335Z" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M46.6673 29.3335L42.6673 56.0002H21.334L17.334 29.3335" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M16 21.3335V18.6668C16 17.2523 16.5619 15.8958 17.5621 14.8956C18.5623 13.8954 19.9188 13.3335 21.3333 13.3335H42.6667C44.0812 13.3335 45.4377 13.8954 46.4379 14.8956C47.4381 15.8958 48 17.2523 48 18.6668V21.3335" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M40 13.3333V8" stroke="#49B965" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_1798_571">
                            <rect width="64" height="64" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
            </div>
            <div class="text-container">
                <p><?php _e("Salad and Beverage?",'reyhoon'); ?></p>
                <p><?php _e("(Recommendations in the Shopping Cart)",'reyhoon'); ?></p>
            </div>
        </div>
    </div>
</div>
