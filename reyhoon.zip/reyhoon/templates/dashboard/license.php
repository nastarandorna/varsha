<?php

$action = trb_Product;
do_action("render_lic_form_{$action}");

?>
