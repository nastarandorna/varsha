<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<div class="min-h-screen relative w-full flex items-center justify-center bg-gray-light overflow-hidden ghab-font">

    <!-- Blur Circle Start -->
    <div class="absolute -right-16 -bottom-16 rounded-full filter blur-3xl w-80 h-80 bg-blue"></div>
    <div class="absolute -top-36 rounded-full filter blur-3xl w-96 h-96 bg-purple"></div>
    <div class="absolute -left-48 rounded-full filter blur-3xl w-100 h-96 bg-green"></div>
    <!-- Blur Circle End -->

    <!-- Main Container Start -->
    <div class="grid grid-cols-1 gap-4 z-10 md:grid-cols-2">

        <!-- License Start -->
        <div class="bg-white relative bg-opacity-60 rounded-xl p-10 text-center">
            <?php include('license.php'); ?>
        </div>
        <!-- License End -->

        <!-- FAQ Start -->
        <div class="relative overflow-hidden flex-1 h-60 bg-white bg-opacity-60 rounded-xl p-10">
            <?php include('faq.php'); ?>
        </div>
        <!-- FAQ End -->

        <div class="flex flex-col md:flex-row">

            <!-- FeedBack Start -->
            <?php include('feedback.php'); ?>
            <!-- FeedBack End -->

            <!-- Poll Start -->
            <?php include('poll.php'); ?>
            <!-- Poll End -->

        </div>

    </div>
    <!-- Main Container End -->

</div>
