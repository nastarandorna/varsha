<?php
?>
<a href="<?= add_query_arg(['update_json' => 'true']) ?>"
   class="transform transition px-9 py-3 bg-gray-dark rounded-xl text-white mt-8 hover:-translate-y-1"><?php _e("Update API",'reyhoon'); ?>/a>
