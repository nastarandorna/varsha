<?php
/**
 * Template: Product Hero.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/hero.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 *
 * @var WC_Product_Variable $product Product.
 * @var array               $args Array of args for the shortcode.
 */

defined( 'ABSPATH' ) || exit;

if ( ! $args['images'] ) {
    return;
}




// دریافت URL ویدئو از متاباکس
//$video_url = rwmb_meta('videosh_video_shakhes', '', $product->get_id());
$product_id = $product->get_id();

// دریافت URL ویدئو از متاباکس
$video_meta = rwmb_meta('videoshvideo_shakhes', ['object_type' => 'post'], $product->get_id());
//$video_meta = rwmb_meta('videosh_video_shakhes', ['object_type' => 'post'], $product_id);

//$video_url = get_post_meta($product_id, 'videosh_video_shakhes', true);
// تعیین نوع ویدئو بر اساس پسوند فایل
$video_url = '';
if (is_array($video_meta)) {
    // در صورتی که یک آرایه شامل URL ها باشد
    foreach ($video_meta as $single_video_meta) {
        if (isset($single_video_meta['src'])) {
            $video_url = $single_video_meta['src'];
            break;
        }
    }
} elseif (is_string($video_meta)) {
    // در صورتی که مستقیماً یک رشته باشد
    $video_url = $video_meta;
}

$video_type = '';

if ($video_url) {
    $file_extension = pathinfo($video_url, PATHINFO_EXTENSION);
    if ($file_extension == 'mp4') {
        $video_type = 'video/mp4';
    } elseif ($file_extension == 'webm') {
        $video_type = 'video/webm';
    }
}
//$video_url = rwmb_meta( 'videoshvideo_shakhes', array( 'object_type' => 'post' ), $product->get_id() );


?>

<video id="background-video">

    <source src="<?php echo esc_url($video_url); ?>" type="<?php echo esc_attr($video_type); ?>">

</video>

<div class="reyhoon-product__hero">

    <?php do_action( 'reyhoon_before_product_hero', $product, $args ); ?>



    <?php do_action( 'reyhoon_after_product_hero', $product, $args ); ?>

</div>
