<?php
/**
 * Template: Product Hero.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/hero.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 *
 * @var WC_Product_Variable $product Product.
 * @var array               $args Array of args for the shortcode.
 */

defined( 'ABSPATH' ) || exit;

if ( ! $args['images'] ) {
    return;
}
?>

<div class="reyhoon-product__hero">
    <div class="product-image-container">
        <?php do_action( 'reyhoon_before_product_hero', $product, $args ); ?>

        <?php echo $product->get_image( 'woocommerce_thumbnail', array(
            'class' => 'reyhoon-product__image product-image',
        ) ); ?>

        <?php do_action( 'reyhoon_after_product_hero', $product, $args ); ?>
    </div>
</div>
