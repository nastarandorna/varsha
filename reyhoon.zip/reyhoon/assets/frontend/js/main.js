if ("serviceWorker" in navigator) {
    navigator.serviceWorker
        .register("sw.js")
        .then(function (res) {
            console.log('service worker registered...')
        })
        .catch(function (e) {
            console.log(e.message);
        });
}

(function ($, document) {
    "use strict";
    var reyhoon_drawer = {
        /**
         * Delays invoking function
         *
         * @param {Function} func The function to debounce.
         * @param {number} timeout The number of milliseconds to delay.
         * @returns {Function} Returns the new debounced function.
         */
        debounce: function (func, timeout = 700) {
            let timer;

            return (...args) => {
                clearTimeout(timer);
                timer = setTimeout(() => {
                    func.apply(this, args);
                }, timeout);
            };
        },

        /**
         * Allow only number for events like keypress
         *
         * @param {Event} event
         */
        allow_only_numbers: function (event) {
            const value = String.fromCharCode(event.which);

            if (!/^\d+$/.test(value)) {
                event.preventDefault();
            }
        },

        /**
         * Send a request to change the quantity.
         *
         * @param {Event} event
         */
        on_change_quantity: function (event) {
            const quantityElement = $(event.currentTarget);

            const product_id = quantityElement.data('reyhoon-product-id');
            const cart_item_key = quantityElement.data('reyhoon-cart-item-key');
            const quantity = parseInt(quantityElement.text());

            var data = {
                'action': 'reyhoon_cart_quantity',
                cart_item_key,
                product_id,
                quantity
            };

            jQuery.post(
                reyhoon_vars.ajax_url,
                data,
                function (response) {
                    if (!response) {
                        return;
                    }

                    $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, quantityElement]);
                    $(document.body).trigger('reyhoon-drawer.quantity-updated');
                }
            );
        },

        /**
         * On doc ready.
         */
        on_ready: function () {
            reyhoon_drawer.cache();
            reyhoon_drawer.watch();
            /**
             * Handle manually changing the quantity of a product.
             */
            $(document.body).on('keypress', '.reyhoon-quantity-roller__quantity', reyhoon_drawer.allow_only_numbers);
            $('.reyhoon-drawer__cart').on('input', '.reyhoon-quantity-roller__quantity', reyhoon_drawer.debounce(reyhoon_drawer.on_change_quantity));
            $('.reyhoon-product__actions').on('input', '.loop-qty .reyhoon-quantity-roller__quantity', reyhoon_drawer.debounce(reyhoon_drawer.on_change_quantity));

            /**
             * We turn off the click event for .add_to_cart_button elements
             * to keep the AJAX behaviour only on Mini cart when the option
             * "Enable AJAX add to cart buttons on archives" is disabled.
             */
            if (reyhoon_vars && !reyhoon_vars.woocommerce_enable_ajax_add_to_cart) {
                $(document.body).off('click', '.add_to_cart_button');
            }
        },

        /**
         * Cache.
         */
        cache: function () {
            reyhoon_drawer.vars = {
                classes: {
                    overlay: 'reyhoon-drawer-overlay',
                    drawer: 'reyhoon-drawer',
                    drawer_cart: 'reyhoon-drawer__cart',
                    drawer_html: 'reyhoon-drawer__html',
                    overlay_open: 'reyhoon-drawer-overlay--open',
                    drawer_open: 'reyhoon-drawer--open',
                    drawer_open_body: 'reyhoon-drawer-open'
                }
            };

            reyhoon_drawer.elements = {
                body: $('body'),
                overlay: $('.' + reyhoon_drawer.vars.classes.overlay),
                drawer: $('.' + reyhoon_drawer.vars.classes.drawer),
                drawer_cart: $('.' + reyhoon_drawer.vars.classes.drawer_cart),
                drawer_html: $('.' + reyhoon_drawer.vars.classes.drawer_html),
                floating_cart_button_class: '.reyhoon-floating-cart__button'
            };
        },

        fullClickableAddCart: function () {
            $('.reyhoon-drawer .reyhoon-product__actions-price').click(function () {
                $(this).parent().find('button').click();
            })
        },

        fullClickableUpdate: function () {
            $('.reyhoon-product__actions__update .reyhoon-product__actions-button__save-update .reyhoon-product__actions-price').click(function () {
                $(this).parent().find('button').click();
            })
        },

        /**
         * Watch for trigger events.
         */
        watch: function () {
            if (typeof reyhoon_drawer.elements.drawer === 'undefined') {
                return;
            }

            $(document.body).on('reyhoon-drawer.open', reyhoon_drawer.open);
            $(document.body).on('reyhoon-drawer.open', reyhoon_drawer.fullClickableAddCart);
            $(document.body).on('reyhoon-drawer.open', reyhoon_drawer.fullClickableUpdate);
            $(document.body).on('reyhoon-drawer.close', reyhoon_drawer.close);

            $(document.body).on('reyhoon-drawer.open', reyhoon_drawer.fixBackButton);

            $(document.body).on('click', reyhoon_drawer.elements.floating_cart_button_class, function () {
                $(document.body).trigger('reyhoon-drawer.open', {show_cart: true});
            });

            $(document.body).on('click', '.reyhoon-product--view-product .reyhoon-product__content', function () {
                $(document.body).trigger('reyhoon-view-product', $(this));
            });

            // open address drawer in checkout
            $(document.body).on('click', '.user-address-btn', function () {
                $(document.body).trigger('reyhoon-drawer.open');
            });

            $(document.body).on('reyhoon-increase-quantity', reyhoon_drawer.cart.handle_quantity_change_by_button);
            $(document.body).on('reyhoon-decrease-quantity', reyhoon_drawer.cart.handle_quantity_change_by_button);

            const updateQuantityRequest = reyhoon_drawer.debounce(reyhoon_drawer.cart.click_increase_decrease_quantity);

            $(document.body).on('reyhoon-increase-quantity', updateQuantityRequest);
            $(document.body).on('reyhoon-decrease-quantity', updateQuantityRequest);

        },

        //fix back button
        fixBackButton: function(e, args) {
            history.pushState(null, null, window.location.href + "?drawer=open");
            window.addEventListener("popstate", function(event) {
                reyhoon_drawer.close();
            });
        },

        /**
         * Open the drawer.
         */
        open: function (event, args) {
            if (typeof args !== 'undefined') {
                args.html = args.html || false;
                args.show_cart = args.show_cart || false;

                reyhoon_drawer.elements.drawer_html.hide();
                reyhoon_drawer.elements.drawer_cart.hide();

                if (args.html) {
                    reyhoon_drawer.elements.drawer_html.html(args.html);
                    reyhoon_drawer.elements.drawer_html.show();
                    if(typeof GLightbox === 'function') {
                        const lightbox = GLightbox();
                    }
                }

                if (args.show_cart) {
                    // Empty drawer HTML before showing cart. Prevents options
                    // interfering with subsequent cart additions.
                    reyhoon_drawer.elements.drawer_html.html('');
                    reyhoon_drawer.elements.drawer_cart.show();
                }
            }

            reyhoon_drawer.elements.overlay.addClass(reyhoon_drawer.vars.classes.overlay_open);
            reyhoon_drawer.elements.drawer.addClass(reyhoon_drawer.vars.classes.drawer_open);
            reyhoon_drawer.elements.body.addClass(reyhoon_drawer.vars.classes.drawer_open_body);

            $(document.body).trigger('reyhoon-drawer.opened', args);
        },

        /**
         * Close the drawer.
         */
        close: function () {
            reyhoon_drawer.elements.overlay.removeClass(reyhoon_drawer.vars.classes.overlay_open);
            reyhoon_drawer.elements.drawer.removeClass(reyhoon_drawer.vars.classes.drawer_open);
            reyhoon_drawer.elements.body.removeClass(reyhoon_drawer.vars.classes.drawer_open_body);

            reyhoon_drawer.elements.drawer_html.html('');

            history.replaceState(null, null, window.location.pathname);

            $(document.body).trigger('reyhoon-drawer.closed');
        },

        /**
         * Mini cart related functions.
         */
        cart: {
            /**
             * When increase qty is clicked.
             *
             * @param e
             * @param $button
             */
            click_increase_decrease_quantity: function (e, $button) {

                var product_id = $button.attr('data-reyhoon-product-id'),
                    cart_item_key = $button.attr('data-reyhoon-cart-item-key'),
                    quantity = $button.attr('data-reyhoon-quantity');


                var data = {
                    'action': 'reyhoon_cart_quantity',
                    cart_item_key,
                    product_id,
                    quantity
                };

                if (this.currentRequest) {
                    this.currentRequest.abort();
                    this.currentRequest = undefined;
                }

                jQuery.ajaxSetup({
                    beforeSend: function () {
                        $button.siblings('span').toggleClass(' reyhoon-button--loading');
                    },
                    complete: function () {
                        $button.siblings('span').toggleClass('reyhoon-button--loading');
                    }
                });
                var $decreasseButton = $button.hasClass('reyhoon-quantity-roller__button--decrease') ? $button : $button.siblings('.reyhoon-quantity-roller__button--decrease');
                quantity == 1 ? $decreasseButton.addClass('recycle') : $decreasseButton.removeClass('recycle');
                quantity == 0 ? $decreasseButton.attr('disabled', 'disabled') : $decreasseButton.removeAttr('disabled');

                this.currentRequest = jQuery.post(
                    reyhoon_vars.ajax_url,
                    data,
                    (function (response) {
                        if (!response) {
                            return;
                        }

                        const $quantityElement = $button.siblings('.reyhoon-quantity-roller__quantity');


                        if (data.quantity === $quantityElement.attr('data-reyhoon-updating-quantity')) {
                            $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, $button]);
                            $(document.body).trigger('reyhoon-drawer.quantity-updated');
                        }

                    }).bind(this)
                )
                    .always((function () {
                        this.currentRequest = undefined;
                    }).bind(this));
            },
            handle_quantity_change_by_button: function (e, $button) {

                const direction = $button.data('reyhoon-trigger');
                const quantity = parseInt($button.attr('data-reyhoon-quantity'));
                const maxQuantity = parseInt($button.attr('data-max'));

                const siblingButtonName = 'increase-quantity' === direction ? 'decrease' : 'increase';

                const $siblingButton = $button.siblings(`.reyhoon-quantity-roller__button--${siblingButtonName}`);
                const $productId = $siblingButton.attr('data-reyhoon-product-id');
                const $quantityElement = $button.siblings('.reyhoon-quantity-roller__quantity');

                const newQuantity = 'increase-quantity' === direction ? quantity + 1 : Math.max(0, quantity - 1);

                if (newQuantity > maxQuantity) {
                    alert('موجودی محصول کافی نیست!');
                    return;
                }
                $button.attr('data-reyhoon-quantity', newQuantity);
                $siblingButton.attr('data-reyhoon-quantity', newQuantity);
                $quantityElement.attr('data-reyhoon-updating-quantity', newQuantity);
                $quantityElement.text(newQuantity);
                const productCard = $(".reyhoon-product [data-reyhoon-product-id='" + $productId + "']").siblings('.loop-qty');
                productCard.find('.reyhoon-quantity-roller__quantity').attr('data-qty', newQuantity);
                productCard.find('.reyhoon-quantity-roller__quantity').text(newQuantity);
            }
        }
    };

    $(document).ready(reyhoon_drawer.on_ready);
}(jQuery, document));
(function ($, document) {
    "use strict";

    var reyhoon_products = {
        /**
         * On doc ready.
         */
        on_ready: function () {
            reyhoon_products.cache();
            reyhoon_products.watch();
        },

        /**
         * Cache.
         */
        cache: function () {
            reyhoon_products.vars = {
                classes: {
                    clickable_product: 'reyhoon-product--add-to-cart ',
                    add_to_order_button: 'reyhoon-product__add-to-order',
                    product_messages: 'reyhoon-product__messages',
                    product_price: 'reyhoon-product__actions-price',
                    invalid_field: 'reyhoon-field--invalid',
                    option_select_td: 'reyhoon-product__option-select',
                    button_loading: 'reyhoon-button--loading',
                    out_of_stock: 'reyhoon-button--out-of-stock'
                },
                parent_price: null
            };

            reyhoon_products.elements = {};
        },

        /**
         * Watch for trigger events.
         */
        watch: function () {
            $(document.body).on('reyhoon-drawer.opened', reyhoon_products.init_product_options);
            $(document.body).on('reyhoon-add-to-cart', reyhoon_products.click_add_to_order);
            $(document.body).on('reyhoon-product-options', reyhoon_products.click_add_to_order);
            $(document.body).on('reyhoon-view-product', reyhoon_products.view_product);
            $(document.body).on('mouseenter mouseleave', '.' + reyhoon_products.vars.classes.clickable_product, reyhoon_products.simulate_add_to_order_hover);
            $(document.body).on('reyhoon-edit-cart-item', reyhoon_products.edit_cart_item);
            $(document.body).on('reyhoon-update-cart-item', reyhoon_products.update_cart_item);
            $(document.body).on('reyhoon-show-cart', reyhoon_products.show_cart);
        },

        /**
         * Simulate hover on add to order button.
         *
         * @param event
         */
        simulate_add_to_order_hover: function (event) {
            var $element = $(this),
                $button = $element.find('.' + reyhoon_products.vars.classes.add_to_order_button);

            $button.toggleClass('reyhoon-button--hover', 'mouseenter' === event.type);
        },

        /**
         * Add to order click event.
         *
         * This event accounts for button clicks or card clicks.
         */
        click_add_to_order: function (event, $element) {
            // If undefined, it means it was triggered by a click
            // event and not the `reyhoon-add-to-cart` trigger.
            $element = typeof $element !== 'undefined' ? $element : $(this);

            // The button is either the clicked element, or the
            // add to order button within the clicked element.
            var $button = $element.is('button') ? $element : $element.find('.' + reyhoon_products.vars.classes.add_to_order_button),
                action = $button.data('reyhoon-trigger'),
                product_id = $button.data('reyhoon-product-id'),
                variation_id = $button.data('reyhoon-variation-id'),
                attributes = $button.data('reyhoon-variation-attributes'),
                args = {action: action};

            if ($button.hasClass(reyhoon_products.vars.classes.button_loading) || $button.hasClass(reyhoon_products.vars.classes.out_of_stock)) {
                return;
            }

            console.log($button)

            $button.addClass(reyhoon_products.vars.classes.button_loading);

            if ('add-to-cart' === action) {
                reyhoon_products.add_to_cart(
                    {
                        'product_id': product_id,
                        'variation_id': variation_id,
                        'attributes': attributes
                    },
                    function (response) {
                        args.show_cart = false;
                        args.response = response;

                        if (!$button.hasClass('reyhoon-cart-bumps__bump-button')) {
                            $(document.body).trigger('reyhoon-drawer.close', args);
                        }
                        $button.removeClass(reyhoon_products.vars.classes.button_loading);
                    }
                );
            } else if ('product-options' === action) {
                reyhoon_products.get_product_options(
                    {
                        'product_id': product_id,
                        'focus': $button.data('reyhoon-focus')
                    },
                    function (response) {
                        args.html = response.html;

                        $(document.body).trigger('reyhoon-drawer.open', args);
                        $button.removeClass(reyhoon_products.vars.classes.button_loading);
                    }
                );
            }
        },

        /**
         * Show the cart.
         */
        show_cart: function () {
            $(document.body).trigger('reyhoon-drawer.open', {show_cart: true});
        },

        /**
         * View product.
         *
         * @param event
         * @param $element
         */
        view_product: function (event, $element) {
            if($element.dataset === undefined) {
                return;
            }

            $($element).addClass(reyhoon_products.vars.classes.button_loading);

            var product_id = $element.dataset.reyhoonProductId,
                args = {action: 'product-options'};

            reyhoon_products.get_product_options(
                {
                    'product_id': product_id
                },
                function (response) {
                    args.html = response.html;

                    $(document.body).trigger('reyhoon-drawer.open', args);

                    $($element).removeClass(reyhoon_products.vars.classes.button_loading);
                }
            );
        },

        /**
         * Ajax add to cart.
         */
        add_to_cart: function (args, callback) {
            if (typeof args.product_id === 'undefined') {
                return;
            }

            var data = {
                'action': 'reyhoon_add_to_cart',
                'product_id': args.product_id,
                'variation_id': args.variation_id || false,
                'attributes': args.attributes || false
            };

            // Prepare addons data.
            if ($('.reyhoon-product-fields-group').length) {
                var inputs = jQuery('.reyhoon-product-fields-group :input').serializeArray();
                var addons_data = reyhoon_products.convert_to_flat_object(inputs);
                if (!jQuery.isEmptyObject(addons_data)) {
                    data = Object.assign(data, addons_data); // Merge objects.
                }
            }

            jQuery.post(
                reyhoon_vars.ajax_url,
                data,
                function (response) {
                    if (!response) {
                        return;
                    }

                    // Trigger event so themes can refresh other areas.
                    $(document.body).trigger('added_to_cart', [
                        response.fragments,
                        response.cart_hash
                    ]);

                    if (typeof callback === 'function') {
                        callback(response);
                    }
                }
            );
        },

        /**
         * Edit cart item.
         *
         * @param event
         * @param $element
         */
        edit_cart_item: function (event, $element) {
            const cart_item_key = $element.data('reyhoon-cart-item-key');

            $element.addClass(reyhoon_products.vars.classes.button_loading);

            reyhoon_products.get_cart_item_options(
                {
                    cart_item_key
                },
                function (response) {
                    const args = {
                        html: response.html,
                        action: 'update-cart-item'
                    };

                    $(document.body).trigger('reyhoon-drawer.open', args);
                    $element.removeClass(reyhoon_products.vars.classes.button_loading);
                }
            );
        },

        /**
         * Update cart item.
         *
         * @param event
         * @param $element
         */
        update_cart_item: function (event, $element) {
            const cart_item_key = $element.data('reyhoon-cart-item-key');
            const product_id = $element.data('reyhoon-product-id');
            const variation_id = $element.data('reyhoon-variation-id');
            const attributes = $element.data('reyhoon-variation-attributes');

            $element.addClass(reyhoon_products.vars.classes.button_loading);
            reyhoon_products.update_cart_item_options(
                {
                    cart_item_key,
                    product_id,
                    variation_id,
                    attributes,
                },
                function (response) {
                    const args = {
                        show_cart: true,
                        response
                    };

                    $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash]);
                    $(document.body).trigger('reyhoon-drawer.open', args);
                    $element.removeClass(reyhoon_products.vars.classes.button_loading);
                }
            );
        },

        /**
         * Convert [{name:x, value:y }] to {x:y} format.
         */
        convert_to_flat_object: function (inputs) {
            var data = {};
            inputs.forEach(function (input) {
                var is_array = '[]' === input.name.substr(-2) || Array.isArray(input.name);
                // If last 2 chars are '[]', remove them.
                var key = is_array ? input.name.substr(0, input.name.length - 2) : input.name;

                if (is_array) {
                    data[key] = typeof data[key] === 'undefined' ? [] : data[key];
                    data[key].push(input.value);
                } else {
                    data[key] = input.value;
                }
            });

            return data;
        },

        /**
         * Get variable product options.
         *
         * @param args
         * @param callback
         */
        get_product_options: function (args, callback) {
            if (typeof args.product_id === 'undefined') {
                return;
            }

            args.action = 'reyhoon_get_product_options';

            jQuery.post(
                reyhoon_vars.ajax_url,
                args,
                function (response) {
                    if (!response.success) {
                        return;
                    }

                    if (typeof callback === 'function') {
                        callback(response.data);
                    }
                }
            );
        },

        /**
         * Get variable product options.
         *
         * @param args
         * @param callback
         */
        get_cart_item_options: function (args, callback) {
            if (typeof args.cart_item_key === 'undefined') {
                return;
            }

            args.action = 'reyhoon_get_cart_item_options';

            jQuery.post(
                reyhoon_vars.ajax_url,
                args,
                function (response) {
                    if (!response.success) {
                        return;
                    }

                    if (typeof callback === 'function') {
                        callback(response.data);
                    }
                }
            );
        },

        /**
         * Update variable product options.
         *
         * @param args
         * @param callback
         */
        update_cart_item_options: function (args, callback) {
            if (typeof args.cart_item_key === 'undefined') {
                return;
            }

            args.action = 'reyhoon_update_cart_item_options';

            // Prepare addons data.
            if ($('.reyhoon-product-fields-group').length) {
                const inputs = jQuery('.reyhoon-product-fields-group :input').serializeArray();
                const addons_data = reyhoon_products.convert_to_flat_object(inputs);
                if (!jQuery.isEmptyObject(addons_data)) {
                    args = Object.assign(args, addons_data); // Merge objects.
                }
            }

            jQuery.post(
                reyhoon_vars.ajax_url,
                args,
                function (response) {
                    if (!response) {
                        return;
                    }

                    if (typeof callback === 'function') {
                        callback(response);
                    }
                }
            );
        },

        /**
         * Init drawer product options.
         *
         * @param event
         * @param args
         */
        init_product_options: function (event, args) {
            if (typeof args == 'undefined' || typeof args.action === 'undefined' || ('product-options' !== args.action && 'update-cart-item' !== args.action)) {
                return;
            }

            var selectors = '.reyhoon-drawer .reyhoon-product__options input, .reyhoon-drawer .reyhoon-product__options select';
            var $options = $(selectors);

            reyhoon_products.vars.parent_price = $('.reyhoon-drawer .reyhoon-product__actions-price').html();

            reyhoon_products.product_options_change($options);
            reyhoon_products.update_button_state();

            var debounced_update_button_state = reyhoon_products.debounce(reyhoon_products.update_button_state, 500);
            var debounced_product_options_change = reyhoon_products.debounce(reyhoon_products.product_options_change, 500);
            $(document).on('change keyup', selectors, function () {
                debounced_product_options_change($options);
                debounced_update_button_state();
            });
        },

        /**
         * On product options change.
         *
         * @param $options
         */
        product_options_change: function ($options) {
            var $add_to_order_button = $('.reyhoon-drawer .reyhoon-product__add-to-order, .reyhoon-drawer .reyhoon-product__update-cart-item'),
                options_set = reyhoon_products.check_options($options),
                product_type = $add_to_order_button.data('reyhoon-product-type');

            if ('product-options' === $add_to_order_button.attr('data-reyhoon-trigger')) {
                $add_to_order_button.attr('data-reyhoon-trigger', 'add-to-cart');
            }

            $('.' + reyhoon_products.vars.classes.product_messages).html('');

            if ('variable' !== product_type) {
                return;
            }

            if (!options_set) {
                reyhoon_products.clear_variation($add_to_order_button);
                return;
            }

            var variation = reyhoon_products.check_variation($options);

            reyhoon_products.set_variation($add_to_order_button, variation);
        },

        /**
         * Check if all product options are set.
         *
         * @param $options
         * @returns {boolean}
         */
        check_options: function ($options) {
            if ($options.length <= 0) {
                return false;
            }

            var all_set = true;

            $options.each(function (index, option) {
                // Only check attribute fields.
                if (!$(option).hasClass('reyhoon-input--validate')) {
                    return;
                }

                if ('' === $(option).val()) {
                    $(option).addClass(reyhoon_products.vars.classes.invalid_field);
                    all_set = false;
                } else {
                    $(option).removeClass(reyhoon_products.vars.classes.invalid_field);
                }
            });

            return all_set;
        },

        /**
         * Check if variation has been selected.
         */
        check_variation: function ($options) {
            var $product = $options.closest('.reyhoon-drawer');

            var variations = $product.find('.reyhoon-product__variations').text();

            variations = variations ? JSON.parse(variations) : '';

            var selected_options = reyhoon_products.serialize_object($options),
                matching_variations = reyhoon_products.find_matching_variations(variations, selected_options);

            if (reyhoon_products.is_empty(matching_variations)) {
                return false;
            }

            var variation = matching_variations.shift();

            variation.attributes = selected_options;
            variation.attributes_json = JSON.stringify(selected_options);

            return typeof variation !== 'undefined' ? variation : false;
        },

        /**
         * Set variation for add to cart button.
         */
        set_variation: function ($button, variation) {
            var variation_id = variation.variation_id || '',
                attributes = variation.attributes_json || '',
                price = variation.price_html || reyhoon_products.vars.parent_price,
                message = '';

            if (variation && '' !== variation.availability_html) {
                message = variation.availability_html;
            }

            if (variation && !variation.is_in_stock) {
                message = '<p>' + reyhoon_vars.i18n.out_of_stock + '</p>';
            }

            if (variation && !variation.is_purchasable) {
                message = '<p>' + reyhoon_vars.i18n.unavailable + '</p>';
            }

            if (false === variation) {
                message = '<p>' + reyhoon_vars.i18n.no_exist + '</p>';
            }

            if (variation && (!variation.is_purchasable || !variation.is_in_stock)) {
                variation_id = '';
                attributes = '';
            }

            if ('' !== message) {
                $('.' + reyhoon_products.vars.classes.product_messages).html(message);
            }

            $button.data('reyhoon-variation-id', variation_id);
            $button.data('reyhoon-variation-attributes', attributes);
            $('.reyhoon-drawer .reyhoon-product__actions-price').html(price);

            $button.trigger('reyhoon_variation_set', {
                variation: variation,
                variation_id: variation_id,
                attributes: attributes,
                price: price
            });
        },

        /**
         * Clear variation and disable add to order.
         *
         * @param $button
         */
        clear_variation: function ($button) {
            reyhoon_products.set_variation($button, '');

            if (reyhoon_products.vars.parent_price) {
                $('.reyhoon-drawer .reyhoon-product__actions-price').html(reyhoon_products.vars.parent_price);
            }
        },

        /**
         * Find matching variations for attributes.
         */
        find_matching_variations: function (variations, attributes) {
            var matching = [];

            for (var i = 0; i < variations.length; i++) {
                var variation = variations[i];

                if (reyhoon_products.is_matching_variation(variation.attributes, attributes)) {
                    matching.push(variation);
                }
            }

            return matching;
        },

        /**
         * See if attributes match.
         * @return {Boolean}
         */
        is_matching_variation: function (variation_attributes, attributes) {
            var match = true;

            for (var attr_name in variation_attributes) {
                if (variation_attributes.hasOwnProperty(attr_name)) {
                    var val1 = variation_attributes[attr_name];
                    var val2 = attributes[attr_name];
                    if (val1 !== undefined && val2 !== undefined && val1.length !== 0 && val2.length !== 0 && val1 !== val2) {
                        match = false;
                    }
                }
            }

            return match;
        },

        /**
         * Is value empty?
         *
         * @param value
         * @returns {boolean}
         */
        is_empty: function (value) {
            return typeof value === 'undefined' || false === value || value.length <= 0 || !value;
        },

        /**
         * Serialize into a key/value object.
         *
         * @param $elements
         * @returns {{}}
         */
        serialize_object: function objectifyForm($elements) {
            var serialized = $elements.serializeArray(),
                return_object = {};

            for (var i = 0; i < serialized.length; i++) {
                return_object[serialized[i].name] = serialized[i].value;
            }
            return return_object;
        },

        /**
         * Disable/Enable the 'Add to cart' button based on the presence of reyhoon-field--invalid class.
         */
        update_button_state: function () {
            // Add delay to ensure invalid class has been assigned to inputs.
            setTimeout(function () {
                var $button = $('.reyhoon-drawer .reyhoon-product__add-to-order, .reyhoon-drawer .reyhoon-product__update-cart-item'),
                    invalid_fields_count = $('.reyhoon-drawer__html .' + reyhoon_products.vars.classes.invalid_field).length,
                    product_type = $button.data('reyhoon-product-type'),
                    has_variation_id = true;

                if ('variable' === product_type) {
                    has_variation_id = '' !== $button.data('reyhoon-variation-id');
                }

                $button.prop('disabled', invalid_fields_count || !has_variation_id);
            }, 50);
        },

        /**
         * Debounce function.
         *
         * @param func      Function to debounce.
         * @param wait      Time to wait in milliseconds.
         * @param immediate Trigger the function on the leading edge, instead of the trailing.
         *
         * @returns
         */
        debounce: function (func, wait, immediate) {
            var timeout;
            return function () {
                var context = this,
                    args = arguments;
                var later = function () {
                    timeout = null;
                    if (!immediate) {
                        func.apply(context, args);
                    }
                };
                var callNow = immediate && !timeout;
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
                if (callNow) {
                    func.apply(context, args);
                }
            };
        },
    };

    $(document).ready(reyhoon_products.on_ready);
}(jQuery, document));


(function ($, document) {
    "use strict";

    var reyhoon_services = {
        /**
         * On doc ready.
         */
        on_ready: function () {
            reyhoon_services.watch();
        },

        /**
         * Watch for trigger events.
         */
        watch: function () {
            $(document.body).on('reyhoon-show-lookup-services', function (event, $button) {
                var $parent = $button.closest('.reyhoon-services-selector'),
                    $lookup = $parent.find('.reyhoon-services-selector__lookup');

                $button.hide();
                $lookup.show();
            });

            $(document.body).on('reyhoon-lookup-services', function (event, $button) {
                var $parent = $button.closest('.reyhoon-services-selector'),
                    $message = $parent.find('.reyhoon-services-selector__lookup-message'),
                    $change = $parent.find('.reyhoon-services-selector__selected-change'),
                    city = $parent.find('.reyhoon-services-selector__lookup-city').val(),
                    postcode = $parent.find('.reyhoon-services-selector__lookup-postcode').val(),
                    service = $button.data('reyhoon-service');

                var data = {
                    'action': 'reyhoon_lookup_service',
                    'postcode': postcode,
                    'city': city,
                    'service': service
                };

                jQuery.post(
                    reyhoon_vars.ajax_url,
                    data,
                    function (response) {
                        if (!response.success) {
                            $message.html('<p>' + response.data.message + '</p>');
                            return;
                        }

                        $message.html('');
                        $change.show();

                        if (typeof response.data.fragments !== 'undefined') {
                            $.each(response.data.fragments, function (fragment_selector, fragment_html) {
                                $(fragment_selector).html(fragment_html);
                            });
                        }

                    }
                );
            });
        }
    };

    $(document).ready(reyhoon_services.on_ready);
}(jQuery, document));

//Tab Scroll

// Tab Scroll (dynamic offset + spacer)
(function ($, document) {
    "use strict";

    const $nav = document.querySelector('.reyhoon-main__tabs');
    if (!$nav) return;

    // اگر اسپیسر بعد از تب وجود ندارد، بساز
    let spacer = $nav.nextElementSibling;
    if (!spacer || !spacer.classList.contains('fix-sticky')) {
        spacer = document.createElement('div');
        spacer.className = 'fix-sticky';
        $nav.parentNode.insertBefore(spacer, $nav.nextSibling);
    }

    const sections = [...document.querySelectorAll('.reyhoon-main__group')];
    const link = (id) => document.querySelector(`a[href="#${id}"]`);

    // محاسبه‌ی آفست بالای صفحه (هدر فیکس + نوار ادمین وردپرس)
    function computeStickyOffset(){
        const header = document.querySelector('.ryn-default-header');
        let offset = header ? header.offsetHeight : 0;
        if (document.body.classList.contains('admin-bar')) {
            offset += (window.innerWidth <= 782 ? 46 : 32);
        }
        document.body.style.setProperty('--sticky-offset', `${offset}px`);
        return offset;
    }

    // اولین مکانی که تب باید فیکس شود
    const thresholdTop = $nav.offsetTop;

    const inView = (el) => {
        let top = el.offsetTop - 50;
        let height = el.offsetHeight;
        while (el.offsetParent){ el = el.offsetParent; top += el.offsetTop; }
        return (top < (window.pageYOffset + window.innerHeight) &&
            (top + height) > window.pageYOffset);
    };

    function handleScroll(){
        const shouldFix = window.pageYOffset >= thresholdTop;
        $nav.classList.toggle('tabs--fixes', shouldFix);

        // به اندازه ارتفاع واقعی تب، اسپیسر بگذار تا پرش نداشته باشیم
        spacer.style.height = shouldFix ? `${$nav.offsetHeight}px` : '0px';

        // هایلایت تب فعال + اسکرول افقی آیتم فعال
        let next = false;
        sections.forEach(sec => {
            const current = link(sec.id)?.parentElement;
            if (!current) return;
            if (inView(sec) && !next) {
                current.classList.add('reyhoon-tabs__item--active');
                next = true;
                const active = document.querySelector(".tabs--fixes .reyhoon-tabs__item--active");
                if (active) active.scrollIntoView({behavior:"smooth", block:"center", inline:"center"});
            } else {
                current.classList.remove('reyhoon-tabs__item--active');
            }
        });
    }

    // اجرای اولیه
    computeStickyOffset();
    handleScroll();

    // رویدادها
    window.addEventListener('scroll', handleScroll);
    window.addEventListener('resize', () => { computeStickyOffset(); handleScroll(); });

    // اسکرول نرم روی کلیک تب‌ها با احتساب آفست و ارتفاع تب
    jQuery('.reyhoon-tabs__link').on('click', function (e) {
        e.preventDefault();
        const sel = $(this).attr('href');
        const $target = $(sel);
        if (!$target.length) return;
        const offsetTop = $target.offset().top;
        const offset = computeStickyOffset();
        const navH = $nav.offsetHeight || 0;
        $('html, body').animate({ scrollTop: offsetTop - offset - navH }, 300);
    });

}(jQuery, document));


var reyhoon_timings = {}; // Make this global so pro modules can access it.

(function ($, document) {
    "use strict";

    reyhoon_timings = {
        /**
         * On doc ready.
         */
        on_ready: function () {
            reyhoon_timings.watch();
            reyhoon_timings.set_date_and_time();
        },

        /**
         * Set Date and Time.
         *
         * When the shipping preview panel loads, we don't want to have
         * to edit it immediately to set the date and time, so instead
         * pick the first available ones. The customer can change them if
         * they need to.
         */
        set_date_and_time: function () {
            var $date = document.querySelector('#reyhoon-date');
            var date_option = '';
            var date_value = '';
            if ($date) {
                date_option = $date.options[$date.selectedIndex];
                if (date_option) {
                    date_value = date_option.value;
                    if (!date_value && $date.options[$date.selectedIndex + 1]) {
                        $date.options[$date.selectedIndex + 1].selected = true;
                        $($date).change();
                    }
                }
            }

            if (date_value === 'asap') {
                return;
            }

            var $time = document.querySelector('#reyhoon-time');
            var time_option = '';
            if ($time) {
                time_option = $time.options[$time.selectedIndex];
                if (time_option && $time.options[$time.selectedIndex + 1]) {
                    var time_value = time_option.value;
                    if (!time_value) {
                        $time.options[$time.selectedIndex + 1].selected = true;
                        $($time).change();
                    }
                }
            }
        },

        /**
         * Restore current timings.
         */
        restore: function () {
            var timings = reyhoon_timings.get_timings();

            if (!timings || !timings.date) {
                return;
            }

            $('.reyhoon-order-timings__date').val(timings.date);
            $('.reyhoon-order-timings__date').change();

            if (!timings.time) {
                return;
            }

            $('.reyhoon-order-timings__time').val(timings.time);
            $('.reyhoon-order-timings__time').change();
        },

        /**
         * Watch for trigger events.
         */
        watch: function () {
            $(document.body).on('wc_fragments_refreshed', function () {
                reyhoon_timings.restore();
                reyhoon_timings.set_date_and_time();
            });

            $(document.body).on('updated_checkout', function () {
                reyhoon_timings.restore();
                reyhoon_timings.set_date_and_time();
            });

            $(document.body).on('change', '.reyhoon-order-timings__date', function (event) {

                var $date_field = $(this),
                    $selected = $date_field.find('option:selected'),
                    slots = $selected.data('reyhoon-slots'),
                    $time_field_wrap = $('.reyhoon-order-timings--time'),
                    $time_field = $('.reyhoon-order-timings__time'),
                    $first_option = $time_field.find('option').first(),
                    $asap_option = $time_field.find('option[value="asap"]').first();

                var timings = reyhoon_timings.get_timings();
                timings.date = $('.reyhoon-order-timings__date').val();
                window.localStorage.setItem('reyhoon_timings', JSON.stringify(timings));

                $time_field.html($first_option);

                if ($asap_option) {
                    $time_field.append($asap_option);
                }

                if (!slots) {
                    $time_field.prop('disabled', true);
                    $time_field_wrap.hide();
                    return;
                }

                if ('all-day' === slots[0].value) {
                    $time_field_wrap.hide();
                    $time_field.prop('disabled', true);
                } else {
                    $time_field.prop('disabled', false);
                    $time_field_wrap.show();

                    $.each(slots, function (index, slot) {
                        $time_field.append($('<option />').attr('value', slot.value).text(slot.formatted));
                    });
                }

                reyhoon_timings.set_timing_clone();
            });

            $(document.body).on('change', '.reyhoon-order-timings__time', function (event) {
                var timings = reyhoon_timings.get_timings();
                timings.time = $('.reyhoon-order-timings__time').val();
                window.localStorage.setItem('reyhoon_timings', JSON.stringify(timings));
            });


        },

        set_timing_clone: function () {
            let clocks = document.querySelector('#reyhoon-time'),
                cloneRoot = $('#reyhoon-time-clone');

            cloneRoot.empty();

            for (let clock of clocks.options) {
                let li = document.createElement('li');
                li.innerText = clock.text;
                li.dataset.value = clock.value;

                cloneRoot.append(li);
            }

            let cloneLi = cloneRoot.find('li');

            cloneLi.click(function () {
                $(clocks).val($(this).data('value'));
                $(clocks).trigger('change');
                cloneLi.removeClass('active');
                $(this).addClass('active');
            })
        },

        get_timings: function () {
            let date = $('#reyhoon-date option:selected').text(),
                time = $('#reyhoon-time option:selected').text(),
                dateTime = $('#current_date_time_header');
            $('#reyhoon-time-clone li[data-value="' + $('#reyhoon-time').val() + '"]').addClass('active');
            if ($('#reyhoon-time option:selected').val() != "") {
                dateTime.text(date + " در ساعت " + time);
            } else {
                dateTime.text(date);
            }
            return JSON.parse(window.localStorage.getItem('reyhoon_timings')) || {};
        }

    };

    $(document).ready(reyhoon_timings.on_ready);
}(jQuery, document));
(function ($, document) {
    "use strict";

    var reyhoon_triggers = {
        /**
         * On doc ready.
         */
        on_ready: function () {
            reyhoon_triggers.watch();
            reyhoon_triggers.init_variation_swach();
        },

        /**
         * Watch for trigger events.
         */
        init_variation_swach: function () {
            $('body').on('click', '.ryn-variations li', function () {
                const select = $('#' + $(this).parent().data('id'));
                select.val($(this).data('value'));
                select.trigger('change');
                $(this).parent().find('li').removeAttr('selected');
                $(this).attr('selected', 'selected')
            });
        },

        /**
         * Watch for trigger events.
         */
        watch: function () {
            $(document.body).on('click', '[data-reyhoon-trigger]', reyhoon_triggers.trigger);
        },

        /**
         * Fire trigger.
         */
        trigger: function (e) {
            // Prevent even bubbling up.
            e.stopImmediatePropagation();

            var $trigger_element = $(this),
                trigger = $trigger_element.data('reyhoon-trigger');

            $(document.body).trigger('reyhoon-' + trigger, [$trigger_element]);
        }
    };

    $(document).ready(reyhoon_triggers.on_ready);

}(jQuery, document));

jQuery(function ($) {
    const search = new URLSearchParams(window.location.search);
    const params = new URLSearchParams(search);
    let paramObj = {};
    for (var value of params.keys()) {
        paramObj[value] = params.get(value);
    }
    if (paramObj['open_drawer'] === 'true') {
        $(document.body).trigger('reyhoon-drawer.open', {show_cart: true});
    }

    $('body').on('updated_checkout', function () {

        let price = $('.order-total .woocommerce-Price-amount').text();

        $('#place_order').text('ثبت سفارش (' + price + ')');
    });
})

jQuery(document).ready(function ($) {
    $('#empty-cart').on('click', function (e) {
        e.preventDefault();
        var retVal = confirm("از حذف کامل سبد خرید اطمینان دارید ؟");
        if (retVal == true) {
            $.ajax({
                url: reyhoon_vars.ajax_url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'reyhoon_empty_cart',
                },
                beforeSend: function () {
                    $('.reyhoon-sb-container').toggleClass('reyhoon-button--loading');
                },
                success: function (result) {
                    $('.reyhoon-sb-container').toggleClass('reyhoon-button--loading');
                    $('.reyhoon-sb-container').html(result.fragments);
                    location.reload();
                }
            });
        } else {
            return false;
        }
    });
});


jQuery(document).ready(function ($) {
    const navbarMenu = document.getElementById("ryn-default-menu");
    const burgerMenu = document.getElementById("ryn-default-burger");
    const headerMenu = document.getElementById("ryn-default-header");

    // Open Close Navbar Menu on Click Burger
    if (burgerMenu && navbarMenu) {
        burgerMenu.addEventListener("click", () => {
            burgerMenu.classList.toggle("is-active");
            navbarMenu.classList.toggle("is-active");
        });
        // Close Navbar Menu on Click Menu Links
        document.querySelectorAll(".menu-link").forEach((link) => {
            link.addEventListener("click", () => {
                burgerMenu.classList.remove("is-active");
                navbarMenu.classList.remove("is-active");
            });
        });

        // Fixed Navbar Menu on Window Resize
        window.addEventListener("resize", () => {
            if (window.innerWidth > 768) {
                if (navbarMenu.classList.contains("is-active")) {
                    navbarMenu.classList.remove("is-active");
                }
            }
        });
    }

    // Change Header Background on Scrolling
    if (headerMenu) {
        window.addEventListener("scroll", () => {
            if (this.scrollY >= 85) {
                headerMenu.classList.add("on-scroll");
            } else {
                headerMenu.classList.remove("on-scroll");
            }
        });
    }

});
