$ = jQuery;
const QRs = document.querySelectorAll('.qr-generator');

QRs.forEach((item, index) => {
    new QRCode(item, {
        text: $(item).next('#url').text(),
        width: 128,
        height: 128,
        colorDark: "#1d2327",
        colorLight: "#fff",
        correctLevel: QRCode.CorrectLevel.H
    });
})

function copyAddress(btn) {
    var copyText = jQuery(btn).siblings("#qrcode");
    copyText = copyText.attr('title');
    navigator.clipboard.writeText(copyText);
    alert( 'link copied : ' + copyText);
}
