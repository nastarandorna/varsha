
(function( $, document ) {
	"use strict";

	var reyhoon_layouts = {
		/**
		 * On doc ready.
		 */
		on_ready: function() {
			/**
			 * On change layout setting.
			 */
			$( document.body ).on( 'change', '.reyhoon-table--product-lists input, .reyhoon-table--product-lists select', function( e ) {
				var $field = $( this ),
					$parent = $field.closest( '.reyhoon-table__row--repeatable' ),
					$shortcode = $parent.find( '.reyhoon-field--product-list-shortcode' );

				var default_shortcode_parameters = {
					categories: '',
					layout: 'grid',
					images: 'true'
				};

				var shortcode_parameters = {
					categories: $parent.find( '.reyhoon-select--categories' ).val().toString(),
					layout: $parent.find( '.reyhoon-select--layout' ).val().toString(),
					images: $parent.find( '.reyhoon-checkbox--images' ).is(':checked').toString()
				};

				var shortcode = '[reyhoon';

				$.each( shortcode_parameters, function( key, value ) {
					if ( value === default_shortcode_parameters[ key ] ) {
						return;
					}

					shortcode += ' ' + key + '="' + value + '"';
				} );

				shortcode += ']';

				$shortcode.val( shortcode );
			} );
		}
	};

	$( document ).ready( reyhoon_layouts.on_ready );
}( jQuery, document ));
(function( $, document ) {
	"use strict";

	var reyhoon_multiselects = {
		/**
		 * On doc ready.
		 */
		on_ready: function() {
			reyhoon_multiselects.init( $( '.reyhoon-select--multi-select' ) );

			/**
			 * Init multiselects trigger.
			 */
			$( document ).on( 'reyhoon-init-multiselects', function( e, data ) {
				if ( typeof data.selects === 'undefined' ) {
					return;
				}

				reyhoon_multiselects.init( data.selects );
			} );

			/**
			 * Destroy mutliselects trigger.
			 */
			$( document ).on( 'reyhoon-destroy-multiselects', function( e, data ) {
				if ( typeof data.selects === 'undefined' ) {
					return;
				}

				reyhoon_multiselects.destroy( data.selects );
			} );
		},

		/**
		 * Init multiselects.
		 *
		 * @param $selects
		 */
		init: function( $selects ) {
			$selects.multiSelect();

			$selects.each( function( index, select ) {
				var $select = $( select ),
					$multi_select = $select.siblings( '.multi-select-container' ),
					$none_option = $multi_select.find( '.multi-select-menuitem--none' ),
					none_label = $select.data( 'reyhoon-select-none-option' );

				$none_option.remove();

				var $labels = $multi_select.find( '.multi-select-menuitem' ),
					$disabled_labels = $multi_select.find( '.multi-select-menuitems input:disabled' ).parent();

				$labels.show();
				$disabled_labels.hide();

				if ( $labels.length === $disabled_labels.length && none_label ) {
					$multi_select.find( '.multi-select-menuitems' ).append( '<span class="multi-select-menuitem multi-select-menuitem--none">' + none_label + '</span>' );
				}
			} );
		},

		/**
		 * Destroy multiselects.
		 *
		 * @param $selects
		 */
		destroy: function( $selects ) {
			var $multi_selects = $selects.siblings( '.multi-select-container' );

			$multi_selects.remove();
			$selects.data( 'plugin_multiSelect', false );
		}
	};

	$( document ).ready( reyhoon_multiselects.on_ready );
}( jQuery, document ));

(function( $, document ) {
	"use strict";

	var reyhoon_timings = {
		/**
		 * On doc ready.
		 */
		on_ready: function() {
			/**
			 * On enable day.
			 */
			$( document.body ).on( 'change', '.reyhoon-enable-day', function( e ) {
				var $checkbox = $( this ),
					day = $checkbox.data( 'reyhoon-day' ),
					checked = $checkbox.is( ':checked' ),
					$day_selects = $( '.reyhoon-select--days' );

				$day_selects.find( 'option[value="' + day + '"]' ).attr( 'disabled', !checked ).attr( 'selected', false );

				$( document ).trigger( 'reyhoon-destroy-multiselects', { selects: $day_selects } );
				$( document ).trigger( 'reyhoon-init-multiselects', { selects: $day_selects } );
			} );

			/**
			 * Toggle delivery/pickup service hours.
			 */
			$( document.body ).on( 'change', '[name*="\\[store_general_services\\]"]', function( e ) {
				var $checkbox = $( this ),
					service = $checkbox.val(),
					checked = $checkbox.is( ':checked' ),
					$elements = $( '.reyhoon-toggle-wrapper--' + service + ', button[data-reyhoon-wrapper="' + service + '"]' ),
					visibility_class = 'reyhoon-ui-hide',
					$select_services_notice = $( '.reyhoon-notice--select-service' );

				// Toggle visibility of service hours.
				if ( checked ) {
					$elements.removeClass( visibility_class );
				} else {
					$elements.addClass( visibility_class );
				}

				var $selected_services = $( '[name*="\\[store_general_services\\]"]:checked' );

				// If no services selected, show message.
				if ( $selected_services.length <= 0 ) {
					$select_services_notice.removeClass( visibility_class );
				} else {
					$select_services_notice.addClass( visibility_class );

					// Toggle first enabled service.
					var active_service = $selected_services.eq( 0 ).val(),
						$active_service_button = $( 'button[data-reyhoon-wrapper="' + active_service + '"]' );

					$active_service_button.click();
				}

				// If only pickup selected, toggle "same as delivery" checkbox.
				var $same_as_delivery_checkbox = $( '#reyhoon_settings_store_general_service_hours_pickup_same' ),
					default_state = $same_as_delivery_checkbox.data( 'default-state' );

				if ( typeof default_state === 'undefined' ) {
					default_state = $same_as_delivery_checkbox.is( ':checked' );
					$same_as_delivery_checkbox.data( 'default-state', default_state );
				}

				if ( 1 === $selected_services.length && 'pickup' === $selected_services.val() ) {
					$same_as_delivery_checkbox.prop( 'checked', false ).parent().addClass( visibility_class );
					$( document.body ).trigger( 'reyhoon-toggle-element', {
						trigger_element: $same_as_delivery_checkbox[0],
						add_class: false
					} );
				} else {
					$same_as_delivery_checkbox.prop( 'checked', default_state ).parent().removeClass( visibility_class );
					$( document.body ).trigger( 'reyhoon-toggle-element', {
						trigger_element: $same_as_delivery_checkbox[0],
						add_class: default_state
					} );
				}

				$( document ).trigger( 'reyhoon-add-last-row-class' );
			} );

			/**
			 * Set default state of "Same as delivery service hours" checkbox.
			 */
			$( document.body ).on( 'change', '#reyhoon_settings_store_general_service_hours_pickup_same', function( e ) {
				$( this ).data( 'default-state', $( this ).is( ':checked' ) );
			} );

			/**
			 * Toggle open hours day.
			 */
			$( '.reyhoon-enable-day' ).on( 'change', function() {
				var $row = jQuery( this ).closest( 'tr' ),
					hidden_class = 'reyhoon-table__row--hidden';

				$row.toggleClass( hidden_class, !this.checked );
			} );
		}
	};

	$( document ).ready( reyhoon_timings.on_ready );
}( jQuery, document ));
(function( $, document ) {
	"use strict";

	var reyhoon_triggers = {
		/**
		 * On doc ready.
		 */
		on_ready: function() {
			/**
			 * On trigger click or change.
			 */
			$( document.body ).on( 'click change', '[data-reyhoon-trigger]', function( e ) {
				var $trigger_element = $( this ),
					trigger = $trigger_element.data( 'reyhoon-trigger' );

				if ( 'click' === e.type && ( $trigger_element.is( 'select' ) || $trigger_element.is( 'input' ) || $trigger_element.is( 'label' ) ) ) {
					return;
				}

				if ( $trigger_element.is( 'button' ) || $trigger_element.is( 'a' ) ) {
					e.preventDefault();
				}

				$( document.body ).trigger( 'reyhoon-' + trigger, { trigger_element: $trigger_element } );
			} );

			/**
			 * On new row.
			 */
			$( document.body ).on( 'reyhoon-new-row', function( e, data ) {
				var $button = $( data.trigger_element ),
					$target = $( $button.data( 'reyhoon-target' ) ),
					$body = $target.find( '.reyhoon-table__body' ),
					$row = $body.find( '.reyhoon-table__row--repeatable:last-child' ),
					index = parseInt( $row.data( 'reyhoon-index' ) ),
					new_index = index + 1,
					row_html = $row[ 0 ].outerHTML.replace( /\[\d+\]/gm, '[' + new_index + ']' ).replace( /data-reyhoon-index="\d+"/gm, 'data-reyhoon-index="' + new_index + '"' );

				$body.append( row_html );

				var $new_row = $body.find( '.reyhoon-table__row--repeatable:last-child' );

				// Reset inputs.
				$new_row.find( 'input' ).not( 'input[type="checkbox"]' ).val( '' );

				// Reset datepickers.
				var $datepickers = $new_row.find( '.hasDatepicker' );

				$datepickers.each( function( index, datepicker ) {
					var $datepicker = $( datepicker );

					// Remove datepicker class and datepicker generated ID.
					$datepicker.removeClass( 'hasDatepicker' ).attr( 'id', '' );
				} );

				// Reset selects.
				var $selects = $new_row.find( 'select' );

				$selects.each( function( index, select ) {
					var $select = $( select ),
						$blank_option = $select.find( 'option[value=""]' ),
						is_multi_select = $select.hasClass( 'reyhoon-select--multi-select' ),
						value = $blank_option.length || is_multi_select ? '' : $select.find( 'option:first-child' ).val();

					$select.val( value );

					if ( is_multi_select ) {
						$select.change();
					}
				} );

				// Checkboxes.
				$new_row.find( 'input[type="checkbox"]' ).prop( 'checked', false );

				// Remove multi select container and reinit.
				$new_row.find( '.multi-select-container' ).remove();
				$( document ).trigger( 'reyhoon-init-multiselects', { selects: $body.find( '.reyhoon-select--multi-select' ) } );

				// Trigger select toggles.
				$body.find( '[data-reyhoon-trigger="toggle-element-select"]' ).change();

				$( document ).trigger( 'reyhoon-add-last-row-class' );
			} );

			/**
			 * On remove row.
			 */
			$( document.body ).on( 'reyhoon-remove-row', function ( e, data ) {
				var $button = $( data.trigger_element ),
					$row = $button.closest( 'tr' ),
					$tbody = $button.closest( 'tbody' ),
					row_count = $tbody.find( '>tr' ).length;

				if ( row_count === 1 ) {
					$row.find( 'input' ).val( '' );
					$row.find( 'input[type="checkbox"], input[type="radio"]' ).prop( 'checked', false );

					$row.find( 'select' ).each(function() {
						if ( $( this ).hasClass( 'reyhoon-select--multi-select' ) ) {
							return;
						}

						this.selectedIndex = 0;
						$( this ).trigger( 'change' );
					} );

					$row.find( '.multi-select-container input[type="checkbox"]' ).trigger( 'change' );
				} else {
					$row.remove();
				}

				$( document ).trigger( 'reyhoon-add-last-row-class' );
			} );

			/**
			 * On toggle element.
			 */
			$( document.body ).on( 'reyhoon-toggle-element', function( e, data ) {
				data.add_class = typeof data.add_class !== 'undefined' ? data.add_class : null;

				var $trigger_element = $( data.trigger_element ),
					$target = $( $trigger_element.data( 'reyhoon-target' ) ),
					toggle_class = $trigger_element.data( 'reyhoon-toggle-class' );

				if ( null === data.add_class ) {
					$target.toggleClass( toggle_class );
				} else if ( true === data.add_class ) {
					$target.addClass( toggle_class );
				} else if ( false === data.add_class ) {
					$target.removeClass( toggle_class );
				}

				$( document ).trigger( 'reyhoon-add-last-row-class' );
			} );

			/**
			 * On toggle element select.
			 */
			$( document.body ).on( 'reyhoon-toggle-element-select', function( e, data ) {
				var $trigger_element = $( data.trigger_element ),
					$parent = $trigger_element.closest( $trigger_element.data( 'reyhoon-parent' ) ),
					targets = $trigger_element.data( 'reyhoon-target' ),
					selected = $trigger_element.val();

				if ( $parent.length <= 0 || typeof targets === 'undefined' || typeof targets[ selected ] === 'undefined' ) {
					return;
				}

				$.each( targets[ selected ], function( index, target ) {
					var $target = $parent.find( target );

					if ( 'show' === index ) {
						$target.show();
					} else if ( 'hide' === index ) {
						$target.hide();
					}
				} );

				$( document ).trigger( 'reyhoon-add-last-row-class' );
			} );

			/**
			 * On toggle wrapper.
			 */
			$( document.body ).on( 'reyhoon-toggle-wrapper', function( e, data ) {
				var $trigger_element = $( data.trigger_element ),
					wrapper = $trigger_element.data( 'reyhoon-wrapper' ),
					group = $trigger_element.data( 'reyhoon-wrapper-group' ),
					$target = $( '.reyhoon-toggle-wrapper--' + wrapper + '[data-reyhoon-wrapper-group="' + group + '"]' );

				$( '.reyhoon-toggle-wrapper[data-reyhoon-wrapper-group="' + group + '"]' ).removeClass( 'reyhoon-toggle-wrapper--active' );
				$target.addClass( 'reyhoon-toggle-wrapper--active' );

				$( '[data-reyhoon-wrapper-group="' + group + '"]' ).removeClass( 'reyhoon-trigger-element--active' );
				$( '[data-reyhoon-wrapper="' + wrapper + '"]' ).addClass( 'reyhoon-trigger-element--active' );

				$( document ).trigger( 'reyhoon-add-last-row-class' );
			} );

			/**
			 * Add last row class trigger.
			 */
			$( document ).on( 'reyhoon-add-last-row-class', reyhoon_triggers.add_last_row_class );

			/**
			 * On ready triggers.
			 */
			$( document ).trigger( 'reyhoon-add-last-row-class' );
		},

		/**
		 * Add last row class.
		 */
		add_last_row_class: function() {
			var $tables = $( '.reyhoon-table' ),
				last_row_class = 'reyhoon-table__row--last',
				$last_rows = $tables.find( '.' + last_row_class ),
				$last_row = $tables.find( 'tbody > tr:visible:last' );

			$last_rows.removeClass( last_row_class );
			$last_row.addClass( last_row_class );
		},
	};

	$( document ).ready( reyhoon_triggers.on_ready );
}( jQuery, document ));
