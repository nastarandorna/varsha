<?php
/**
 * Plugin Name: ریحون - پلتفرم سفارش آنلاین غذا
 * Author URI: https://avin-tarh.ir
 * Description: ساخت یک سیستم سفارش آنلاین غذا مشابه اسنپ فود برای ووکامرس
 * Version: 3.0.0
 * Author: آوین طرح
 * Text Domain: reyhoon
 * WC requires at least: 5.4.0
 * WC tested up to: 6.7.0
 */

define('RYN_PRODUCT', 'reyhoon');
define('RYN_SELLER', 'avin'); //avin or zhaket

require_once ('reyhoon.php');

function reyhoon_register_activation_hook() {
    global $wpdb;
    $tb = $wpdb->prefix . 'reyhoon_mobile_otp';
    if ($wpdb->get_var("SHOW TABLES LIKE '$tb'") != $tb) {
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $tb (
		          mobileno VARCHAR(20) NOT NULL,
		          otp VARCHAR(32) NOT NULL,
		          time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		          UNIQUE ID(mobileno)
	            ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta(array($sql));
    }
}

register_activation_hook(__FILE__, 'reyhoon_register_activation_hook');

