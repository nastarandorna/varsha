<?php

defined("ABSPATH") or exit;

$reyhoon = new Reyhoon();
class Reyhoon
{
    public static $version;
    public function __construct()
    {
        $this->define_constants();
        add_action("init", [$this, "load_textdomain"], 0);
        add_action("plugins_loaded", [$this, "run"], 20);
        add_action("activated_plugin", [$this, "activate"], 20);
    }
    public function load_textdomain()
    {
        load_plugin_textdomain("reyhoon", false, REYHOON_LANGUAGES_PATH);
    }
    public function run()
    {
        if (!self::is_woo_active()) {
            add_action("admin_notices", ["Reyhoon", "reyhoon_notice_woocommerce"]);
        } else {
            $this->init_lic();
            $this->load_classes();
            do_action("reyhoon_init");
        }
    }
    public function activate($plugin)
    {
        if (!self::is_woo_active()) {
            return NULL;
        }
        $checked = isset($_REQUEST["checked"]) ? $_REQUEST["checked"] : [];
        if (is_array($checked) && 1 < count($checked)) {
            return NULL;
        }
        if (REYHOON_BASENAME != $plugin) {
            return NULL;
        }
        wp_redirect(admin_url("admin.php?page=reyhoon-settings"));
        exit;
    }
    public static function reyhoon_notice_woocommerce()
    {
        echo "        <div class=\"notice notice-error\">\r\n            <p>\r\n                ";
        _e("Reyhoon requires WooCommerce to be installed and activated.", "reyhoon");
        echo "            </p>\r\n        </div>\r\n        ";
    }
    private function define_constants()
    {
        $this->define("REYHOON_PATH", plugin_dir_path(__FILE__));
        $this->define("REYHOON_URL", plugin_dir_url(__FILE__));
        $this->define("REYHOON_ASSETS_URL", REYHOON_URL . "assets/");
        $this->define("REYHOON_INC_PATH", REYHOON_PATH . "inc/");
        $this->define("REYHOON_MODULES_PATH", REYHOON_INC_PATH . "modules/");
        $this->define("REYHOON_VENDOR_PATH", REYHOON_INC_PATH . "vendor/");
        $this->define("REYHOON_TEMPLATES_PATH", REYHOON_PATH . "templates/");
        $this->define("REYHOON_TPL_PATH", REYHOON_PATH . "templates/");
        $this->define("REYHOON_BASENAME", plugin_basename(__FILE__));
        $this->define("REYHOON_LANGUAGES_PATH", dirname(REYHOON_BASENAME) . "/languages/");
        $this->define("REYHOON_VERSION", time());
    }
    public function init_lic()
    {
       // if (!class_exists("AVN_Lic_Controller")) {
            require REYHOON_PATH . "/admin-core.php";
            return"ok";
       // }
       /*
        $config = ["product" => "reyhoon", "productId" => 6185, "seller" => RYN_SELLER, "token" => "9ffdb870-a21b-48f6-9b76-c041ae4d1081", "wp_option" => "avn_" . RYN_SELLER . "_reyhoon", "parent_menu" => "woocommerce", "menu_title" => "لایسنس ریحون", "salt" => "ufj3mnvBrLJpivjr8HDlpwrf84D1mnOkhrwerwfvswvcwerfwerfrweaaamqq"];
        $config = apply_filters("reyhoon_license_config", $config);
        */
       /*
       $has_license = new AVN_Lic_Controller($config["salt"]);
        if (defined("RYN_plus_hasLicense")) {
            wp_die("خطا!!! ممکن است تغییرات شما در فایل ها باعث ایجاد خطا در لایسنس شده باشد.");
        }
        if ($has_license->salt() != $config["salt"]) {
            wp_die("خطا!!! ممکن است تغییرات شما در فایل ها باعث ایجاد خطا در لایسنس شده باشد.");
        }
      //  define("RYN_plus_hasLicense", $has_license->get_License($config));
      */
    }
    private function define($name, $value)
    {
        if (!defined($name)) {
            define($name, $value);
        }
    }
    private function load_classes()
    {
        require_once REYHOON_INC_PATH . "functions.php";
        require_once REYHOON_INC_PATH . "class-helpers.php";
        require_once REYHOON_INC_PATH . "class-settings.php";
        require_once REYHOON_INC_PATH . "class-modules.php";
        require_once REYHOON_INC_PATH . "class-assets.php";
        require_once REYHOON_INC_PATH . "class-products.php";
        require_once REYHOON_INC_PATH . "class-ajax.php";
        require_once REYHOON_INC_PATH . "class-admin-notices.php";
        require_once REYHOON_INC_PATH . "class-shortcodes.php";
        require_once REYHOON_INC_PATH . "class-ask-review.php";
        Reyhoon_Settings::run();
        Reyhoon_Assets::run();
        Reyhoon_Modules::run();
        Reyhoon_Products::run();
        Reyhoon_Ajax::run();
        Reyhoon_Shortcodes::run();
        Reyhoon_Ask_Review::run();
        Reyhoon::ckeck_lic();
    }
    private static function ckeck_lic()
    {
    	return"success";
    	/*
        if ((!defined("RYN_plus_hasLicense") || !RYN_plus_hasLicense) && !is_admin() && defined("WP_USE_THEMES")) {
            echo "                <div style=\"display: flex;justify-content: center\" >\r\n             ";
            Reyhoon_Helpers::echo_svg("cart-empty-background");
            echo "\r\n                </div>\r\n                <p style=\"direction: rtl; text-align: center;font-size: 18px;font-weight: bold\">رستوران غیرفعال است.</p>\r\n             ";
            if (current_user_can("manage_options")) {
                echo "                    <p style=\"direction: rtl; margin-top: 25px ; text-align: center;font-size: 14px\">لایسنس محصول غیرفعال است نسبت به فعال سازی از طریق پیشخوان وردپرس اقدام بفرمایید.</p>\r\n          ";
            }
            wp_die();
        }
        */
    }
    public static function is_woo_active()
    {
        return in_array("woocommerce/woocommerce.php",  apply_filters("active_plugins", get_option("active_plugins")), true) || in_array("woocommerce/woocommerce.php", array_keys( get_site_option("active_sitewide_plugins"), true));
    }
}

?>