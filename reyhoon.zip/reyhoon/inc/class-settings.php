<?php
/**
 * Settings methods.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

/**
 * Settings class.
 */
class Reyhoon_Settings
{
    /**
     * Settings framework instance.
     *
     * @var null|Reyhoon_Settings_Framework
     */
    public static $settings_framework = null;

    /**
     * Settings.
     *
     * @var array
     */
    public static $settings = array();

    /**
     * Option group.
     *
     * @var string
     */
    protected static $option_group = 'reyhoon';

    /**
     * Run.
     */
    public static function run()
    {
        add_action('init', array(__CLASS__, 'init_settings'));
        add_filter('plugin_action_links_' . REYHOON_BASENAME, array(__CLASS__, 'plugin_settings_link'));
        add_action('admin_menu', array(__CLASS__, 'add_settings_page'), 1);
        add_filter('reyhoon_default_settings', array(__CLASS__, 'default_settings'));
        add_filter('wpsf_register_settings_reyhoon', array(__CLASS__, 'register_settings'));
        add_filter('wpsf_register_settings_reyhoon', array(__CLASS__, 'reorder_settings_tabs'), 200);
        add_filter('wpsf_title_reyhoon', array(__CLASS__, 'settings_logo'));
        add_action('wpsf_after_title_reyhoon', array(__CLASS__, 'settings_header'));

        // Add category fields.
        add_action('product_cat_add_form_fields', array(__CLASS__, 'add_category_fields'), 20);
        add_action('product_cat_edit_form_fields', array(__CLASS__, 'edit_category_fields'), 20);
        add_action('created_term', array(__CLASS__, 'save_category_fields'), 10, 3);
        add_action('edit_term', array(__CLASS__, 'save_category_fields'), 10, 3);

    }

    /**
     * Init settings.
     */
    public static function init_settings()
    {
        require_once REYHOON_VENDOR_PATH . 'wp-settings-framework/wp-settings-framework.php';

        self::$settings_framework = new Reyhoon_Settings_Framework(null, self::$option_group);
        self::$settings = self::$settings_framework->get_settings();
    }

    /**
     * Add settings page link to plugin listing.
     *
     * @param array $links
     *
     * @return array
     */
    public static function plugin_settings_link($links = array())
    {
        $settings_url = admin_url('admin.php?page=reyhoon-settings');
        $links[] = sprintf('<a href="%s">%s</a>', esc_url($settings_url), esc_html(__('Settings', 'reyhoon')));

        return $links;
    }

    /**
     * Add settings page.
     */
    public static function add_settings_page()
    {
        $icon = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTI1LjE1MzIgMEgzMy41ODU2QzQxLjU0NjQgMCA0OCA2LjQ1MzU1IDQ4IDE0LjQxNDRWMjIuODQ2OEgzOS41Njc2QzMxLjYwNjcgMjIuODQ2OCAyNS4xNTMyIDE2LjM5MzMgMjUuMTUzMiA4LjQzMjQzVjBaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMjIuODQ2OCAwSDE0LjQxNDRDNi40NTM1NSAwIDAgNi40NTM1NSAwIDE0LjQxNDRWMjIuODQ2OEg4LjQzMjQzQzE2LjM5MzMgMjIuODQ2OCAyMi44NDY4IDE2LjM5MzMgMjIuODQ2OCA4LjQzMjQzVjBaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMjIuODQ2OCAyNS4xNTMySDE0LjQxNDRDNi40NTM1NSAyNS4xNTMyIDAgMzEuNjA2NyAwIDM5LjU2NzZWNDhIOC40MzI0M0MxNi4zOTMzIDQ4IDIyLjg0NjggNDEuNTQ2NCAyMi44NDY4IDMzLjU4NTZWMjUuMTUzMloiIGZpbGw9IiM0OUI5NjUiLz4KPHBhdGggZD0iTTQ4IDI1LjE1MzJIMzkuNTY3NkMzMS42MDY3IDI1LjE1MzIgMjUuMTUzMiAzMS42MDY3IDI1LjE1MzIgMzkuNTY3NlY0OEgzMy41ODU2QzQxLjU0NjQgNDggNDggNDEuNTQ2NCA0OCAzMy41ODU2VjI1LjE1MzJaIiBmaWxsPSJ3aGl0ZSIvPgo8L3N2Zz4K';

        add_menu_page('Reyhoon', 'ریحون', 'manage_options', 'reyhoon', null, $icon, 54);

        self::$settings_framework->add_settings_page(
            array(
                'parent_slug' => 'reyhoon',
                'page_title' => __('Reyhoon Settings', 'reyhoon'),
                'menu_title' => __('Settings', 'reyhoon'),
                'capability' => 'manage_options',
            )
        );

        remove_submenu_page('reyhoon', 'reyhoon');
    }

    /**
     * Add default settings.
     *
     * @param array $default_settings
     *
     * @return array
     */
    public static function default_settings($default_settings = array())
    {
        $default_settings['style_style_color'] = '#036666';
        return $default_settings;
    }

    /**
     * Register settings.
     *
     * @param array $settings
     *
     * @return array
     */
    public static function register_settings($settings = array())
    {
        $settings = array(
            'tabs' => array(),
            'sections' => array(),
        );

        $settings['tabs'] = array(
            array(
                'id' => 'dashboard',
                'title' => __('Dashboard', 'reyhoon'),
                'priority' => 0,
            ),
            array(
                'id' => 'style',
                'title' => __('Style', 'reyhoon'),
                'priority' => 100,
            ),
        );

        $settings['sections']['dashboard_getting_started'] = array(
            'tab_id' => 'dashboard',
            'section_id' => 'getting_started',
            'section_title' => __('Getting Started', 'reyhoon'),
            'section_order' => 0,
            'fields' => array(
                'remaining_days' => array(
                    'id' => 'remaining_days',
                    'title' => '',
                    'subtitle' => '',
                    'default' => '',
                    'type' => 'custom',
                    'output' => self::remaining_days(),
                ),
            ),
        );
        $settings['sections']['dashboard_getting_main'] = array(
            'tab_id' => 'dashboard',
            'section_id' => 'getting_main',
            'section_title' => __('Getting main', 'reyhoon'),
            'section_order' => 0,
            'fields' => array(
                'pro_version' => array(
                    'id' => 'pro_version',
                    'title' => '',
                    'subtitle' => '',
                    'default' => '',
                    'type' => 'custom',
                    'output' => self::pro_landing(),
                )
            ),
        );

        $settings['sections']['style'] = array(
            'tab_id' => 'style',
            'section_id' => 'style',
            'section_title' => __('General', 'reyhoon'),
            'section_description' => '',
            'section_order' => 10,
            'fields' => array(
                'color' => array(
                    'id' => 'color',
                    'title' => __('Brand Color', 'reyhoon'),
                    'subtitle' => __('Select an accent color to be used for buttons and other elements.', 'reyhoon'),
                    'type' => 'color',
                    'default' => self::get_setting_default('style_style_color'),
                ),
                'main_logo' => array(
                    'id' => 'main_logo',
                    'title' => __("Upload Logo",'reyhoon'),
                    'subtitle' => __("Logo with a width of 110",'reyhoon'),
                    'type' => 'file',
                    'default' => '',
                ),
            ),
        );

        return $settings;
    }

    /**
     * Reorder settings tabs.
     *
     * @param array $settings
     *
     * @return array
     */
    public static function reorder_settings_tabs($settings = array())
    {
        usort(
            $settings['tabs'],
            function ($a, $b) {
                $a['priority'] = empty($a['priority']) ? 0 : absint($a['priority']);
                $b['priority'] = empty($b['priority']) ? 0 : absint($b['priority']);

                return $a['priority'] - $b['priority'];
            }
        );

        return $settings;
    }

    /**
     * Get setting default.
     *
     * @param string $setting_name
     *
     * @return bool|mixed
     */
    public static function get_setting_default($setting_name = '')
    {
        if (empty($setting_name)) {
            return false;
        }

        $defaults = apply_filters('reyhoon_default_settings', array());

        if (!isset($defaults[$setting_name])) {
            return false;
        }

        return $defaults[$setting_name];
    }

    /**
     * Get setting.
     *
     * This method is accessible before the settings are assign to self::$settings.
     *
     * @param string $setting_name
     *
     * @return bool|mixed
     */
    public static function get_setting($setting_name = '')
    {
        if (empty($setting_name)) {
            return false;
        }

        $settings = get_option(self::$option_group . '_settings');

        if (isset($settings[$setting_name])) {
            return $settings[$setting_name];
        }

        return self::get_setting_default($setting_name);
    }

    /**
     * @param string $suffix
     *
     * @return bool
     */
    public static function is_settings_page($suffix = '')
    {
        if (!is_admin()) {
            return false;
        }

        // Allow bypass from other modules.
        if (apply_filters('reyhoon_is_settings_page', false)) {
            return true;
        }

        $valid_pages = apply_filters(
            'reyhoon_valid_admin_pages',
            array(
                self::$option_group . '-settings' . $suffix,
            )
        );
       // $page = filter_input(INPUT_GET, 'page', FILTER_SANITIZE_STRING);
        $page = filter_input(INPUT_GET, 'page', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

        if (!in_array($page, $valid_pages, true)) {
            return false;
        }

        return true;
    }

    /**
     * Get countries and states for select field.
     *
     * @return array
     */
    public static function get_countries_states()
    {
        $countries_states = array();

        if (!function_exists('WC')) {
            return $countries_states;
        }

        $countries = WC()->countries->get_countries();

        if (empty($countries)) {
            return $countries_states;
        }

        foreach ($countries as $key => $value) {
            $countries_states['country:' . $key] = $value;
            $states = WC()->countries->get_states($key);

            if (empty($states)) {
                continue;
            }

            $countries_states[$key] = array(
                'group_label' => $value,
                'values' => array(),
            );

            foreach ($states as $state_key => $state_value) {
                $state_key = sprintf('state:%s:%s', $key, $state_key);
                $countries_states[$key]['values'][$state_key] = sprintf('%s &mdash; %s', $value, $state_value);
            }
        }

        return $countries_states;
    }

    /**
     * Category fields.
     */
    public static function add_category_fields()
    {
        ?>
        <div class="form-field term-display-type-wrap">
            <label for="visibility"><?php esc_html_e('Visibility', 'reyhoon'); ?></label>
            <select id="visibility" name="visibility" class="postform">
                <option value=""><?php esc_html_e('Default', 'reyhoon'); ?></option>
                <option value="hidden"><?php esc_html_e('Hidden', 'reyhoon'); ?></option>
            </select>
            <p><?php _e('Choose whether to hide (on the frontend) this category archive and all single product pages within this category. Hiding them is recommended if using this category in the Reyhoon menu shortcode.', 'reyhoon'); ?></p>
        </div>
        <?php
    }

    /**
     * Edit category fields.
     *
     * @param mixed $term Term (category) being edited.
     */
    public static function edit_category_fields($term)
    {
        $visibility = get_term_meta($term->term_id, 'visibility', true);
        ?>
        <tr class="form-field term-display-type-wrap">
            <th scope="row" valign="top">
                <label for="visibility"><?php esc_html_e('Visibility', 'reyhoon'); ?></label>
            </th>
            <td>
                <select id="visibility" name="visibility" class="postform">
                    <option value="" <?php selected('', $visibility); ?>><?php esc_html_e('Default', 'reyhoon'); ?></option>
                    <option value="hidden" <?php selected('hidden', $visibility); ?>><?php esc_html_e('Hidden', 'reyhoon'); ?></option>
                </select>
                <p><?php _e('Choose whether to hide (on the frontend) this category archive and all single product pages within this category. Hiding them is recommended if using this category in the Reyhoon menu shortcode.', 'reyhoon'); ?></p>
            </td>
        </tr>
        <?php
    }

    /**
     * Save category fields.
     *
     * @param mixed $term_id Term ID being saved.
     * @param mixed $tt_id Term taxonomy ID.
     * @param string $taxonomy Taxonomy slug.
     */
    public static function save_category_fields($term_id, $tt_id = '', $taxonomy = '')
    {
        $visibility = filter_input(INPUT_POST, 'visibility', FILTER_SANITIZE_STRING);

        if (!is_null($visibility) && 'product_cat' === $taxonomy) {
            update_term_meta($term_id, 'visibility', sanitize_text_field($visibility));
        }
    }

    /**
     * Get hidden category IDs.
     *
     * @return array
     */
    public static function get_hidden_categories()
    {
        global $wpdb;

        static $hidden_categories = null;

        if (!is_null($hidden_categories)) {
            return apply_filters('reyhoon_hidden_categories', $hidden_categories);
        }

        $hidden_categories = array();

        $results = $wpdb->get_results(
            "SELECT DISTINCT tm.term_id
			FROM $wpdb->term_taxonomy AS tt
			INNER JOIN $wpdb->terms AS t ON tt.term_id = t.term_id
			INNER JOIN $wpdb->termmeta AS tm ON t.term_id = tm.term_id
			WHERE tt.taxonomy = 'product_cat'
			AND tm.meta_key = 'visibility'
			AND tm.meta_value IN ( 'hidden' )
			
			UNION DISTINCT
			
			SELECT DISTINCT term_id 
			FROM $wpdb->term_taxonomy
			WHERE parent IN (
				SELECT DISTINCT tm.term_id
				FROM $wpdb->term_taxonomy AS tt
				INNER JOIN $wpdb->terms AS t ON tt.term_id = t.term_id
				INNER JOIN $wpdb->termmeta AS tm ON t.term_id = tm.term_id
				WHERE tt.taxonomy = 'product_cat'
				AND tm.meta_key = 'visibility'
				AND tm.meta_value IN ( 'hidden' )
			)",
            ARRAY_A
        );

        if (is_wp_error($results) || empty($results)) {
            return apply_filters('reyhoon_hidden_categories', $hidden_categories);
        }

        $hidden_categories = array_map('absint', wp_list_pluck($results, 'term_id'));

        return apply_filters('reyhoon_hidden_categories', $hidden_categories);
    }

    /**
     * Add logo to settings page.
     */
    public static function settings_logo($title = '')
    {
        return sprintf('<img src="%s" width="164" height="36" />', esc_url(REYHOON_ASSETS_URL . 'img/reyhoon-logo.svg'));
    }

    /**
     * Help buttons and version number
     */
    public static function settings_header()
    {
        ?>
        <div class="reyhoon-settings-header">
            <ul class="reyhoon-settings-header__links">
                <li>
                    <a href="https://reyhoon.avin-tarh.ir/doc"
                       target="_blank">
                        <svg width="36" height="37" viewBox="0 0 36 37" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1185_20)">
                                <path d="M28.5 6.5V30.5H10.5C9.70435 30.5 8.94129 30.1839 8.37868 29.6213C7.81607 29.0587 7.5 28.2956 7.5 27.5V9.5C7.5 8.70435 7.81607 7.94129 8.37868 7.37868C8.94129 6.81607 9.70435 6.5 10.5 6.5H28.5Z"
                                      stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M28.5 24.5H10.5C9.70435 24.5 8.94129 24.8161 8.37868 25.3787C7.81607 25.9413 7.5 26.7044 7.5 27.5"
                                      stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M13.5 12.5H22.5" stroke="white" stroke-width="2" stroke-linecap="round"
                                      stroke-linejoin="round"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_1185_20">
                                    <rect width="36" height="36" fill="white" transform="translate(0 0.5)"/>
                                </clipPath>
                            </defs>
                        </svg>

                    </a>
                </li>
            </ul>
        </div>
        <?php
    }


    /**
     * Universal upgrade page content.
     *
     * @param string $feature Feature name.
     */
    public static function upgrade_page_content($feature = '')
    {
        $utm_campaign = str_replace(' ', '-', strtolower($feature));
        include REYHOON_TEMPLATES_PATH . 'admin/reyhoon-pro-page.php';
    }

    public static function remaining_days()
    {
        if (!is_admin()) {
            return;
        }
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, 'https://reyhoon.avin-tarh.ir/ryn_banner.json');
        $result = curl_exec($ch);
        curl_close($ch);
        $obj = json_decode($result);


        ob_start();
        ?>

        <div class="reyhoon-dashboard-header">
            <div class="progressbar-container">
                <?php if (!defined('RYN_plus_hasLicense') || !RYN_plus_hasLicense) { ?>
                    <div class="pie-container" style="--p:0;--b:4px;--c:#D63638;">
                        <div class="pie" style="--p:0;--b:4px;--c:#D63638;">
                            <div class="pie-inner">
                                <?php
                                echo 0;
                                ?>
                                <span><?php _e("Remaining time (days)",'reyhoon'); ?></span>
                            </div>
                        </div>
                    </div>
                    <span class="licence-title"> <?php echo apply_filters('ryn_lic_type', 'نسخه پایه - Basic'); ?></span>
                <?php }else{ ?>
                    <div class="pie-container" style="--p:100;--b:4px;--c:#262489;">
                        <div class="pie" style="--p:100;--b:4px;--c:#262489;">
                            <div class="pie-inner">
                                <?php
                                echo apply_filters('ryn_lic_expire_date', Reyhoon_Helpers::echo_svg('unlimit', false));
                                ?>
                                <span><?php _e("Remaining time (days)",'reyhoon'); ?></span>
                            </div>
                        </div>
                    </div>
                    <span class="licence-title"> <?php echo apply_filters('ryn_lic_type', 'نسخه پایه - Basic'); ?></span>
            <?php } ?>
            </div>

            <!-- License Start -->
            <div class="license-container bg-white relative bg-opacity-60 rounded-xl p-10 text-center">
                <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                <?php do_action('reyhoon_lic'); ?>
            </div>
            <!-- License End -->
            <div class="avin-container">
                <a href="<?= $obj->url ?>">
                    <img src="<?= $obj->image ?>" alt="ads">
                </a>
            </div>
        </div>

        <?php

        return ob_get_clean();
    }

    public static function pro_landing()
    {
        if (!is_admin()) {
            return;
        }
        if(!class_exists('Reyhoon_Pro')) {
            ob_start();
            include Reyhoon_Helpers::get_template_path('templates/admin/reyhoon-pro-page.php');
            return ob_get_clean();
        }
    }
}
