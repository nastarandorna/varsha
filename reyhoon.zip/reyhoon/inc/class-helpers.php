<?php
/**
 * Helper methods.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

/**
 * Helpers class.
 */
class Reyhoon_Helpers
{
    /**
     * Get term ID by slug.
     *
     * @param string $slug
     * @param string $taxonomy
     *
     * @return int|bool
     */
    public static function get_term_id_by_slug($slug, $taxonomy = 'product_cat')
    {
        global $wpdb;

        $results = $wpdb->get_var($wpdb->prepare(
            "SELECT DISTINCT t.term_id
			FROM wp_term_taxonomy AS tt
			INNER JOIN wp_terms AS t ON tt.term_id = t.term_id
			WHERE t.slug = %s
			AND tt.taxonomy = %s",
            $slug,
            $taxonomy
        ));

        return $results ? absint($results) : false;
    }

    /**
     * Load classes.
     *
     * @param array $classes Key = filename / Value = Class name.
     * @param string $module Module folder name.
     */
    public static function load_classes($classes, $module, $root = REYHOON_MODULES_PATH)
    {
        foreach ($classes as $file_name => $class_name) {
            $path = $root . $module . '/class-' . $file_name . '.php';

            if (!file_exists($path)) {
                continue;
            }

            require_once $path;

            if (!method_exists($class_name, 'run')) {
                continue;
            }

            $class_name::run();
        }
        //float button
        add_action('wp_footer', [__CLASS__, 'render_admin_float_botton']);
        add_action('admin_footer', [__CLASS__, 'render_admin_float_botton']);
    }

    public static function load_ajax_function()
    {
        //save shop location on settings
        add_action('wp_ajax_update_shop_location', [__CLASS__, 'update_shop_location']);
        add_action('wp_ajax_nopriv_update_shop_location', [__CLASS__, 'update_shop_location']);
    }

    /**
     * Get pro button.
     *
     * @param string $campaign
     * @param string $text
     * @param bool $lock_icon
     *
     * @return string
     */
    public static function get_pro_button($campaign = '', $text = '', $lock_icon = true)
    {
        $text = empty($text) ? __('Available in Pro', 'reyhoon') : $text;
        $lock_icon = $lock_icon ? '<span class="dashicons dashicons-lock"></span>' : '';

        return sprintf('<a href="%s" class="reyhoon-admin-button reyhoon-admin-button--pro" target="_blank">%s %s</a>', esc_url('https://reyhoon.avin-tarh.ir/pricing/'), $lock_icon, $text);
    }

    /**
     * Prepare post type labels.
     *
     * @param array $labels
     *
     * @return array|bool
     */
    public static function prepare_post_type_labels($labels = array())
    {
        if (empty($labels)) {
            return false;
        }

        return array(
            'name' => $labels['plural'],
            'singular_name' => $labels['singular'],
            'menu_name' => $labels['plural'],
            'name_admin_bar' => $labels['singular'],
            'add_new' => __('Add New', 'reyhoon'),
            'add_new_item' => sprintf(__('Add New %s', 'reyhoon'), $labels['singular']),
            'new_item' => sprintf(__('New %s', 'reyhoon'), $labels['singular']),
            'edit_item' => sprintf(__('Edit %s', 'reyhoon'), $labels['singular']),
            'view_item' => sprintf(__('View %s', 'reyhoon'), $labels['singular']),
            'all_items' => $labels['plural'],
            'search_items' => sprintf(__('Search %s', 'reyhoon'), $labels['plural']),
            'parent_item_colon' => sprintf(__('Parent %s:', 'reyhoon'), $labels['plural']),
            'not_found' => sprintf(__('No %s found.', 'reyhoon'), strtolower($labels['plural'])),
            'not_found_in_trash' => sprintf(__('No %s found in trash.', 'reyhoon'), strtolower($labels['plural'])),
            'featured_image' => sprintf(_x('%s Featured Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'reyhoon'), $labels['singular']),
            'set_featured_image' => _x('Set featured image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'reyhoon'),
            'remove_featured_image' => _x('Remove featured image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'reyhoon'),
            'use_featured_image' => _x('Use as featured image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'reyhoon'),
            'archives' => sprintf(_x('%s archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'reyhoon'), $labels['plural']),
            'insert_into_item' => sprintf(_x('Insert into %s', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'reyhoon'), strtolower($labels['singular'])),
            'uploaded_to_this_item' => sprintf(_x('Uploaded to this %s', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'reyhoon'), strtolower($labels['singular'])),
            'filter_items_list' => sprintf(_x('Filter %s list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'reyhoon'), strtolower($labels['plural'])),
            'items_list_navigation' => sprintf(_x('%s list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'reyhoon'), $labels['plural']),
            'items_list' => sprintf(_x('%s list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'reyhoon'), $labels['plural']),
        );
    }

    /**
     * Custom kses method so we can also modify CSS properties allowed.
     *
     * @param string $content
     * @param string $context
     *
     * @return string
     */
    public static function kses($content, $context = '')
    {
        if (empty($content)) {
            return $content;
        }

        // Modify allowed CSS.
        add_filter('safe_style_css', array(__CLASS__, 'safe_css'));

        $content = wp_kses($content, self::kses_allowed_html($context));

        // Disable CSS modification.
        remove_filter('safe_style_css', array(__CLASS__, 'safe_css'));

        return $content;
    }

    /**
     * Sanitise output and allow form elements.
     *
     * @param string $context
     *
     * @return array
     */
    public static function kses_allowed_html($context = '')
    {
        $allowed_html = wp_kses_allowed_html('post');

        if ('form' === $context) {
            $allowed_attributes = array(
                'name' => array(),
                'class' => array(),
                'value' => array(),
                'type' => array(),
                'selected' => array(),
            );

            $allowed_html['span'] = $allowed_attributes;
            $allowed_html['select'] = $allowed_attributes;
            $allowed_html['option'] = $allowed_attributes;
            $allowed_html['input'] = $allowed_attributes;
        }

        return $allowed_html;
    }

    /**
     * Modify safe CSS values.
     *
     * @param array $safe_css
     *
     * @return array
     */
    public static function safe_css($safe_css = array())
    {
        $safe_css[] = 'display';

        return $safe_css;
    }

    /**
     * Has notices?
     *
     * @return bool
     */
    public static function has_notices()
    {
        return !empty(WC()->session->get('wc_notices', array()));
    }

    /**
     * Add image to media library.
     *
     * @param string $url URL.
     * @param int $associated_with_post Post ID if media is associated to post.
     * @param string $file_name File name.
     *
     * @return bool|int|WP_Error
     */
    public static function add_to_media($url, $associated_with_post = 0, $file_name = '')
    {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $tmp = download_url($url);
        $post_id = $associated_with_post;
        $file_array = array();

        // Set variables for storage.
        // fix file filename for query strings.
        preg_match('/[^\?]+\.(jpg|jpe|jpeg|gif|png|apk)/i', $url, $matches);

        if (empty($matches)) {
            return false;
        }

        $file_array['name'] = !empty($file_name) ? $file_name : basename($matches[0]);
        $file_array['tmp_name'] = $tmp;

        // If error storing temporarily, unlink.
        if (is_wp_error($tmp)) {
            @unlink($file_array['tmp_name']);

            return false;
        }

        // do the validation and storage stuff.
        $id = media_handle_sideload($file_array, $post_id);

        // If error storing permanently, unlink.
        if (is_wp_error($id)) {
            @unlink($file_array['tmp_name']);

            return false;
        }

        return $id;
    }

    /**
     * Check for the template in theme if exits then returns the file path
     * in theme, else returns the path in plugin.
     *
     * This function simplifies the path in the theme to reyhoon/{module-slug}/template.php.
     * For example if the path of file in plugin is
     * /inc/modules/drawer/templates/floating-cart.php then the path in the theme
     * would be reyhoon/drawer/floating-cart.php.
     *
     * @param string $file File to load.
     * @param string $module Module slug example 'addons-pro'. Default: false.
     * @param bool $pro Whether to find the template in pro plugin. Default: false.
     *
     * @return string
     */
    public static function get_template_path($file, $module = false, $pro = false)
    {
        // Look for the file in theme.
        // Remove 'templates/' if it exists in the start.
        if ('templates/' === substr($file, 0, 10)) {
            $file = substr($file, 10);
        }

        $theme_path = 'reyhoon/' . $file;

        if ($module) {
            $theme_path = sprintf('reyhoon/%s/%s', $module, $file);
        }

        // If template found in the theme, then return the theme path.
        $theme_template = locate_template($theme_path);
        if ($theme_template) {
            return $theme_template;
        }

        // Else look in the plugin.

        if ($pro && !defined('REYHOON_PRO_PATH')) {
            return false;
        }

        $reyhoon_path = $pro ? REYHOON_PRO_PATH : REYHOON_PATH;

        if ($module) {
            return sprintf('%sinc/modules/%s/templates/%s', $reyhoon_path, $module, $file);
        } else {
            return $reyhoon_path . 'templates/' . $file;
        }
    }

    public static function echo_svg($name, $echo = true)
    {

        if (!file_exists(REYHOON_PATH . 'assets/svg/' . $name . '.svg')) {
            return "";
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch,CURLOPT_URL,REYHOON_ASSETS_URL . 'svg/' . $name . '.svg');
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.A.B.C Safari/525.13");
        $svg = curl_exec($ch);
        curl_close($ch);
        // $svg = file_get_contents(REYHOON_ASSETS_URL . 'svg/' . $name . '.svg');
        if ($echo) {
            echo $svg;
        } else {
            return $svg;
        }
    }

    public static function toggle_shop_status()
    {

        $reyhoon_settings = get_option('reyhoon_settings');
        $current_status = $reyhoon_settings['store_general_rey_status'];
        $new_status = $current_status == "1" ? "0" : "1";
        $reyhoon_settings['store_general_rey_status'] = $new_status;
        update_option('reyhoon_settings', $reyhoon_settings);

        wp_send_json_success();
    }

    public
    static function render_admin_float_botton()
    {
        $reyhoon_settings = get_option('reyhoon_settings');
        $current_status = $reyhoon_settings['store_general_rey_status'];
        if (current_user_can('editor') || current_user_can('administrator')) {
            ?>
            <div class="admin-float">
                <div class="toggle-icon power"><?php self::echo_svg("power") ?></div>
                <span class="divider-line"></span>
                <a href="<?= home_url() ?>/wp-admin/edit.php?post_type=shop_order&reyhoon_live_view"
                   class="toggle-icon"><?php self::echo_svg("order") ?></a>
                <span class="toggle-status <?= $current_status == '1' ? 'active' : '' ?>"></span>
            </div>
            <style>
                .admin-float {
                    display: flex;
                    position: fixed;
                    bottom: 140px;
                    <?= is_rtl() ? 'left: 15px;' : 'right: 15px;'; ?>
                    flex-direction: column;
                    justify-content: space-around;
                    box-shadow: 0px 4px 25px rgba(0, 0, 0, 0.25);
                    border-radius: 8px;
                    width: 45px;
                    align-items: center;
                    background-color: #fff;
                    z-index: 9999999999;
                }

                .divider-line {
                    width: 33px;
                    height: 1px;
                    background-color: #ECECEC;
                }

                .toggle-icon {
                    padding: 9px;
                }

                .toggle-icon.power {
                    cursor: pointer;
                }

                .toggle-status {
                    position: absolute;
                    width: 5px;
                    height: 5px;
                    background-color: #737373;
                    border-radius: 50%;
                    top: 5px;
                    right: 5px;
                }

                .toggle-status.active {
                    background-color: #49B965;
                }
            </style>
            <script>
                jQuery(document).ready(function ($) {
                    $('.power').on('click', function () {
                        $(this).siblings('.toggle-status').toggleClass('active');

                        $.ajax({
                            type: "post",
                            dataType: "json",
                            url: "<?=admin_url('admin-ajax.php')?>",
                            data: {
                                action: 'toggle_shop_status',
                            },
                            success: function (data) {
                                window.location.reload();
                            },
                        });
                    })
                });
            </script>
            <?php
        }
    }

    public static function update_shop_location()
    {
        $lat = $_POST['lat'];
        $lng = $_POST['lng'];

        update_option('lat', $lat);
        update_option('lng', $lng);

        wp_send_json_success();
    }

    public static function reyhoon_swach($args = array())
    {
        $args = wp_parse_args(
            $args,
            array(
                'options' => false,
                'attribute' => false,
                'product' => false,
                'selected' => false,
                'required' => false,
                'name' => '',
                'id' => '',
                'class' => '',
            )
        );

        // Get selected value.
        if (false === $args['selected'] && $args['attribute'] && $args['product'] instanceof WC_Product) {
            $selected_key = 'attribute_' . sanitize_title($args['attribute']);
            // phpcs:disable WordPress.Security.NonceVerification.Recommended
            $args['selected'] = isset($_REQUEST[$selected_key]) ? wc_clean(wp_unslash($_REQUEST[$selected_key])) : $args['product']->get_variation_default_attribute($args['attribute']);
            // phpcs:enable WordPress.Security.NonceVerification.Recommended
        }

        $options = $args['options'];
        $product = $args['product'];
        $attribute = $args['attribute'];
        $name = $args['name'] ? $args['name'] : 'attribute_' . sanitize_title($attribute);
        $id = $args['id'] ? $args['id'] : sanitize_title($attribute);
        $class = $args['class'];
        $required = (bool)$args['required'];

        if (empty($options) && !empty($product) && !empty($attribute)) {
            $attributes = $product->get_variation_attributes();
            $options = $attributes[$attribute];
        }

        $html = '<ul data-id="' . esc_attr($id) . '" class="' . esc_attr($class) . ' flex">';

        if (!empty($options)) {
            if ($product && taxonomy_exists($attribute)) {
                // Get terms if this is a taxonomy - ordered. We need the names too.
                $terms = wc_get_product_terms(
                    $product->get_id(),
                    $attribute,
                    array(
                        'fields' => 'all',
                    )
                );

                foreach ($terms as $term) {
                    if (in_array($term->slug, $options, true)) {
                        $html .= '<li data-value="' . esc_attr($term->slug) . '" ' . selected(sanitize_title($args['selected']), $term->slug, false) . '>' . esc_html(apply_filters('woocommerce_variation_option_name', $term->name, $term, $attribute, $product)) . '</li>';
                    }
                }
            } else {
                foreach ($options as $option) {
                    // This handles < 2.4.0 bw compatibility where text attributes were not sanitized.
                    $selected = sanitize_title($args['selected']) === $args['selected'] ? selected($args['selected'], sanitize_title($option), false) : selected($args['selected'], $option, false);
                    $html .= '<li data-value="' . esc_attr($option) . '" ' . $selected . '>' . esc_html(apply_filters('woocommerce_variation_option_name', $option, null, $attribute, $product)) . '</li>';
                }
            }
        }

        $html .= '</ul>';

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo $html;
    }

    public static function is_smart_table()
    {
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            $user_role = $user->roles;
            if (in_array('smart_table', $user_role)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}
