<?php
/**
 * Shortcodes
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

/**
 * Shortcodes class.
 */
class Reyhoon_Shortcodes
{

    /**
     * Init.
     */
    public static function run()
    {
        add_shortcode('reyhoon_add_to_cart', array(__CLASS__, 'reyhoon_add_to_cart'));
        add_shortcode('reyhoon_orderable', array(__CLASS__, 'reyhoon_orderable'));
        add_shortcode('reyhoon_header_widget', array(__CLASS__, 'reyhoon_header_widget'));
        add_shortcode('reyhoon_toolbar_widget', array(__CLASS__, 'reyhoon_toolbar_widget'));
    }

    /**
     * Add to cart shortcode.
     *
     * @param array $args Shortcode arguments.
     *
     * @return stirng
     */
    public static function reyhoon_add_to_cart($args)
    {
        $defaults = array(
            'product_id' => -1,
        );

        $args = wp_parse_args($args, $defaults);
        $product = $args['product_id'];

        if ($product < 0) {
            global $product;
        }

        if (is_numeric($product)) {
            $product = wc_get_product($product);
        }

        if (empty($product)) {
            return;
        }

        ob_start();
        ?>
        <div class="reyhoon-product__actions-button">
            <?php
            // Phpcs:ignore -- WordPress.Security.EscapeOutput.OutputNotEscaped.
            echo Reyhoon_Products::get_add_to_cart_button($product, 'reyhoon-product__add-to-order');
            ?>
        </div>
        <?php

        return ob_get_clean();
    }

    public static function reyhoon_orderable()
    {

    }

    public static function reyhoon_header_widget()
    {
        $logo = Reyhoon_Settings::get_setting('style_style_main_logo');
        if (isset($_GET['demo'])) {
            $logo = get_template_directory_uri() . '/assets/images/' . $_GET['demo'] . '.png';
        }
        ob_start(); ?>
        <div
            class="<?php echo Reyhoon_Status::is_shop_open() ? 'reyhoon-restaurant-details' : 'reyhoon-restaurant-details reyhoon-restaurant-details-denied'; ?>">
            <div class="reyhoon-restaurant-details-logo">
                <a href="<?php echo site_url('/'); ?>"><img src="<?php echo $logo; ?>" alt="logo"></a>
                <div class="reyhoon-restaurant-branch-details">
                    <h1 class="reyhoon-restaurant-branch-name"><?= get_bloginfo('name'); ?></h1>
                    <?php
                    if (Reyhoon_Settings::get_setting('footer_footer_h_delivery_cost')) {
                        Reyhoon_Helpers::echo_svg('reyhoon_motorcycle_white');
                        ?>
                        <div class="reyhoon-restaurant-shipping-cost">
                            <p><?php _e('delivery :','reyhoon'); ?></p>
                            <strong> <?php echo Reyhoon_Shipping_Method::get_shipping_cost_by_id(); ?></strong>
                        </div>
                    <?php } else {
                        echo Reyhoon_Settings::get_setting('footer_footer_h_widget_text');
                    } ?>
                </div>
            </div>
            <div
                class="<?php echo Reyhoon_Status::is_shop_open() ? 'reyhoon-accept-orders' : 'reyhoon-denied-orders'; ?>">
                <?php Reyhoon_Status::is_shop_open() ? Reyhoon_Helpers::echo_svg('reyhoon_light_on') : Reyhoon_Helpers::echo_svg('reyhoon_light_off'); ?>
                <p class="status-order-accept"><?php _e("We are accepting orders.",'reyhoon'); ?></p>
                <p class="status-order-denied"><?php _e("The order is closed.",'reyhoon'); ?></p>
            </div>
        </div>
        <?php
        $close_message = Reyhoon_Settings::get_setting('translate_translate_close_message');
        if (!Reyhoon_Status::is_shop_open() && is_front_page()) {
            if(!Reyhoon_Settings::get_setting('store_general_rey_status')){
                $opt = array(
                    'name' => 'ryn-status',
                    'image' => Reyhoon_Helpers::echo_svg('close-status', false),
                    'header' => $close_message,
                    'body' => "<span>امکان ارائه سرویس در حال حاضر وجود ندارد.</span><div> <h3> در زمان دیگری مراجعه کنید </div>",
                );
            }else {

                $service_dates = Reyhoon_Timings::get_service_dates('delivery', false);
                if(isset($service_dates[0]['formatted'])) {
                    $first_avilabe_day = $service_dates[0]['formatted'];
                    $first_avilabe_hour = reset($service_dates[0]['slots'])['formatted'];
                    $first_avilabe_time = $first_avilabe_hour ? $first_avilabe_day. ' در ساعت ' .$first_avilabe_hour : $first_avilabe_day;
                }else{
                    $first_avilabe_time = "مشخص نشده !";
                }


                $opt = array(
                    'name' => 'ryn-status',
                    'image' => Reyhoon_Helpers::echo_svg('close-status', false),
                    'header' => __("The restaurant is closed.",'reyhoon'),
                    'body' => "<span>شما همچنان میتوانید ثبت سفارش انجام دهید.</span><div> <h3> سریعترین زمان ممکن برای تحویل سفارش: </h3> <span>{$first_avilabe_time}</span> </div>",
                );
            }
            $opt = json_encode($opt);
            ?>
            <script>
                jQuery(document).ready(function ($) {
                    let opt = <?=$opt?>;
                    opt.actions = [{
                        text: '<?= __("Show menu",'reyhoon')?>',
                        class: 'main-action',
                        callback: function (){
                            $(document.body).trigger('popup-handler', {close:true});
                        },
                    }];

                      $(document.body).trigger('popup-handler', [opt]);
                })
            </script>
            <?php
        }
        return ob_get_clean();
    }

    public static function reyhoon_toolbar_widget()
    {
        ob_start(); ?>
        <div class="ryn-toolbar">
            <a href="<?php echo site_url('/'); ?>">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_3004_971)">
                        <path d="M5 12H3L12 3L21 12H19" stroke="#071117" stroke-width="1.5" stroke-linecap="round"
                              stroke-linejoin="round"/>
                        <path
                            d="M5 12V19C5 19.5304 5.21071 20.0391 5.58579 20.4142C5.96086 20.7893 6.46957 21 7 21H17C17.5304 21 18.0391 20.7893 18.4142 20.4142C18.7893 20.0391 19 19.5304 19 19V12"
                            stroke="#071117" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path
                            d="M9 21V15C9 14.4696 9.21071 13.9609 9.58579 13.5858C9.96086 13.2107 10.4696 13 11 13H13C13.5304 13 14.0391 13.2107 14.4142 13.5858C14.7893 13.9609 15 14.4696 15 15V21"
                            stroke="#071117" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_3004_971">
                            <rect width="24" height="24" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
                <span><?php _e('first page','reyhoon'); ?></span>
            </a>

            <a href="<?php echo wc_get_account_endpoint_url('dashboard'); ?>">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_3009_985)">
                        <path
                            d="M9 7H15M9 11H15M13 15H15M5 21V5C5 4.46957 5.21071 3.96086 5.58579 3.58579C5.96086 3.21071 6.46957 3 7 3H17C17.5304 3 18.0391 3.21071 18.4142 3.58579C18.7893 3.96086 19 4.46957 19 5V21L16 19L14 21L12 19L10 21L8 19L5 21Z"
                            stroke="#071117" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_3009_985">
                            <rect width="24" height="24" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
                <span><?php _e('my orders','reyhoon'); ?></span>
            </a>

            <div class="toolbar-bg">
                <svg width="390" height="64" viewBox="0 0 390 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M390 64V0H323.801C280.081 0 238.72 36 195 36C151.28 36 109.919 0 66.1994 0H0V64H390Z" fill="white"/>
                </svg>
            </div>
        </div>
        <?php return ob_get_clean();
    }
}
