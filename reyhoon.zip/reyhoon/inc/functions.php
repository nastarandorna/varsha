<?php

// Save billing_name and billing_phone fields to user meta
add_action('woocommerce_created_customer', 'save_billing_name_and_phone', 10, 3);
function save_billing_name_and_phone($customer_id, $new_customer_data, $password_generated)
{
    if (isset($_POST['billing_first_name'])) {
        update_user_meta($customer_id, 'billing_first_name', sanitize_text_field($_POST['billing_first_name']));
    }
    if (isset($_POST['billing_phone'])) {
        update_user_meta($customer_id, 'billing_phone', sanitize_text_field($_POST['billing_phone']));
    }
}
