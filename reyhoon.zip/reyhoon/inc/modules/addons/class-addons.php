<?php
/**
 * Module: Addons.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Addons module class.
 */
class Reyhoon_Addons {
	/**
	 * Init.
	 */
	public static function run() {
		add_filter( 'reyhoon_valid_admin_pages', array( __CLASS__, 'add_valid_admin_pages' ) );
		add_action( 'admin_menu', array( __CLASS__, 'add_settings_page' ) );
	}

	/**
	 * Add valid admin page.
	 */
	public static function add_valid_admin_pages( $pages = array() ) {
		$pages[] = 'reyhoon-product-addons';

		return $pages;
	}

	/**
	 * Add settings page.
	 */
	public static function add_settings_page() {
		add_submenu_page(
            'reyhoon',
            __( 'Product Addons', 'reyhoon' ),
            sprintf( '%s <span class="update-plugins" style="background-color: #ffffff1c"><span class="plugin-count">%s</span></span>',
                __( 'Addons', 'reyhoon' ), __( 'Pro', 'reyhoon' ) ),
            'manage_options',
            'reyhoon-product-addons',
            array( __CLASS__, 'product_addons_page' ),
            10 );
	}

	/**
	 * Product addons page.
	 */
	public static function product_addons_page() {
		Reyhoon_Settings::upgrade_page_content( __( 'Product Addons', 'reyhoon' ) );
	}
}
