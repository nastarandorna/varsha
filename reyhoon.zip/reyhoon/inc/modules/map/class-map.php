<?php
/**
 * Map methods.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

class Reyhoon_Map
{

    public static function run()
    {
        if(!empty(Reyhoon_Settings::get_setting('store_general_map_api')) && Reyhoon_Settings::get_setting('store_general_map_api') != '') {
            add_filter('upload_mimes', [__CLASS__, 'grant_geojson_types'], 10, 1);
            add_action('wp_enqueue_scripts', array(__CLASS__, 'frontend_assets'));
            add_action('admin_enqueue_scripts', array(__CLASS__, 'frontend_assets'));
            self::get_geo_json();
        }
    }

    public static function frontend_assets()
    {


        //scripts
        wp_register_script('rey-env',REYHOON_URL . 'inc/modules/map/assets/js/mapp.env.js', array('jquery'), REYHOON_VERSION, ['strategy' => 'defer'] );
        wp_register_script('rey-mapp',REYHOON_URL . 'inc/modules/map/assets/js/mapp.min.js', array('rey-env'), REYHOON_VERSION, ['strategy' => 'defer'] );
        wp_register_script('rey-map',REYHOON_URL . 'inc/modules/map/assets/js/rey-map.js', array('rey-mapp'), REYHOON_VERSION, ['strategy' => 'defer'] );
        wp_localize_script('rey-map','mapObj',array(
            'api_key' => Reyhoon_Settings::get_setting('store_general_map_api'),
            'is_pro' => class_exists('Reyhoon_Pro'),
            'lat' => get_option('lat'),
            'lng' => get_option('lng'),
            'ajaxurl' => admin_url('admin-ajax.php'),
        ));

        wp_register_style('rey-mapp-style',REYHOON_URL . 'inc/modules/map/assets/css/mapp.min.css', array(), REYHOON_VERSION );
        wp_register_style('rey-map',REYHOON_URL . 'inc/modules/map/assets/css/rey-map.css', array('rey-mapp-style'), REYHOON_VERSION );
        wp_register_style('rey-map-style',REYHOON_URL . 'inc/modules/map/assets/css/style.css', array('rey-mapp-style'), REYHOON_VERSION );

        if((is_checkout() && is_user_logged_in()) || (is_admin() || Reyhoon_Settings::is_settings_page())){

            wp_enqueue_script('rey-map');

            wp_enqueue_style('rey-mapp-style');
            wp_enqueue_style('rey-map');
            wp_enqueue_style('rey-map-style');
        }
    }



    public static function get_geo_json()
    {
        return Reyhoon_Settings::get_setting('store_general_map_geo');

    }


    public static function grant_geojson_types($mime_types)
    {
        $mime_types['geojson'] = 'text/plain';
        return $mime_types;
    }

}
