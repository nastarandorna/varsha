globalThis.Your_API_Key = mapObj.api_key;
jQuery(document).ready(function ($) {
    console.log('map')
    let app = null;
    $('.user-address-btn').on('click', function () {

        if(app === null){
            app = new Mapp({
                element: '#app',
                presets: {
                    latlng: {
                        lat: mapObj.lat,
                        lng: mapObj.lng
                    },
                    zoom: 20
                },
                locale: 'fa',
                apiKey: Your_API_Key
            });
            var have_stage = false;
            //geofence api handler object
            var geofence = {
                deleteMode: false,
                checkMode: false,
                setApiKey: function (apiKey) {
                    this.apiKey = Your_API_Key;
                },
                getStages: function (calback) {
                    $.ajax({
                        url: 'https://map.ir/geofence/stages',
                        headers: {
                            'x-api-key': this.apiKey
                        },
                        method: 'GET',
                        statusCode: {
                            404: function () {
                                const data = {
                                    'odata.count': 0,
                                    value: []
                                };
                                calback(data);
                            },
                            401: function () {
                                const data = {error: 401};
                                calback(data);
                            }
                        }
                    }).done(function (data) {
                        have_stage = true;
                        calback(data);
                    });
                },
                checkPoint: function (data, calback) {
                    $.ajax({
                        url:
                            'https://map.ir/geofence/boundaries?lat=' +
                            data.lat +
                            '&lon=' +
                            data.lng,
                        headers: {
                            'Content-Type': 'application/json',
                            'x-api-key': this.apiKey
                        },
                        method: 'GET',
                        statusCode: {
                            404: function () {
                                const data = {
                                    'odata.count': 0,
                                    value: []
                                };
                                calback(data);
                            }
                        }
                    }).done(function (data) {
                        calback(data);
                    });
                }
            };

            app.addGeolocation({
                onLoad: false,
            });

            app.addVectorLayers({
                base: {
                    default: {
                        style: "https://map.ir/vector/styles/main/mapir-Dove-style.json"
                    }
                }
            });


            app.map.on('dragend', function (e) {
                if (mapObj.is_pro) {
                    isInArea(app.map.getCenter());
                }
                getAddress(app.map.getCenter());
            });

            /* $('.reyhoon-address-drawer-accept-address').click(function (e) {
                 e.preventDefault();
                 getAddress(app.map.getCenter());
             });*/

            function getAddress(position) {
                var addLat = position.lat;
                var addLong = position.lng;
                let positionDom = $('.map-with-address');
                $.ajax({
                    url: `https://map.ir/reverse/?lat=${addLat}&lon=${addLong}`,
                    method: 'GET',
                    beforeSend: function (request) {
                        request.setRequestHeader('x-api-key', Your_API_Key);
                        request.setRequestHeader('content-type', 'application/json');
                    },
                    success: function (data, status) {

                        primary = data.address_compact;
                        positionDom.attr('data-lat', addLat);
                        $('#lat').val(addLat);
                        positionDom.attr('data-lng', addLong);
                        $('#lng').val(addLong);
                        $('#billing_address_1').text(primary);

                    },
                    error: function (error) {
                        console.log(error);
                    }
                });

            }

            function isInArea(position) {
                if (!have_stage) {
                    return;
                }
                let addrbutton = $('.confirm-location-button');
                let inAreaHtml = "<span class=\"confirm-location-button\">\n" +
                    "   <svg width=\"25\" height=\"25\" viewBox=\"0 0 25 25\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n" +
                    "      <g clip-path=\"url(#clip0_972_69)\">\n" +
                    "         <path d=\"M5.20825 12.5001L10.4166 17.7084L20.8333 7.29175\" stroke=\"white\" stroke-width=\"1.7\"\n" +
                    "            stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n" +
                    "      </g>\n" +
                    "      <defs>\n" +
                    "         <clipPath id=\"clip0_972_69\">\n" +
                    "            <rect width=\"25\" height=\"25\" fill=\"white\"/>\n" +
                    "         </clipPath>\n" +
                    "      </defs>\n" +
                    "   </svg>\n" +
                    "   تایید لوکیشن\n" +
                    "</span>";

                let outOfAreaHtml = "<span class=\"confirm-location-button\">\n" +
                    "   <svg width=\"26\" height=\"25\" viewBox=\"0 0 26 25\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n" +
                    "      <g clip-path=\"url(#clip0_2243_3574)\">\n" +
                    "         <path d=\"M19.25 6.25L6.75 18.75\" stroke=\"white\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n" +
                    "         <path d=\"M6.75 6.25L19.25 18.75\" stroke=\"white\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n" +
                    "      </g>\n" +
                    "      <defs>\n" +
                    "         <clipPath id=\"clip0_2243_3574\">\n" +
                    "            <rect width=\"25\" height=\"25\" fill=\"white\" transform=\"translate(0.5)\"/>\n" +
                    "         </clipPath>\n" +
                    "      </defs>\n" +
                    "   </svg>\n" +
                    "   این مکان خارج از محدوده است\n" +
                    "</span>\n";
                geofence.checkPoint(position, function (data) {

                    if (data['odata.count'] === 0) {
                        showMessage('نقطه مورد نظر در هیچ محدوده ای قرار ندارد');
                        addrbutton.parent('button').addClass('disable');
                        addrbutton.replaceWith(outOfAreaHtml);
                    } else {
                        showMessage(
                            `نقطه مورد نظر در ${data['odata.count']} محدوده قرار دارد.`,
                            'success'
                        );
                        addrbutton.parent('button').removeClass('disable');
                        addrbutton.replaceWith(inAreaHtml);
                    }
                });
            }

            function showMessage(text, type) {
                let bgcolor;
                if (type === 'success') {
                    bgcolor = 'green';
                } else if (type === 'error') {
                    bgcolor = '#ed205a';
                } else {
                    bgcolor = 'orange';
                }
                $('#message').css('background-color', bgcolor);
                $('#message').text(text);
                $('#message')
                    .fadeIn('fast')
                    .animate({opacity: 1.0}, 1000)
                    .fadeOut('fast');
            }

            function showBoundaries(data) {
                data.value.forEach((item, index) => {
                    app.addPolygon({
                        name: item.id,
                        style: {
                            clickable: true,
                            stroke: true,
                            color: '#4584f0',
                            weight: 2,
                            opacity: 0.8,
                            smoothFactor: 1,
                            fill: true,
                            fillColor: '#FFFFFF',
                            fillOpacity: 0.1
                        },
                        coordinates: item.boundary.coordinates[0].map(item => item.reverse()),
                        popup: false,
                    });
                });
            }

            //check api key
            if (Your_API_Key) {
                geofence.setApiKey(Your_API_Key);
                geofence.getStages(function (data) {
                    if (data['error'] === 401) {
                        $('.popup-token').html(
                            'لطفا Api Key معتبر وارد کنید<br/><li><a href="https://corp.map.ir/registration/" target="_blank">دریافت Api Key</a></li>'
                        );
                        $('.popup-token').show();
                        $('#app').hide();
                        $('.top-btn-container').hide();
                    } else {
                        if (data['odata.count'] === 0) {
                            showMessage('شما قبلا هیچ محدوده ای ثبت نکرده اید');
                        } else {
                            showMessage('محدوده ها دریافت شدند', 'success');

                            showBoundaries(data);
                        }
                        $('.popup-token').hide();
                        $('#app').css('opacity', 1);
                    }
                });
            } else {
                $('.popup-token').show();
                $('#app').hide();
                $('.top-btn-container').hide();
            }
        }


    });
    $('.map_container').on('click', function () {
        if(app === null){
            $(this).removeClass('map-preloader');
            app = new Mapp({
                element: '#app',
                presets: {
                    latlng: {
                        lat: mapObj.lat,
                        lng: mapObj.lng
                    },
                    zoom: 12
                },
                apiKey: Your_API_Key,
            });

            var lat = app.map.getCenter().lat;
            var lng = app.map.getCenter().lng;
            app.addVectorLayers({
                base: {
                    default: {
                        style: "https://map.ir/vector/styles/main/mapir-Dove-style.json"
                    }
                }
            });

            app.map.on('dragend', function (e) {
                lat = app.map.getCenter().lat;
                lng = app.map.getCenter().lng;
            });
            $('.verify-location').click(function () {
                $.ajax({
                    type: "POST",
                    url: mapObj.ajaxurl,
                    data: {
                        'action': 'update_shop_location',
                        'lat': lat,
                        'lng': lng,
                    },
                    success: function () {
                        alert('موقعیت تایید شد.')
                    }
                })
            })
        }
    })
});
