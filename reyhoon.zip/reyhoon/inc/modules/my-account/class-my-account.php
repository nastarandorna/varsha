<?php
/**
 * My Account methods.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

class Reyhoon_My_Account
{
    public static function run()
    {
        add_action('wp_enqueue_scripts', [__CLASS__, 'load_assets']);
        add_filter('woocommerce_account_menu_items', [__CLASS__, 'my_account_menu']);
        add_action('reyhoon_after_header', [__CLASS__, 'reyhoon_account_navigation'], 15);
    }

    public static function load_assets()
    {

        if (is_account_page()) {
            $suffix_css = is_rtl() ? '-rtl' : '';

            wp_enqueue_style('ryn-account', REYHOON_URL . 'inc/modules/my-account/assets/css/ryn-account' . $suffix_css . '.css', array(), REYHOON_VERSION);
            wp_enqueue_script('ryn-account', REYHOON_URL . 'inc/modules/my-account/assets/js/ryn-account.js', array('jquery'), REYHOON_VERSION, true);
        }
    }

    public static function my_account_menu($menu_items)
    {
        unset($menu_items['orders']);
        unset($menu_items['downloads']);
        return $menu_items;
    }

    public static function reyhoon_account_navigation()
    {
        if (is_account_page() && is_user_logged_in()) {
            $user = wp_get_current_user();
            $wallet_endpoint = Reyhoon_Settings::get_setting('store_general_wallet_endpoint');
            ?>

            <div class="account-detail">
                <a href="<?= wc_get_account_endpoint_url('edit-account') ?>">
                    <div class="info">
                        <p><?= $user->first_name ?></p>
                        <span> <?php _e("Edit User Information", 'reyhoon'); ?> <?= Reyhoon_Helpers::echo_svg('arrow-left') ?></span>
                    </div>
                </a>
                <a href="<?= wc_get_account_endpoint_url('customer-logout') ?>">
                    <div class="logout">
                        <span><?php _e("Log Out", 'reyhoon'); ?></span><?= Reyhoon_Helpers::echo_svg('exit') ?></div>
                </a>
            </div>
            <div class="nav-container">
                <div class="nav-wrapper">
                    <a href="<?= wc_get_account_endpoint_url('dashboard') ?>">
                        <div
                                class="nav-box <?= is_user_logged_in() && is_account_page() && !is_wc_endpoint_url() ? 'is-active' : '' ?>">
                            <div class="nav-item"><?= Reyhoon_Helpers::echo_svg('orders') ?></div>
                            <p><?php _e("Orders", 'reyhoon'); ?></p>
                        </div>
                    </a>
                    <a href="<?= wc_get_account_endpoint_url($wallet_endpoint) ?>">
                        <div class="nav-box <?= is_wc_endpoint_url($wallet_endpoint) ? 'is-active' : '' ?> "
                             <?=empty($wallet_endpoint) ? 'style="opacity: 0.5;"' : ''?>>
                            <div class="nav-item"><?= Reyhoon_Helpers::echo_svg('wallet') ?></div>
                            <p><?php _e("Wallet", 'reyhoon'); ?></p>
                        </div>
                    </a>
                    <a href="<?= wc_get_account_endpoint_url('edit-address') ?>">
                        <div class="nav-box <?= is_wc_endpoint_url('edit-address') ? 'is-active' : '' ?>">
                            <div class="nav-item"><?= Reyhoon_Helpers::echo_svg('address') ?></div>
                            <p><?php _e("Addresses", 'reyhoon'); ?></p>
                        </div>
                    </a>
                </div>
            </div>
            <?php
        }
    }
}
