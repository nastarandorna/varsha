<?php
/**
 * Module: Translate.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

/**
 * Translate module class.
 */
class Reyhoon_Translate
{

    /**
     * Init.
     */
    public static function run()
    {
        add_action('wp_enqueue_scripts', [__CLASS__, 'load_assets']);
        add_filter('reyhoon_default_settings', array(__CLASS__, 'default_settings'));
        add_filter('wpsf_register_settings_reyhoon', array(__CLASS__, 'register_settings'), 20);

    }

    public static function load_assets()
    {

    }

    /**
     * Add default settings.
     *
     * @param array $default_settings
     *
     * @return array
     */
    public static function default_settings($default_settings = array())
    {
        return $default_settings;
    }

    /**
     * Register settings.
     *
     * @param array $settings
     *
     * @return array
     */
    public static function register_settings($settings = array())
    {
        $settings['tabs'][] = array(
            'id' => 'translate',
            'title' => __('translate','reyhoon'),
            'priority' => 110,
        );

        $settings['sections'][] = array(
            'tab_id' => 'translate',
            'section_id' => 'translate',
            'section_title' => __("Translate Theme Strings",'reyhoon'),
            'section_description' => '',
            'section_order' => 0,
            'fields' => array(
                array(
                    'id' => 'bump_title',
                    'title' => __('محصولات پیشنهادی','reyhoon'),
                    'subtitle' => __('عنوانی که محصولات پیشنهادی که در انتهای سبد خرید نمایش داده می شود. ','reyhoon'),
                    'type' => 'text',
                    'default' =>  __('نوشیدنی و سالاد؟','reyhoon'),
                ),
                array(
                    'id' => 'close_message',
                    'title' => __('بسته بودن رستوران','reyhoon'),
                    'type' => 'text',
                    'default' =>  __('رستوران بسته است','reyhoon'),
                ),
                array(
                    'id' => 'waiting_message',
                    'title' => __('وضعیت انتظار سفارشات','reyhoon'),
                    'type' => 'text',
                    'default' =>  __('در انتظار تایید رستوران','reyhoon'),
                ),
                array(
                    'id' => 'processing_message',
                    'title' => __('وضعیت آماده شدن سفارشات','reyhoon'),
                    'type' => 'text',
                    'default' =>  __('در حال آماده سازی','reyhoon'),
                ),
                array(
                    'id' => 'completed_message',
                    'title' => __('وضعیت اتمام سفارشات','reyhoon'),
                    'type' => 'text',
                    'default' =>  __('تحویل داده شده','reyhoon'),
                ),
                array(
                    'id' => 'on_way_message',
                    'title' => __('وضعیت ارسال سفارشات','reyhoon'),
                    'type' => 'text',
                    'default' =>  __('پیک در راه','reyhoon'),
                ),
                array(
                    'id' => 'no_order_message',
                    'title' => __('پیغام عدم ثبت سفارش','reyhoon'),
                    'type' => 'text',
                    'default' =>  __('شما هنوز سفارشی ثبت نکرده اید.','reyhoon'),
                ),
                array(
                    'id' => 'return_shop_message',
                    'title' => __('پیغام نمایش فروشگاه ','reyhoon'),
                    'type' => 'text',
                    'default' =>  __('بازگشت به منو مجموعه','reyhoon'),
                ),
                array(
                    'id'            => 'upload_img',
                    'type'          => 'File',
                    'title'         =>  __('آپلود عکس','reyhoon'),
                    'subtitle' => __('عکسی که در صفحه ی حساب کاربری نمایش داده میشود ','reyhoon'),
                    'settings'      => array(
                        'upload_type'  => 'image',
                        'button_title' => 'Upload',
                        'frame_title'  => 'Select an image',
                    ),
                ),

            ),



        );

        return $settings;
    }


}
