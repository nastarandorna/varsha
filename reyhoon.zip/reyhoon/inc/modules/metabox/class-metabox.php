<?php
/**
 * Metabox methods.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

class Reyhoon_MetaBox
{

    private static $options;

    public static function run()
    {

        self::$options = array(
            array(
                'id' => 'reyhoon_metabox',
               // 'title' => __('More settings', 'reyhoon','reyhoon'),
                //FIXME check translate
                'title' => 'تنظیمات بیشتر',
                'post_type' => 'product',
                'context' => 'normal',
                'priority' => 'default',
                'sections' => array(
                    array(
                        'name' => 'packaging',
                    //    'title' => __('Packaging settings', 'reyhoon'),
                        'title' => 'بسته بندی',
                        'icon' => 'fa fa-price',
                        'fields' => array(
                            array(
                                'id' => 'cost',
                                'type' => 'text',
                               // 'title' => __('Packaging cost', 'reyhoon'),
                                'title' => 'هزینه بسته بندی',
                            ),
                        ),
                    ),
                ),
            ),
        );

        add_action('add_meta_boxes', [__CLASS__, 'init_metabox']);
        add_action('save_post', [__CLASS__, 'reyhoon_save_metabox_data']);
    }

    public static function init_metabox()
    {
        foreach (self::$options as $option) {
            add_meta_box(
                $option['id'],
                $option['title'],
                [__CLASS__, 'reyhoon_render_metabox'],
                $option['post_type'],
                $option['context'],
                $option['priority'],
                $option
            );
        }
    }

    public static function reyhoon_render_metabox($post, $metabox)
    {
        $options = $metabox['args']['sections'];

        echo '<input type="hidden" name="reyhoon_metabox_nonce" value="' . wp_create_nonce('reyhoon_metabox_nonce') . '">';
        // Output HTML for your metabox fields based on the $options array
        foreach ($options as $section) {
            echo '<h3>' . esc_html($section['title']) . '</h3>';
            foreach ($section['fields'] as $field) {
                $value = get_post_meta($post->ID, $metabox['args']['id'] . '_' . $section['name'] . '_' . $field['id'], true);
                echo '<label for="' . esc_attr($field['id']) . '" style="margin-left: 12px;">' . esc_html($field['title']) . '</label>';
                echo '<input type="' . esc_attr($field['type']) . '" id="' . esc_attr($field['id']) . '" name="' . esc_attr($metabox['args']['id'] . '_' . $section['name'] . '_' . $field['id']) . '" value="' . esc_attr($value) . '">';
            }
        }
    }

    public static function reyhoon_save_metabox_data($post_id)
    {
// Check if the nonce is set.
        if (!isset($_POST['reyhoon_metabox_nonce'])) {
            return;
        }

// Verify that the nonce is valid.
        if (!wp_verify_nonce($_POST['reyhoon_metabox_nonce'], 'reyhoon_metabox_nonce')) {
            return;
        }

// If this is an autosave, our form has not been submitted, so we don't want to do anything.
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

// Check the user's permissions.
        if ('page' === $_POST['post_type']) {
            if (!current_user_can('edit_page', $post_id)) {
                return;
            }
        } else {
            if (!current_user_can('edit_post', $post_id)) {
                return;
            }
        }

// Save the data.
        foreach (self::$options as $option) {
            foreach ($option['sections'] as $section) {
                foreach ($section['fields'] as $field) {
                    $meta_key = $option['id'] . '_' . $section['name'] . '_' . $field['id'];
                    $meta_value = sanitize_text_field($_POST[$meta_key]);
                }
            }
        }
    }
}
