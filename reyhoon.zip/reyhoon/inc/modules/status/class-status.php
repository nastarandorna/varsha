<?php
/**
 * Status methods.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

class Reyhoon_Status
{

    public static $open_hours_key = 'store_general_open_hours';

    public static function run()
    {
        self::is_shop_open();
        add_action('wp_ajax_toggle_shop_status','Reyhoon_Helpers::toggle_shop_status');
        add_action('wp_ajax_nopriv_toggle_shop_status','Reyhoon_Helpers::toggle_shop_status');
    }

    public static function is_shop_open()
    {

        if(!Reyhoon_Settings::get_setting('store_general_rey_status')){
            return false;
        }
        if(Reyhoon_Settings::get_setting('store_general_rey_full_time')){
            return true;
        }


        date_default_timezone_set(get_option('timezone_string'));
        $now = date("H:i");
        $day_of_week = date('w');
        $open_hours_settings = Reyhoon_Settings::get_setting(self::$open_hours_key);

        $is_enable_day = isset($open_hours_settings[$day_of_week]['enabled']) && $open_hours_settings[$day_of_week]['enabled'] == 1 ? true : false;
        if ($is_enable_day) {

            $open_from = Reyhoon_Timings::convert_time_to_24_hour($open_hours_settings[$day_of_week]['from']);
            $open_to = Reyhoon_Timings::convert_time_to_24_hour($open_hours_settings[$day_of_week]['to']);
            $open_from = $open_from['hour'] . ":" . $open_from['minute'];
            $open_to = $open_to['hour'] . ":" . $open_to['minute'];

            return self::is_in_time_range($open_from, $open_to, $now);

        } else {
            return false;
        }

    }

    public static function is_in_time_range($start, $end, $time)
    {
        $s = DateTime::createFromFormat('!H:i', $start);
        $e = DateTime::createFromFormat('!H:i', $end);
        $t = DateTime::createFromFormat('!H:i', $time);

        return ($s <= $t && $t <= $e);
    }


}
