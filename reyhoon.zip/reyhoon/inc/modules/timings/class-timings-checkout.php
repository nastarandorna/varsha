<?php
/**
 * Module: Timings checkout.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Timings checkout class.
 */
class Reyhoon_Timings_Checkout {
	/**
	 * Init.
	 */
	public static function run() {
		add_action( 'woocommerce_review_order_before_submit', array( __CLASS__, 'output_timing_fields' ) );
		add_action( 'woocommerce_checkout_process', array( __CLASS__, 'validate_checkout' ) );
		add_action( 'woocommerce_checkout_update_order_meta', array( __CLASS__, 'process_checkout' ) );
		add_filter( 'woocommerce_order_button_html', array( __CLASS__, 'place_order_button' ) );
	}

	/**
	 * Output timing fields at checkout.
	 *
	 * @throws Exception
	 */
	public static function output_timing_fields() {
		if ( ! self::has_available_methods() ) {
			return;
		}

		$service       = Reyhoon_Services::get_selected_service( true );
		$service_dates = Reyhoon_Timings::get_service_dates();
		$asap          = Reyhoon_Timings::get_asap_setting();

		// No dates required.
		if ( true === $service_dates ) {
			return;
		} ?>

		<?php if ( false === $service_dates ) { ?>
			<div class="reyhoon-order-timings reyhoon-order-timings--no-dates">
				<div>
					<?php
					// Translators: %s Service type.
					printf( __( '%s Date', 'reyhoon' ), $service );
					?>
				</div>
				<div>
					<ul class="woocommerce-error" role="alert" style="margin-bottom: 0;">
						<li>
							<?php
							// Translators: %s Service type.
							printf( __( 'Sorry, there are currently no slots available for %s.', 'reyhoon' ), strtolower( $service ), $service );
							?>
						</li>
					</ul>
				</div>
			</div>
		<?php } else { ?>
			<div class="reyhoon-order-timings-container">
                <div class="reyhoon-order-timings-header">
                    <div>
                        <label for="reyhoon-date">
		                    <?php
		                    // Translators: %s Service type.
		                   // printf( __( '%s Date', 'reyhoon' ), $service );
                            printf("تاریخ و ساعت تحویل:");
                            printf("<br> ابتدا روز را انتخاب کنید .");
                            printf("<br> و ساعت را بصورت کشویی در زیر مشخص کنید.");
		                    ?>
                        </label>
                        <div id="current_date_time_header">در حال محاسبه ...</div>
                    </div>
                    <button type="button">
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1380_2314)">
                                <path d="M3.6665 18.3333H7.33317L16.9582 8.70829C17.4444 8.22206 17.7176 7.56259 17.7176 6.87495C17.7176 6.18732 17.4444 5.52785 16.9582 5.04162C16.4719 4.55539 15.8125 4.28223 15.1248 4.28223C14.4372 4.28223 13.7777 4.55539 13.2915 5.04162L3.6665 14.6666V18.3333Z" stroke="#036666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M12.375 5.95837L16.0417 9.62504" stroke="#036666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_1380_2314">
                                    <rect width="22" height="22" fill="white"/>
                                </clipPath>
                            </defs>
                        </svg>
                        تغییر زمان
                    </button>
                </div>
                <div id="date_time_timings">
                    <div class="reyhoon-order-timings reyhoon-order-timings--date">
                        <div>
                            <select name="reyhoon_order_date" id="reyhoon-date" class="reyhoon-order-timings__date">
                                <option value=""><?php _e( 'Select a date...', 'reyhoon' ); ?></option>
				                <?php if ( is_array( $asap ) && in_array( 'day', $asap, true ) ) { ?>
                                    <option value="asap"><?php esc_html_e( 'As soon as possible', 'reyhoon' ); ?></option>
				                <?php } ?>
				                <?php foreach ( $service_dates as $service_date_data ) { ?>
                                    <option value="<?php echo esc_attr( $service_date_data['timestamp'] ); ?>" data-reyhoon-slots="<?php echo wc_esc_json( json_encode( array_values( $service_date_data['slots'] ) ) ); ?>"><?php echo $service_date_data['formatted']; ?></option>
				                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="reyhoon-order-timings reyhoon-order-timings--time" style="display: none;">
                        <div>
                            <label for="reyhoon-time">
                                <strong>
					                <?php
					                // Translators: %s Service type.
					                printf( __( '%s Time', 'reyhoon' ), $service );
					                ?>
                                </strong>
                            </label>
                        </div>

                        <div>
                            <select name="reyhoon_order_time" id="reyhoon-time" class="reyhoon-order-timings__time" disabled="disabled">
                                <option value=""><?php _e( 'Select a time...', 'reyhoon' ); ?></option>
				                <?php if ( in_array( 'slot', $asap, true ) ) { ?>
                                    <option value="asap"><?php esc_html_e( 'As soon as possible', 'reyhoon' ); ?></option>
				                <?php } ?>
                            </select>
                            <ul id="reyhoon-time-clone">

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
		<?php } ?>
		<?php
	}

	/**
	 * Validate checkout fields.
	 */
	public static function validate_checkout() {
		$order_date = filter_input( INPUT_POST, 'reyhoon_order_date', FILTER_SANITIZE_STRING );

		if ( isset( $_POST['reyhoon_order_date'] ) && empty( $order_date ) ) {
			wc_add_notice( __( 'Please select an order date.', 'reyhoon' ), 'error' );
		}
	}

	/**
	 * Process checkout fields.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @throws Exception
	 */
	public static function process_checkout( $order_id ) {
		$checkout_data = self::get_checkout_data();

		if ( empty( $checkout_data ) ) {
			return;
		}

		foreach ( $checkout_data as $key => $data ) {
			if ( ! $data['save'] ) {
				continue;
			}

			update_post_meta( $order_id, $key, $data['value'] );
		}
	}

	/**
	 * Get posted checkout data.
	 *
	 * @return mixed|void
	 * @throws Exception
	 */
	public static function get_checkout_data() {
		$data = array();

		$order_date = filter_input( INPUT_POST, 'reyhoon_order_date', FILTER_SANITIZE_STRING );

		if ( $order_date && 'asap' !== $order_date ) {
			$date_format          = get_option( 'date_format' );
			$timestamp_adjusted   = $order_date + Reyhoon_Timings::get_timezone_offset( $order_date );
			$order_date_formatted = date_i18n( $date_format, $timestamp_adjusted );

			$data['_reyhoon_order_timestamp'] = array(
				'save'  => true,
				'value' => absint( $order_date ),
			);

			$data['reyhoon_order_date'] = array(
				'save'  => true,
				'value' => sanitize_text_field( $order_date_formatted ),
			);
		}

		if ( $order_date && 'asap' === $order_date ) {
			$dates = Reyhoon_Timings::get_service_dates();

			if ( ! $dates ) {
				return;
			}

			$earliest_order_date  = $dates[0]['timestamp'];
			$date_format          = get_option( 'date_format' );
			$timestamp_adjusted   = $earliest_order_date + Reyhoon_Timings::get_timezone_offset( $earliest_order_date );
			$order_date_formatted = date_i18n( $date_format, $timestamp_adjusted );

			$data['_reyhoon_order_timestamp'] = array(
				'save'  => true,
				'value' => absint( $earliest_order_date ),
			);

			$data['reyhoon_order_date'] = array(
				'save'  => true,
				'value' => sanitize_text_field( $order_date_formatted ) . esc_html__( ' (As soon as possible)', 'reyhoon' ),
			);
		}

		return apply_filters( 'reyhoon_checkout_data', $data );
	}

	/**
	 * Has available shipping methods.
	 *
	 * @return bool
	 */
	public static function has_available_methods() {
		$has_available_methods = false;
		$packages              = WC()->shipping()->get_packages();

		if ( ! empty( $packages ) ) {
			foreach ( $packages as $i => $package ) {
				if ( empty( $package['rates'] ) ) {
					continue;
				}

				$has_available_methods = true;
				break;
			}
		}

		return apply_filters( 'reyhoon_has_available_methods', $has_available_methods );
	}

	/**
	 * Modify place order button.
	 */
	public static function place_order_button( $button_html ) {
		$service_dates = Reyhoon_Timings::get_service_dates();

		if ( $service_dates ) {
			return $button_html;
		}

		if ( strpos( $button_html, 'disabled' ) !== false ) {
			return $button_html;
		}

		$button_html = str_replace( '<button', '<button disabled', $button_html );

		return $button_html;
	}
}
