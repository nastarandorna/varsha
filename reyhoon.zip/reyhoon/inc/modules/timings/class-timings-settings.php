<?php
/**
 * Timings settings.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

/**
 * Timings settings class.
 */
class Reyhoon_Timings_Settings
{
    /**
     * Open hours settings key.
     *
     * @var string
     */
    public static $open_hours_key = 'store_general_open_hours';

    /**
     * Service hours settings key.
     *
     * @var string
     */
    public static $service_hours_key = 'store_general_service_hours';

    /**
     * Holidays settings key.
     *
     * @var string
     */
    public static $holidays_key = 'holidays';

    /**
     * Init.
     */
    public static function run()
    {
        add_filter('reyhoon_default_settings', array(__CLASS__, 'default_settings'));
        add_filter('wpsf_register_settings_reyhoon', array(__CLASS__, 'register_settings'), 20);
        add_filter('reyhoon_settings_validate', array(__CLASS__, 'validate_settings'), 10);
    }

    /**
     * Add default settings.
     *
     * @param array $default_settings
     *
     * @return array
     */
    public static function default_settings($default_settings = array())
    {
        $default_settings[self::$open_hours_key] = array();
        $default_settings[self::$service_hours_key . '_delivery'] = array(
            array(
                'days' => array(),
                'period' => 'all-day',
                'from' => array(),
                'to' => array(),
                'frequency' => '',
                'cutoff' => '',
                'max_orders' => '',
            ),
        );
        $default_settings[self::$service_hours_key . '_pickup'] = array(
            array(
                'days' => array(),
                'period' => 'all-day',
                'from' => array(),
                'to' => array(),
                'frequency' => '',
                'cutoff' => '',
                'max_orders' => '',
            ),
        );
        $default_settings[self::$holidays_key] = array(
            array(
                'from' => '',
                'to' => '',
                'services' => array(),
                'repeat' => 0,
            ),
        );

        $default_settings['store_general_lead_time'] = 0;
        $default_settings['store_general_preorder'] = 2;
        $default_settings['store_general_service_hours_pickup_same'] = 1;
        $default_settings['store_general_calculation_method'] = 'service';

        return $default_settings;
    }

    /**
     * Register settings.
     *
     * @param array $settings
     *
     * @return array
     */
    public static function register_settings($settings = array())
    {
        $settings['tabs'][] = array(
            'id' => 'store',
            'title' => __('Store Settings', 'reyhoon'),
            'priority' => 10,
        );

        $settings['sections']['store_general'] = array(
            'tab_id' => 'store',
            'section_id' => 'general',
            'section_title' => __('Store Settings', 'reyhoon'),
            'section_description' => '',
            'section_order' => 0,
            'fields' => array(
                array(
                    'id' => 'rey_status',
                    'title' => __('restaurant_service', 'reyhoon'),
                    'subtitle' => __("This option disables your restaurant's ordering system in general and the restaurant is closed message is displayed. If this option is active, the restaurant's open or closed status will be determined based on the restaurant's working hours. Also, if you use the Pro version, there is a floating option at the bottom left of the page for faster access.", 'reyhoon'),
                    'type' => 'toggle',
                    'default' => true
                ),
                array(
                    'id' => 'rey_full_time',
                    'title' => __('open full time', 'reyhoon'),
                    'subtitle' => __("If this option is active, your collection will be active and open all the time.", 'reyhoon'),
                    'type' => 'toggle',
                    'default' => false
                ),
                array(
                    'id' => 'open_hours',
                    'title' => __('Open Hours', 'reyhoon'),
                    'subtitle' => __('The days and hours your store is open. Leave "Max Orders" empty for no limit.', 'reyhoon'),
                    'type' => 'custom',
                    'default' => Reyhoon_Settings::get_setting_default(self::$open_hours_key),
                    'output' => self::get_open_hours_fields(),
                    'show_if' => array(
                        array(
                            'field' => 'store_general_rey_full_time',
                            'value' => ['false'],
                        ),
                    )// dependency rule
                ),
                array(
                    'id' => 'timezone',
                    'title' => __('Timezone', 'reyhoon'),
                    'subtitle' => __("Your store's current timezone. This should be set to the location of your store.", 'reyhoon'),
                    'type' => 'custom',
                    'default' => '',
                    'output' => self::get_timezone_fields(),
                ),
                array(
                    'id' => 'services',
                    'title' => __('Services', 'reyhoon'),
                    'subtitle' => sprintf(__('Which services do you offer? Please ensure there are <a href="%s" target="_blank">shipping methods</a> available for these services.', 'reyhoon'), esc_url(admin_url('admin.php?page=wc-settings&tab=shipping'))),
                    'type' => 'checkboxes',
                    'default' => array(),
                    'choices' => array(
                        'delivery' => __('Delivery', 'reyhoon'),
                        'pickup' => __('Pickup', 'reyhoon'),
                    ),
                ),
                array(
                    'id' => 'service_hours',
                    'title' => __('Service Hours', 'reyhoon'),
                    'subtitle' => __('The days and hours where you offer delivery/pickup services.', 'reyhoon'),
                    'type' => 'custom',
                    'default' => Reyhoon_Settings::get_setting_default('store_general_service_hours'),
                    'output' => self::get_service_hours_fields(),
                ),
                'asap' => array(
                    'id' => 'asap',
                    'title' => __('As Soon As Possible', 'reyhoon'),
                    'subtitle' => __('Allow customers to request delivery "ASAP".', 'reyhoon'),
                    'type' => 'checkboxes',
                    'default' => array(),
                    'choices' => array(
                        'day' => __('Allow "ASAP" as an option when choosing delivery date', 'reyhoon'),
                    ),
                ),
                array(
                    'id' => 'ready_time',
                    'title' => __('estimated_order_preparation_time', 'reyhoon'),
                    'subtitle' => __('How long does it take from the time an order is placed until it is delivered to the customer?', 'reyhoon'),
                    'type' => 'number',
                    'default' => Reyhoon_Settings::get_setting_default('store_general_ready_time'),
                ),
                array(
                    'id' => 'lead_time',
                    'title' => __('Lead Time', 'reyhoon'),
                    'subtitle' => __('How many days do you need to prepare the order? Leave blank or "0" for same day.', 'reyhoon'),
                    'type' => 'number',
                    'default' => Reyhoon_Settings::get_setting_default('store_general_lead_time'),
                ),
                array(
                    'id' => 'preorder',
                    'title' => __('Preorder Days', 'reyhoon'),
                    'subtitle' => __('For how many days after the lead time will you accept orders?', 'reyhoon'),
                    'type' => 'number',
                    'default' => Reyhoon_Settings::get_setting_default('store_general_preorder'),
                ),
                array(
                    'id' => 'calculation_method',
                    'title' => __('Delivery Days Calculation Method', 'reyhoon'),
                    'subtitle' => __('Calculate Lead time and Preorder Days based on all days of the week, open days, service days or weekdays.', 'reyhoon'),
                    'type' => 'select',
                    'choices' => array(
                        'service' => __('Service Days', 'reyhoon'),
                        'open' => __('Open Days', 'reyhoon'),
                        'weekdays' => __('Weekdays Only', 'reyhoon'),
                        'all' => __('All Days', 'reyhoon'),
                    ),
                    'default' => Reyhoon_Settings::get_setting_default('store_general_calculation_method'),
                ),
                array(
                    'id' => 'holidays',
                    'title' => __('Holidays', 'reyhoon'),
                    'subtitle' => __('Days when your store is closed.', 'reyhoon'),
                    'type' => 'custom',
                    'default' => Reyhoon_Settings::get_setting_default(self::$holidays_key),
                    'output' => self::get_holidays_fields(),
                ),
                array(
                    'id' => 'packaging_cost',
                    'title' => __('packaging_cost', 'reyhoon'),
                    'subtitle' => __("enter packaging cost (You can set a special packaging fee for each product in the products menu)", 'reyhoon'),
                    'type' => 'custom',
                    'output' => self::packing_cost(),
                ),
                array(
                    'id' => 'product_layout',
                    'title' => __("Variable product display pattern", 'reyhoon'),
                    'subtitle' => __("If the 'Default Variables' option is selected, the Reyhoon add-on modules will be disabled.", 'reyhoon'),
                    'type' => 'radio',
                    'default' => 'addon',
                    'choices' => array(
                        'addon' => __("Using Reyhoon Product Add-ons", 'reyhoon'),
                        'variable' => __("Utilizing Default Variables in WooCommerce", 'reyhoon')
                    ),
                ),
                array(
                    'id' => 'checkout_type',
                    'title' => __("Checkout", 'reyhoon'),
                    'subtitle' => __("Please select the checkout module of your choice. If you intend to use third-party shipping plugins to avoid potential conflicts, choose the 'WooCommerce Default Checkout' option.", 'reyhoon'),
                    'type' => 'radio',
                    'default' => 'reyhoon',
                    'choices' => array(
                        'reyhoon' => __("Reyhoon Custom Checkout", 'reyhoon'),
                        'woocommerce' => __("WooCommerce Default Checkout", 'reyhoon')
                    ),
                ),
                array(
                    'id' => 'wallet_endpoint',
                    'title' => __("Wallet", 'reyhoon'),
                    'subtitle' => __("Please insert the Wallet endpoint.", 'reyhoon'),
                    'type' => 'text',
                    'default' => '',
                    'placeholder' => 'woo-wallet',

                ),
                array(
                    'id' => 'map_api',
                    'title' => __("Map API", 'reyhoon'),
                    'subtitle' => __("Please obtain the API from map.ir website.", 'reyhoon'),
                    'type' => 'textArea',
                    'placeholder' => __("Please obtain the API from map.ir website.", 'reyhoon')
                ),

                array(
                    'id' => 'map_geo',
                    'title' => __("Geographic Fence", 'reyhoon'),
                    'subtitle' => __("Obtain the geographic fence file from geojson.io.", 'reyhoon'),
                    'type' => 'custom',
                    'output' => self::get_uplaod_map_setting(),
                ),

                array(
                    'id' => 'map_location',
                    'title' => __("Your restaurant's location", 'reyhoon'),
                    'subtitle' => __("Specify the restaurant's location on the map.", 'reyhoon'),
                    'type' => 'custom',
                    'output' => self::get_shop_location(),
                ),
            ),
        );

        return $settings;
    }

    /**
     * Validate settings.
     *
     * @param array $settings
     *
     * @return array
     */
    public static function validate_settings($settings = array())
    {
        if (empty($settings[self::$service_hours_key . '_pickup_same'])) {
            $settings[self::$service_hours_key . '_pickup_same'] = 0;
        }

        return $settings;
    }

    /**
     * Get open hours fields.
     *
     * @return void|string
     */
    public static function get_open_hours_fields()
    {
        if (!is_admin()) {
            return;
        }

        $days = Reyhoon_Timings::get_days_of_the_week();
        $open_hours_settings = Reyhoon_Settings::get_setting(self::$open_hours_key);

        ob_start();
        ?>
        <table class="reyhoon-table reyhoon-table--open-hours" cellpadding="0" cellspacing="0">
            <thead>
            <tr>
                <th class="reyhoon-table__column reyhoon-table__column--checkbox">&nbsp;</th>
                <th class="reyhoon-table__column reyhoon-table__column--label">&nbsp;</th>
                <th class="reyhoon-table__column reyhoon-table__column--time"><?php esc_html_e('Open Hours (From)', 'reyhoon'); ?></th>
                <th class="reyhoon-table__column reyhoon-table__column--time"><?php esc_html_e('Open Hours (To)', 'reyhoon'); ?></th>
                <th class="reyhoon-table__column reyhoon-table__column--last"><?php esc_html_e('Max Orders (Day)', 'reyhoon'); ?></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($days as $day_number => $day_name) {
                $day_settings = isset($open_hours_settings[$day_number]) ? $open_hours_settings[$day_number] : array();
                $enabled = !empty($day_settings['enabled']);
                $from = !empty($day_settings['from']) ? $day_settings['from'] : array();
                $to = !empty($day_settings['to']) ? $day_settings['to'] : array();

                ?>
                <tr class="reyhoon-table__row <?php if (!$enabled) {
                    echo 'reyhoon-table__row--hidden';
                } ?>">
                    <td class="reyhoon-table__column reyhoon-table__column--checkbox reyhoon-table__column--always-visible">
                        <input class="reyhoon-enable-day" type="checkbox"
                               name="reyhoon_settings[<?php echo esc_attr(self::$open_hours_key); ?>][<?php echo esc_attr($day_number); ?>][enabled]"
                               id="store_general_open_hours_<?php echo esc_attr($day_number); ?>_enabled"
                               value="1" <?php checked($enabled); ?>
                               data-reyhoon-day="<?php echo esc_attr($day_number); ?>">
                    </td>
                    <td class="reyhoon-table__column reyhoon-table__column--label reyhoon-table__column--always-visible">
                        <label for="<?php echo esc_attr(self::$open_hours_key); ?>_<?php echo esc_attr($day_number); ?>_enabled"><?php echo esc_html($day_name); ?></label>
                    </td>
                    <td class="reyhoon-table__column reyhoon-table__column--time">
                        <strong class="reyhoon-table__rwd-labels"><?php esc_html_e('Open Hours (From)', 'reyhoon'); ?></strong>
                        <?php echo Reyhoon_Helpers::kses(self::get_time_field('reyhoon_settings[' . self::$open_hours_key . '][' . $day_number . '][from]', $from), 'form'); ?>
                    </td>
                    <td class="reyhoon-table__column reyhoon-table__column--time">
                        <strong class="reyhoon-table__rwd-labels"><?php esc_html_e('Open Hours (To)', 'reyhoon'); ?></strong>
                        <?php echo Reyhoon_Helpers::kses(self::get_time_field('reyhoon_settings[' . self::$open_hours_key . '][' . $day_number . '][to]', $to), 'form'); ?>
                    </td>
                    <td class="reyhoon-table__column reyhoon-table__column--last">
                        <?php echo Reyhoon_Helpers::kses(self::get_max_orders_field('reyhoon_settings[' . self::$open_hours_key . '][' . $day_number . '][max_orders]', $day_settings), 'form'); ?>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        <?php

        return ob_get_clean();
    }

    /**
     * Get service hours fields.
     *
     * @return void|string
     */
    public static function get_service_hours_fields()
    {
        if (!is_admin()) {
            return;
        }

        ob_start();

        $services = Reyhoon_Timings::get_services();
        $active_service = empty($services) ? false : reset($services);
        $pickup_same = Reyhoon_Settings::get_setting(self::$service_hours_key . '_pickup_same');
        ?>
        <p class="reyhoon-notice reyhoon-notice--select-service <?php if (!empty($services)) {
            echo 'reyhoon-ui-hide';
        } ?>"><?php _e('Please select services available for this store.', 'reyhoon'); ?></p>

        <div class="reyhoon-toolbar">
            <button class="reyhoon-admin-button reyhoon-admin-button--delivery <?php if ('delivery' === $active_service) {
                echo 'reyhoon-trigger-element--active';
            } ?> <?php if (!in_array('delivery', $services)) {
                echo 'reyhoon-ui-hide';
            } ?>" data-reyhoon-trigger="toggle-wrapper" data-reyhoon-wrapper="delivery"
                    data-reyhoon-wrapper-group="service"><?php _e('Delivery', 'reyhoon'); ?></button>
            <button class="reyhoon-admin-button reyhoon-admin-button--pickup <?php if ('pickup' === $active_service) {
                echo 'reyhoon-trigger-element--active';
            } ?> <?php if (!in_array('pickup', $services)) {
                echo 'reyhoon-ui-hide';
            } ?>" data-reyhoon-trigger="toggle-wrapper" data-reyhoon-wrapper="pickup"
                    data-reyhoon-wrapper-group="service"><?php _e('Pickup', 'reyhoon'); ?></button>
            <div class="reyhoon-toolbar__actions">
				<span class="reyhoon-toggle-wrapper reyhoon-toggle-wrapper--delivery <?php if ('delivery' === $active_service) {
                    echo 'reyhoon-toggle-wrapper--active';
                } ?>" data-reyhoon-wrapper-group="service">
					<button class="reyhoon-admin-button reyhoon-admin-button--primary" data-reyhoon-trigger="new-row"
                            data-reyhoon-target=".reyhoon-table--service-hours-delivery"><span
                                class="dashicons dashicons-plus"></span> <?php _e('Add service hours', 'reyhoon'); ?></button>
				</span>
                <span class="reyhoon-element--pickup <?php echo $pickup_same ? 'reyhoon-element--disabled' : ''; ?> reyhoon-toggle-wrapper <?php if ('pickup' === $active_service) {
                    echo 'reyhoon-toggle-wrapper--active';
                } ?> reyhoon-toggle-wrapper--pickup" data-reyhoon-wrapper-group="service">
					<button class="reyhoon-admin-button reyhoon-admin-button--primary" data-reyhoon-trigger="new-row"
                            data-reyhoon-target=".reyhoon-table--service-hours-pickup"><span
                                class="dashicons dashicons-plus"></span> <?php _e('Add service hours', 'reyhoon'); ?></button>
				</span>
            </div>
        </div>

        <div class="reyhoon-toggle-wrapper reyhoon-toggle-wrapper--delivery <?php if ('delivery' === $active_service) {
            echo 'reyhoon-toggle-wrapper--active';
        } ?>" data-reyhoon-wrapper-group="service">
            <?php self::output_service_hours_table('delivery'); ?>
        </div>

        <div class="reyhoon-toggle-wrapper reyhoon-toggle-wrapper--pickup <?php if ('pickup' === $active_service) {
            echo 'reyhoon-toggle-wrapper--active';
        } ?>" data-reyhoon-wrapper-group="service">
            <label for="reyhoon_settings_<?php echo esc_attr(self::$service_hours_key); ?>_pickup_same"
                   id="reyhoon_settings_<?php echo esc_attr(self::$service_hours_key); ?>_pickup_same_label">
                <input type="checkbox"
                       id="reyhoon_settings_<?php echo esc_attr(self::$service_hours_key); ?>_pickup_same"
                       name="reyhoon_settings[<?php echo esc_attr(self::$service_hours_key); ?>_pickup_same]"
                       value="1" <?php checked($pickup_same); ?> data-reyhoon-trigger="toggle-element"
                       data-reyhoon-target=".reyhoon-element--pickup"
                       data-reyhoon-toggle-class="reyhoon-element--disabled">
                <?php _e('Same as delivery service hours', 'reyhoon'); ?>
            </label>
            <?php self::output_service_hours_table('pickup', $pickup_same); ?>
        </div>
        <?php

        return ob_get_clean();
    }

    /**
     * Output service hours table.
     *
     * @param string $type Type is 'delivery' or 'pickup'.
     * @param bool $disabled Disable the table?
     */
    public static function output_service_hours_table($type, $disabled = false)
    {
        if (empty($type)) {
            return;
        }

        $settings = self::get_service_hours_settings($type);

        if (empty($settings)) {
            return;
        }

        $open_hours_settings = Reyhoon_Settings::get_setting(self::$open_hours_key);
        $days_of_the_week = Reyhoon_Timings::get_days_of_the_week('short');
        ?>
        <table class="reyhoon-table reyhoon-table--service-hours-<?php echo esc_attr($type); ?> reyhoon-element--<?php echo esc_attr($type); ?> <?php echo $disabled ? 'reyhoon-element--disabled' : ''; ?>"
               cellpadding="0" cellspacing="0">
            <tbody class="reyhoon-table__body">
            <?php foreach ($settings as $index => $settings_row) { ?>
                <tr class="reyhoon-table__row reyhoon-table__row--repeatable"
                    data-reyhoon-index="<?php echo esc_attr($index); ?>">
                    <td class="reyhoon-table__cell reyhoon-table__cell--no-padding">
                        <table class="reyhoon-table reyhoon-table--child reyhoon-table--compact" cellpadding="0"
                               cellspacing="0">
                            <tbody>
                            <tr>
                                <th class="reyhoon-table__column reyhoon-table__column--medium"><?php _e('Days', 'reyhoon'); ?></th>
                                <td>
                                    <select class="reyhoon-select reyhoon-select--multi-select reyhoon-select--days"
                                            name="reyhoon_settings[<?php echo esc_attr(self::$service_hours_key); ?>_<?php echo esc_attr($type); ?>][<?php echo esc_attr($index); ?>][days][]"
                                            multiple
                                            data-reyhoon-select-none-option="<?php esc_attr_e('Select "Open Hours" first', 'reyhoon'); ?>">
                                        <?php foreach ($days_of_the_week as $day_number => $day_label) {
                                            $is_day_enabled = !empty($open_hours_settings[$day_number]['enabled']); ?>
                                            <option value="<?php echo esc_attr($day_number); ?>" <?php selected(in_array($day_number, $settings_row['days']) && $is_day_enabled); ?> <?php disabled(!$is_day_enabled); ?>><?php echo esc_attr($day_label); ?></option>
                                        <?php } ?>
                                    </select>
                                </td>
                            </tr>
                            <tr <?php if ('all-day' === $settings_row['period']) {
                                echo 'class="reyhoon-table__row--last"';
                            } ?>>
                                <th class="reyhoon-table__column reyhoon-table__column--medium"><?php esc_html_e('Period', 'reyhoon'); ?></th>
                                <td>
                                    <select class="reyhoon-select"
                                            name="reyhoon_settings[<?php echo esc_attr(self::$service_hours_key); ?>_<?php echo esc_attr($type); ?>][<?php echo esc_attr($index); ?>][period]"
                                            data-reyhoon-trigger="toggle-element-select"
                                            data-reyhoon-parent=".reyhoon-table__row"
                                            data-reyhoon-target="<?php echo esc_attr(json_encode(
                                                array(
                                                    'all-day' => array(
                                                        'hide' => '[data-reyhoon-period="time-slots"]',
                                                    ),
                                                    'time-slots' => array(
                                                        'show' => '[data-reyhoon-period="time-slots"]',
                                                    ),
                                                )
                                            )); ?>">
                                        <option value="all-day" <?php selected($settings_row['period'], 'all-day'); ?>><?php esc_html_e('All Day', 'reyhoon'); ?></option>
                                        <option value="time-slots" <?php selected($settings_row['period'], 'time-slots'); ?>><?php esc_html_e('Time Slots', 'reyhoon'); ?></option>
                                    </select>
                                </td>
                            </tr>
                            <?php
                            echo Reyhoon_Helpers::kses(self::get_time_slot_fields('reyhoon_settings[' . self::$service_hours_key . '_' . $type . '][' . $index . ']', $settings_row), 'form'); ?>
                            </tbody>
                        </table>
                    </td>
                    <td class="reyhoon-table__column reyhoon-table__column--remove">
                        <a href="javascript: void(0);" class="reyhoon-table__remove-row"
                           data-reyhoon-trigger="remove-row"><span class="dashicons dashicons-trash"></span></a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        <?php
    }

    /**
     * Output holiday fields.
     *
     * @return void|string
     */
    public static function get_holidays_fields()
    {
        if (!is_admin()) {
            return;
        }

        $settings = Reyhoon_Settings::get_setting(self::$holidays_key);
        $defaults = Reyhoon_Settings::get_setting_default(self::$holidays_key);

        $defaults = $defaults[0];

        ob_start();
        ?>
        <div class="reyhoon-toolbar">
            <div class="reyhoon-toolbar__actions">
                <button class="reyhoon-admin-button reyhoon-admin-button--primary" data-reyhoon-trigger="new-row"
                        data-reyhoon-target=".reyhoon-table--holidays">
                    <span class="dashicons dashicons-plus"></span> <?php esc_html_e('Add holiday', 'reyhoon'); ?>
                </button>
            </div>
        </div>
        <table class="reyhoon-table reyhoon-table--holidays" cellpadding="0" cellspacing="0">
            <tbody class="reyhoon-table__body">
            <?php foreach ($settings as $index => $settings_row) {
                $from = isset($settings_row['from']) ? $settings_row['from'] : $defaults['from'];
                $to = isset($settings_row['to']) ? $settings_row['to'] : $defaults['to'];
                $services = isset($settings_row['services']) ? $settings_row['services'] : $defaults['services'];
                $repeat = isset($settings_row['repeat']) ? $settings_row['repeat'] : $defaults['repeat'];
                ?>
                <tr class="reyhoon-table__row reyhoon-table__row--repeatable"
                    data-reyhoon-index="<?php echo esc_attr($index); ?>">
                    <td class="reyhoon-table__cell reyhoon-table__cell--no-padding">
                        <table class="reyhoon-table reyhoon-table--child reyhoon-table--compact" cellpadding="0"
                               cellspacing="0">
                            <tbody>
                            <tr>
                                <th class="reyhoon-table__column reyhoon-table__column--medium"><?php esc_html_e('From', 'reyhoon'); ?></th>
                                <td>
                                    <input type="text" class="datepicker"
                                           name="reyhoon_settings[<?php echo esc_attr(self::$holidays_key); ?>][<?php echo esc_attr($index); ?>][from]"
                                           value="<?php esc_attr_e($from); ?>"
                                           data-datepicker="{&quot;dateFormat&quot;:&quot;yy-mm-dd&quot;}"
                                           readonly="readonly">
                                </td>
                            </tr>
                            <tr>
                                <th class="reyhoon-table__column reyhoon-table__column--medium"><?php esc_html_e('To', 'reyhoon'); ?></th>
                                <td>
                                    <input type="text" class="datepicker"
                                           name="reyhoon_settings[<?php echo esc_attr(self::$holidays_key); ?>][<?php echo esc_attr($index); ?>][to]"
                                           value="<?php esc_attr_e($to); ?>"
                                           data-datepicker="{&quot;dateFormat&quot;:&quot;yy-mm-dd&quot;}"
                                           readonly="readonly">
                                </td>
                            </tr>
                            <tr>
                                <th class="reyhoon-table__column reyhoon-table__column--medium"><?php esc_html_e('Services', 'reyhoon'); ?></th>
                                <td>
                                    <ul class="wpsf-list wpsf-list--checkboxes">
                                        <li>
                                            <label>
                                                <input type="checkbox"
                                                       name="reyhoon_settings[<?php echo esc_attr(self::$holidays_key); ?>][<?php echo esc_attr($index); ?>][services][]"
                                                       value="delivery" <?php checked(in_array('delivery', $services, true)); ?>>
                                                <?php esc_html_e('Delivery', 'reyhoon'); ?>
                                            </label>
                                        </li>
                                        <li>
                                            <label>
                                                <input type="checkbox"
                                                       name="reyhoon_settings[<?php echo esc_attr(self::$holidays_key); ?>][<?php echo esc_attr($index); ?>][services][]"
                                                       value="pickup" <?php checked(in_array('pickup', $services, true)); ?>>
                                                <?php esc_html_e('Pickup', 'reyhoon'); ?>
                                            </label>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <tr>
                                <th class="reyhoon-table__column reyhoon-table__column--medium"><?php esc_html_e('Repeat Yearly?', 'reyhoon'); ?></th>
                                <td>
                                    <input type="checkbox"
                                           name="reyhoon_settings[<?php echo esc_attr(self::$holidays_key); ?>][<?php echo esc_attr($index); ?>][repeat]"
                                           value="1" <?php checked(1, $repeat); ?>>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                    <td class="reyhoon-table__column reyhoon-table__column--remove">
                        <a href="javascript: void(0);" class="reyhoon-table__remove-row"
                           data-reyhoon-trigger="remove-row"><span class="dashicons dashicons-trash"></span></a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
        <?php
        return ob_get_clean();
    }

    /**
     * Get time field.
     *
     * @param string $name
     * @param array $values
     *
     * @return false|string
     */
    public static function get_time_field($name, $values = array())
    {
        $defaults = array(
            'hour' => '',
            'minute' => '',
            'period' => '',
        );

        $values = wp_parse_args($values, $defaults);

        $hours = array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
        $minutes = array('00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55');

        ob_start();
        ?>
        <span class="reyhoon-time">
			<select class="reyhoon-time__select reyhoon-time__select--hour" name="<?php echo esc_attr($name); ?>[hour]">
				<?php foreach ($hours as $hour) { ?>
                    <option value="<?php echo esc_attr($hour); ?>" <?php selected($values['hour'], $hour); ?>><?php echo esc_html($hour); ?></option>
                <?php } ?>
			</select>
			<select class="reyhoon-time__select reyhoon-time__select--minute"
                    name="<?php echo esc_attr($name); ?>[minute]">
				<?php foreach ($minutes as $minute) { ?>
                    <option value="<?php echo esc_attr($minute); ?>" <?php selected($values['minute'], $minute); ?>><?php echo esc_html($minute); ?></option>
                <?php } ?>
			</select>
			<select class="reyhoon-time__select reyhoon-time__select--period"
                    name="<?php echo esc_attr($name); ?>[period]">
				<option value="AM" <?php selected($values['period'], 'AM'); ?>>AM</option>
				<option value="PM" <?php selected($values['period'], 'PM'); ?>>PM</option>
			</select>
		</span>
        <?php

        return ob_get_clean();
    }

    /**
     * Get max orders field.
     *
     * @param string $name
     * @param array $settings
     *
     * @return mixed|void
     */
    public static function get_max_orders_field($name, $settings = array())
    {
        ob_start();
        ?>
        <strong class="reyhoon-table__rwd-labels"><?php esc_html_e('Max Orders (Day)', 'reyhoon'); ?></strong>
        <?php echo Reyhoon_Helpers::get_pro_button('max-orders'); ?>
        <?php

        return apply_filters('reyhoon_get_max_orders_field', ob_get_clean(), $name, $settings);
    }

    /**
     * Get time slot fields.
     *
     * @param string $name
     * @param array $settings
     *
     * @return mixed|void
     */
    public static function get_time_slot_fields($name, $settings = array())
    {
        ob_start();
        ?>
        <tr data-reyhoon-period="time-slots"
            class="reyhoon-table__no-td-border" <?php if ('all-day' === $settings['period']) {
            echo 'style="display: none;"';
        } ?>>
            <th class="reyhoon-table__column reyhoon-table__column--medium"><?php esc_html_e('Hours', 'reyhoon'); ?></th>
            <td class="reyhoon-table__column reyhoon-table__column--time" rowspan="4" style="text-align: center;">
                <?php echo Reyhoon_Helpers::get_pro_button('time-slots'); ?>
            </td>
        </tr>
        <tr data-reyhoon-period="time-slots" <?php if ('all-day' === $settings['period']) {
            echo 'style="display: none;"';
        } ?>>
            <th class="reyhoon-table__column reyhoon-table__column--medium"><?php esc_html_e('Frequency (Mins)', 'reyhoon'); ?></th>
        </tr>
        <tr data-reyhoon-period="time-slots" <?php if ('all-day' === $settings['period']) {
            echo 'style="display: none;"';
        } ?>>
            <th class="reyhoon-table__column reyhoon-table__column--medium"><?php esc_html_e('Cutoff (Mins)', 'reyhoon'); ?></th>
        </tr>
        <tr data-reyhoon-period="time-slots" <?php if ('all-day' === $settings['period']) {
            echo 'style="display: none;"';
        } ?>>
            <th class="reyhoon-table__column reyhoon-table__column--medium"><?php esc_html_e('Max Orders (Slot)', 'reyhoon'); ?></th>
        </tr>
        <?php

        return apply_filters('reyhoon_get_time_slot_fields', ob_get_clean(), $name, $settings);
    }

    /**
     * Get service hours settings.
     *
     * @param string $type
     *
     * @return mixed|void
     */
    public static function get_service_hours_settings($type = 'delivery')
    {
        $service_hours = array();
        $settings = Reyhoon_Settings::get_setting(self::$service_hours_key . '_' . $type);
        $defaults = Reyhoon_Settings::get_setting_default(self::$service_hours_key . '_' . $type);

        if (empty($settings) || empty($defaults)) {
            return apply_filters('reyhoon_get_service_hours_settings', $service_hours, $type);
        }

        $defaults = $defaults[0];

        foreach ($settings as $index => $settings_row) {
            $service_hours[$index] = wp_parse_args($settings_row, $defaults);
        }

        return apply_filters('reyhoon_get_service_hours_settings', $service_hours, $type);
    }

    /**
     * Timezone fields.
     */
    public static function get_timezone_fields()
    {
        $current_offset = get_option('gmt_offset');
        $tzstring = get_option('timezone_string');
        $timezone_format = _x('Y-m-d H:i:s', 'timezone date format');

        $check_zone_info = true;

// Remove old Etc mappings. Fallback to gmt_offset.
        if (false !== strpos($tzstring, 'Etc/GMT')) {
            $tzstring = '';
        }

        if (empty($tzstring)) { // Create a UTC+- zone if no timezone string exists.
            $check_zone_info = false;
            if (0 == $current_offset) {
                $tzstring = 'UTC+0';
            } elseif ($current_offset < 0) {
                $tzstring = 'UTC' . $current_offset;
            } else {
                $tzstring = 'UTC+' . $current_offset;
            }
        }

        ob_start();
        ?>
        <a href="<?php echo esc_url(admin_url('options-general.php#timezone_string')); ?>" target="_blank"
           class="reyhoon-admin-button"
           style="margin-bottom: 20px;"><?php esc_html_e('Update Timezone', 'reyhoon'); ?></a>

        <p id="timezone-description">
            <?php
            // Translators: %s: Timezone string.
            echo wp_kses(sprintf(__("Your store's current timezone is %s.", 'reyhoon'), '<code>' . $tzstring . '</code>'), array('code' => array()));
            ?>
        </p>

        <p class="timezone-info">
			<span id="utc-time">
				<?php
                echo wp_kses(sprintf(
                /* translators: %s: UTC time. */
                    __('Universal time is %s.'),
                    '<code>' . date_i18n($timezone_format, false, true) . '</code>'
                ), array('code' => array()));
                ?>
			</span>

            <?php if (get_option('timezone_string') || !empty($current_offset)) : ?>
                <span id="local-time">
					<?php
                    echo wp_kses(sprintf(
                    /* translators: %s: Local time. */
                        __('Local time is %s.'),
                        '<code>' . date_i18n($timezone_format) . '</code>'
                    ), array('code' => array()));
                    ?>
				</span>
            <?php endif; ?>
        </p>

        <?php if ($check_zone_info && $tzstring) : ?>
        <p class="timezone-info">
				<span>
					<?php
                    $now = new DateTime('now', new DateTimeZone($tzstring));
                    $dst = (bool)$now->format('I');

                    if ($dst) {
                        esc_html_e('This timezone is currently in daylight saving time.');
                    } else {
                        esc_html_e('This timezone is currently in standard time.');
                    }
                    ?>
					<br/>
					<?php
                    if (in_array($tzstring, timezone_identifiers_list(), true)) {
                        $transitions = timezone_transitions_get(timezone_open($tzstring), time());

                        // 0 index is the state at current time, 1 index is the next transition, if any.
                        if (!empty($transitions[1])) {
                            echo ' ';
                            $message = $transitions[1]['isdst'] ?
                                /* translators: %s: Date and time. */
                                __('Daylight saving time begins on: %s.') :
                                /* translators: %s: Date and time. */
                                __('Standard time begins on: %s.');
                            echo wp_kses(sprintf(
                                $message,
                                '<code>' . wp_date(__('F j, Y') . ' ' . __('g:i a'), $transitions[1]['ts']) . '</code>'
                            ), array('code' => array()));
                        } else {
                            esc_html_e('This timezone does not observe daylight saving time.');
                        }
                    }
                    ?>
				</span>
        </p>
    <?php endif; ?>
        <?php

        return ob_get_clean();
    }

    public static function packing_cost()
    {
        if (!is_admin()) {
            return;
        }
        ob_start(); ?>
        <strong class="reyhoon-table__rwd-labels">'هزینه بسته بندی'</strong>
        <?php echo Reyhoon_Helpers::get_pro_button();
        return apply_filters('reyhoon_packing_cost', ob_get_clean());
    }

    public static function get_uplaod_map_setting()
    {
        if (!is_admin()) {
            return;
        }
        ob_start();
        if (!empty(Reyhoon_Settings::get_setting('store_general_map_api')) && Reyhoon_Settings::get_setting('store_general_map_api') != '') {
            ?>
            <strong class="reyhoon-table__rwd-labels">'حصار جغرافیایی'</strong>
            <?php echo Reyhoon_Helpers::get_pro_button(); ?>
            <?php

            return apply_filters('reyhoon_get_uplaod_map_setting', ob_get_clean());
        } else {
            return '<p>api نقشه وارد نشده است</p>';
        }
    }

    public static function get_shop_location()
    {
        if (!is_admin()) {
            return;
        }
        if (!empty(Reyhoon_Settings::get_setting('store_general_map_api')) && Reyhoon_Settings::get_setting('store_general_map_api') != '') {
            wp_enqueue_script('rey-map');
            ob_start(); ?>
            <div class="map_container map-preloader" style="overflow: hidden;position: relative;z-index:0">
                <div id="app">
                    <div id="center-marker"></div>
                </div>
                <span class="verify-location">تایید موقعیت</span>
            </div>
            <style>
                .map-preloader::before {
                    width: 100%;
                    height: 100%;
                    content: "برای لود نقشه کلیک کنید";
                    position: absolute;
                    display: flex;
                    background: #333;
                    justify-content: center;
                    align-items: center;
                    font-size: 28px;
                    color: #fff;
                    z-index: 10;
                }
            </style>
            <?php
            return ob_get_clean();
        } else {
            return '<p>api نقشه وارد نشده است</p>';
        }
    }

}
