<?php
/**
 * Template: Open hours.
 *
 * @package Reyhoon/Templates
 */

defined( 'ABSPATH' ) || exit;

$open_hours = Reyhoon_Timings::get_open_hours();

if ( empty( $open_hours ) ) {
	return;
}
?>

<table class="reyhoon-open-hours">
	<tbody>
	<?php foreach ( $open_hours as $open_hour ) { ?>
		<tr class="reyhoon-open-hours__day">
			<th class="reyhoon-open-hours__day-name">
				<?php if ( $args['date'] ) { ?>
					<span class="reyhoon-open-hours__date"><?php echo esc_attr( $open_hour['date'] ); ?></span>
				<?php } ?>

				<?php echo esc_attr( $open_hour['day'] ); ?>
			</th>
			<td class="reyhoon-open-hours__hours">
				<span class="reyhoon-open-hours__hours-text reyhoon-open-hours__hours-text--<?php echo $open_hour['is_closed'] ? 'closed' : 'open'; ?>"><?php echo $open_hour['hours']; ?></span>

				<?php if ( $args['services'] && ! empty( $open_hour['services'] ) && ! $open_hour['is_closed'] ) { ?>
					<?php foreach ( $open_hour['services'] as $service => $active ) { ?>
						<span class="reyhoon-open-hours__service reyhoon-open-hours__service--<?php echo esc_attr( $service ); ?> reyhoon-open-hours__service--<?php echo $active ? 'open' : 'closed'; ?>"><?php echo wp_kses_post( Reyhoon_Services::get_service_label( $service ) ); ?></span>
					<?php } ?>
				<?php } ?>
			</td>
		</tr>
	<?php } ?>
	</tbody>
</table>
