<?php
/**
 * Module: Timings order.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Timings order class.
 */
class Reyhoon_Timings_Order {
	/**
	 * Init.
	 */
	public static function run() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_footer', array( __CLASS__, 'enqueue_daterange_script' ) );
		add_filter( 'woocommerce_get_order_item_totals', array( __CLASS__, 'add_to_order_details' ), 10, 3 );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( __CLASS__, 'add_to_admin_order' ), 10, 1 );
		add_filter( 'manage_edit-shop_order_columns', array( __CLASS__, 'add_admin_order_columns' ), 20 );
		add_filter( 'manage_edit-shop_order_sortable_columns', array( __CLASS__, 'add_admin_order_sortable_columns' ) );
		add_action( 'manage_shop_order_posts_custom_column', array( __CLASS__, 'add_admin_order_columns_content' ), 10, 2 );
		add_action( 'pre_get_posts', array( __CLASS__, 'filter_admin_orders' ), 100 );
		add_action( 'restrict_manage_posts', array( __CLASS__, 'due_date_filter' ), 60 );
		add_action( 'woocommerce_admin_order_preview_start', array( __CLASS__, 'modify_order_preview_template' ) );
		add_filter( 'woocommerce_admin_order_preview_get_order_details', array( __CLASS__, 'modify_order_preview_get_order_details' ), 10, 2 );
	}

	/**
	 * Enqueue assets.
	 */
	public static function enqueue_assets() {
		if ( ! Reyhoon_Orders::is_orders_page() ) {
			return;
		}

		wp_enqueue_script( 'momentjs', REYHOON_ASSETS_URL . 'vendor/moment/moment.min.js', array( 'jquery' ), REYHOON_VERSION, true );
		wp_enqueue_script( 'daterangepicker', REYHOON_ASSETS_URL . 'vendor/daterangepicker/daterangepicker.js', array( 'jquery', 'momentjs' ), REYHOON_VERSION, true );
		wp_enqueue_style( 'daterangepicker', REYHOON_ASSETS_URL . 'vendor/daterangepicker/daterangepicker.css', array(), REYHOON_VERSION );

		wp_localize_script(
			'daterangepicker',
			'reyhoon_timings_daterangepicker',
			array(
				'today'        => esc_html__( 'Today', 'reyhoon' ),
				'tomorrow'     => esc_html__( 'Tomorrow', 'reyhoon' ),
				'next_7_days'  => esc_html__( 'Next 7 Days', 'reyhoon' ),
				'next_30_days' => esc_html__( 'Next 30 Days', 'reyhoon' ),
				'custom_range' => esc_html__( 'Custom Range', 'reyhoon' ),
				'clear'        => esc_html__( 'Clear', 'reyhoon' ),
				'apply'        => esc_html__( 'Apply', 'reyhoon' ),
			)
		);
	}

	/**
	 * Add date range script.
	 */
	public static function enqueue_daterange_script() {
		if ( ! Reyhoon_Orders::is_orders_page() ) {
			return;
		}
		?>
		<script>
			var reyhoon_date_picker = {
				/**
				 * On ready.
				 */
				ready: function() {
					reyhoon_date_picker.init();
					reyhoon_date_picker.watch();
				},

				/**
				 * Init datepicker.
				 */
				init: function() {
					var ranges = {};
					ranges[reyhoon_timings_daterangepicker.today] = [ moment(), moment() ];
					ranges[reyhoon_timings_daterangepicker.tomorrow] = [ moment().add( 1, 'days' ), moment().add( 1, 'days' ) ];
					ranges[reyhoon_timings_daterangepicker.next_7_days] = [ moment(), moment().add( 6, 'days' ) ];
					ranges[reyhoon_timings_daterangepicker.next_30_days] = [ moment(), moment().add( 29, 'days' ) ];

					jQuery( 'input[name="reyhoon_due_date"]' ).daterangepicker( {
						opens: 'left',
						autoUpdateInput: false,
						alwaysShowCalendars: true,
						locale: {
							format: 'YYYY/MM/DD',
							cancelLabel: reyhoon_timings_daterangepicker.clear,
							applyLabel: reyhoon_timings_daterangepicker.apply,
							customRangeLabel: reyhoon_timings_daterangepicker.custom_range,
							daysOfWeek: [
								'<?php esc_html_e( 'Su', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'Mo', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'Tu', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'We', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'Th', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'Fr', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'Sa', 'reyhoon' ); ?>',
							],
							monthNames: [
								'<?php esc_html_e( 'January', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'February', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'March', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'April', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'May', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'June', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'July', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'August', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'September', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'October', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'November', 'reyhoon' ); ?>',
								'<?php esc_html_e( 'December', 'reyhoon' ); ?>'
							],
						},
						ranges: ranges,
					} );
				},

				/**
				 * Watch datepicker events.
				 */
				watch: function() {
					jQuery( document.body ).on( 'apply.daterangepicker', 'input[name="reyhoon_due_date"]', function( ev, picker ) {
						jQuery( this ).val( picker.startDate.format( 'YYYY/MM/DD' ) + ' - ' + picker.endDate.format( 'YYYY/MM/DD' ) );
					} );

					jQuery( document.body ).on( 'cancel.daterangepicker', 'input[name="reyhoon_due_date"]', function( ev, picker ) {
						jQuery( this ).val( '' );
					} );
				}
			};

			jQuery( document ).ready( reyhoon_date_picker.ready );
			jQuery( document ).on( 'reyhoon-live-view-updated', reyhoon_date_picker.init );
		</script>
		<?php
	}

	/**
	 * Add date and time to order details.
	 *
	 * @param array    $total_rows
	 * @param WC_Order $order
	 * @param bool     $tax_display
	 *
	 * @return array
	 */
	public static function add_to_order_details( $total_rows, $order, $tax_display ) {
		$data        = self::get_order_date_time( $order );
		$order_total = $total_rows['order_total'];

		unset( $total_rows['order_total'] );

		foreach ( $data as $key => $value ) {
			if ( 'order_timestamp' === $key || empty( $value['value'] ) ) {
				continue;
			}

			$total_rows[ 'reyhoon_' . $key ] = array(
				'label' => wptexturize( $value['label'] . ':' ),
				'value' => wptexturize( $value['value'] ),
			);
		}

		$total_rows['order_total'] = $order_total;

		return $total_rows;
	}

	/**
	 * @param WC_Order $order
	 */
	public static function add_to_admin_order( $order ) {
		$data = self::get_order_date_time( $order );

		foreach ( $data as $key => $value ) {
			if ( 'order_timestamp' === $key || empty( $value['value'] ) ) {
				continue;
			}

			echo '<p><strong>' . $value['label'] . ':</strong> <br>' . $value['value'] . '</p>';
		}
	}

	/**
	 * Get order date/time.
	 *
	 * @param WC_Order $order
	 *
	 * @return array
	 */
	public static function get_order_date_time( $order ) {
		return apply_filters( 'reyhoon_get_order_date_time', array(
			'order_date'      => array(
				'value' => $order->get_meta( 'reyhoon_order_date' ),
				'label' => __( 'Date', 'reyhoon' ),
			),
			'order_time'      => array(
				'value' => $order->get_meta( 'reyhoon_order_time' ),
				'label' => __( 'Time', 'reyhoon' ),
			),
			'order_timestamp' => array(
				'value' => $order->get_meta( '_reyhoon_order_timestamp' ),
				'label' => __( 'Timestamp', 'reyhoon' ),
			),
		), $order );
	}

	/**
	 * Add columns to admin orders screen.
	 *
	 * @param array $columns
	 *
	 * @return array
	 */
	public static function add_admin_order_columns( $columns ) {
		$columns['reyhoon_order_data'] = __( 'Due Date/Time', 'reyhoon' );

		return $columns;
	}

	/**
	 * Add columns content to admin orders screen.
	 *
	 * @param $column_name
	 * @param $post_id
	 */
	public static function add_admin_order_columns_content( $column_name, $post_id ) {
		if ( 'reyhoon_order_data' === $column_name ) {
			$order = wc_get_order( $post_id );
			$data  = self::get_order_date_time( $order );

			if ( ! empty( $data['order_date']['value'] ) ) {
				printf( '<p><strong>%s</strong>: %s</p>', __( 'Date', 'reyhoon' ), $data['order_date']['value'] );
			}

			if ( ! empty( $data['order_time']['value'] ) ) {
				printf( '<p><strong>%s</strong>: %s</p>', __( 'Time', 'reyhoon' ), $data['order_time']['value'] );
			}
		}
	}

	/**
	 * Register columns as sortable.
	 *
	 * @param array $columns
	 *
	 * @return array
	 */
	public static function add_admin_order_sortable_columns( $columns ) {
		$columns['reyhoon_order_data'] = '_reyhoon_order_timestamp';

		return $columns;
	}

	/**
	 * Sort admin orders.
	 *
	 * @param WP_Query $query
	 */
	public static function filter_admin_orders( $query ) {
		if ( ! Reyhoon_Orders::is_orders_page() || 'shop_order' !== $query->get( 'post_type' ) ) {
			return;
		}

		$args = array(
			'orderby'  => filter_input( INPUT_GET, 'orderby', FILTER_SANITIZE_FULL_SPECIAL_CHARS ),
			'due_date' => array_filter( self::get_filtered_due_date() ),
		);

		self::update_query( $query, $args );
	}

	/**
	 * Update orders query.
	 *
	 * @param WP_Query $query
	 * @param array    $args
	 */
	public static function update_query( $query, $args = array() ) {
		$defaults = array(
			'orderby'  => '',
			'due_date' => '',
		);

		$args       = wp_parse_args( $args, $defaults );
		$meta_query = (array) $query->get( 'meta_query' );

		if ( ! empty( $args['orderby'] ) && '_reyhoon_order_timestamp' === $args['orderby'] ) {
			$meta_query[] = array(
				'key'     => $args['orderby'],
				'compare' => 'EXISTS',
			);
		}

		if ( ! empty( $args['due_date'] ) && ! empty( $args['due_date']['start_timestamp'] ) && ! empty( $args['due_date']['end_timestamp'] ) ) {
			$meta_query[] = array(
				'key'     => '_reyhoon_order_timestamp',
				'value'   => array( $args['due_date']['start_timestamp'], $args['due_date']['end_timestamp'] ),
				'type'    => 'numeric',
				'compare' => 'BETWEEN',
			);
		}

		$query->set( 'meta_query', $meta_query );
	}

	/**
	 * Due date filter.
	 */
	public static function due_date_filter() {
		if ( ! Reyhoon_Orders::is_orders_page() ) {
			return;
		}

		$due_date = self::get_filtered_due_date();
		?>
		<input type="text" name="reyhoon_due_date" value="<?php echo esc_attr( $due_date['formatted'] ); ?>" placeholder="<?php esc_attr_e( 'Filter by due date', 'reyhoon' ); ?>" style="min-width: 195px;" />
		<?php
	}

	/**
	 * Get filtered due date.
	 *
	 * @return array
	 */
	public static function get_filtered_due_date() {
		$return = array(
			'start'           => '',
			'start_timestamp' => '',
			'end'             => '',
			'end_timestamp'   => '',
			'formatted'       => '',
		);

		$due_date = filter_input( INPUT_GET, 'reyhoon_due_date', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		if ( ! $due_date ) {
			return $return;
		}

		$due_date_exploded = explode( ' - ', $due_date );

		$return['start']     = isset( $due_date_exploded[0] ) ? $due_date_exploded[0] : false;
		$return['end']       = isset( $due_date_exploded[1] ) ? $due_date_exploded[1] : false;
		$return['formatted'] = $due_date;

		if ( $return['start'] ) {
			$start = DateTime::createFromFormat( 'Y/m/d H:i:s', $return['start'] . ' 00:00:00', wp_timezone() );

			$return['start_timestamp'] = $start->getTimestamp();
		}

		if ( $return['end'] ) {
			$end = DateTime::createFromFormat( 'Y/m/d H:i:s', $return['end'] . ' 00:00:00', wp_timezone() );

			$return['end_timestamp'] = $end->getTimestamp();
		}

		if ( isset( $start ) && ( ! $return['end'] || $return['end'] === $return['start'] ) ) {
			$start->add( new DateInterval( 'P1D' ) );

			$return['end_timestamp'] = $start->getTimestamp();
		}

		return $return;
	}

	/**
	 * Modify preview order template.
	 */
	public static function modify_order_preview_template() {
		?>
		<# if ( data.reyhoon.order_date.value ) { #>
		<div class="wc-order-preview-addresses" style="padding: 0;">
			<div class="wc-order-preview-address">
				<strong>{{ data.reyhoon.order_date.label }}</strong>
				{{ data.reyhoon.order_date.value }}
			</div>
			<# if ( data.reyhoon.order_time.value ) { #>
			<div class="wc-order-preview-address">
				<strong>{{ data.reyhoon.order_time.label }}</strong>
				{{ data.reyhoon.order_time.value }}
			</div>
			<# } #>
		</div>
		<# } #>
		<?php
	}

	/**
	 * Modify preview order details.
	 *
	 * @param array    $data
	 * @param WC_Order $order
	 *
	 * @return array
	 */
	public static function modify_order_preview_get_order_details( $data, $order ) {
		$data['reyhoon'] = self::get_order_date_time( $order );

		return $data;
	}
}