<?php
/**
 * Template: Service Selector.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/services/service-selector.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 */

defined( 'ABSPATH' ) || exit;

$selected_service  = Reyhoon_Services::get_selected_service();
$shipping_city     = ! empty( WC()->customer ) ? WC()->customer->get_shipping_city() : '';
$shipping_postcode = ! empty( WC()->customer ) ? WC()->customer->get_shipping_postcode() : '';
?>

<div class="reyhoon-services-selector <?php if ( $selected_service ) {
	echo 'reyhoon-services-selector--selected';
} ?>">
	<div class="reyhoon-services-selector__selected">
		<?php if ( $selected_service ) { ?>
			<p>
				<?php printf( __( 'You have selected %s for your order.' ), '<strong>' . $selected_service . '</strong>' ); ?>
				<button class="reyhoon-services-selector__selected-change" data-reyhoon-trigger="show-lookup-services"><?php _e( 'Change?', 'reyhoon' ); ?></button>
			</p>
		<?php } ?>
	</div>
	<div class="reyhoon-services-selector__lookup">
		<!--input type="text" class="reyhoon-services-selector__lookup-city" value="<?php echo esc_attr( $shipping_city ); ?>" placeholder="<?php esc_attr_e( 'City', 'woocommerce' ); ?>" name="reyhoon_city" /-->
		<input type="text" class="reyhoon-services-selector__lookup-postcode" value="<?php echo esc_attr( $shipping_postcode ); ?>" placeholder="<?php esc_attr_e( 'Postcode / ZIP', 'woocommerce' ); ?>" name="reyhoon_postcode" />
		<span class="reyhoon-services-selector__lookup-buttons">
			<button data-reyhoon-trigger="lookup-services" data-reyhoon-service="delivery"><?php esc_html_e( 'Delivery', 'woocommerce' ); ?></button>
			<button data-reyhoon-trigger="lookup-services" data-reyhoon-service="pickup"><?php esc_html_e( 'Pickup', 'woocommerce' ); ?></button>
		</span>
	</div>
	<div class="reyhoon-services-selector__lookup-message"></div>
</div>
