<?php
/**
 * Module: Services order.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Services order class.
 */
class Reyhoon_Services_Order {
	/**
	 * Init.
	 */
	public static function run() {
		add_action( 'restrict_manage_posts', array( __CLASS__, 'services_filter' ), 50 );
		add_action( 'pre_get_posts', array( __CLASS__, 'filter_admin_orders' ), 100 );
		add_filter( 'manage_edit-shop_order_columns', array( __CLASS__, 'add_admin_order_columns' ), 10 );
		add_action( 'manage_shop_order_posts_custom_column', array( __CLASS__, 'add_admin_order_columns_content' ), 10, 2 );
		add_filter( 'reyhoon_get_order_date_time', array( __CLASS__, 'modify_order_date_time_labels' ), 10, 2 );
		add_action( 'woocommerce_before_order_object_save', array( __CLASS__, 'before_save_order' ), 10, 2 );
	}

	/**
	 * Services filter.
	 */
	public static function services_filter() {
		$service = self::get_filtered_service();
		?>
		<select name="reyhoon_service">
			<option value=""><?php esc_attr_e( 'All services', 'reyhoon' ); ?></option>
			<option value="delivery" <?php selected( $service, 'delivery' ); ?>><?php esc_attr_e( 'Delivery', 'reyhoon' ); ?></option>
			<option value="pickup" <?php selected( $service, 'pickup' ); ?>><?php esc_attr_e( 'Pickup', 'reyhoon' ); ?></option>
		</select>
		<?php
	}

	/**
	 * Get filtered service.
	 *
	 * @return mixed
	 */
	public static function get_filtered_service() {
		$service = filter_input( INPUT_GET, 'reyhoon_service', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		if ( ! $service ) {
			return '';
		}

		return $service;
	}

	/**
	 * Filter orders.
	 *
	 * @param WP_Query $query
	 */
	public static function filter_admin_orders( $query ) {
		if ( ! Reyhoon_Orders::is_orders_page() || 'shop_order' !== $query->get( 'post_type' ) ) {
			return;
		}

		$meta_query = (array) $query->get( 'meta_query' );
		$service    = self::get_filtered_service();

		if ( ! empty( $service ) ) {
			$meta_query[] = array(
				'key'   => '_reyhoon_service_type',
				'value' => $service,
			);
		}

		$query->set( 'meta_query', $meta_query );
	}

	/**
	 * Get service type for an order.
	 *
	 * @param WC_Order $order
	 *
	 * @return bool|string
	 */
	public static function get_service_type( $order ) {
		$shipping_methods = $order->get_shipping_methods();
		$type             = false;

		if ( empty( $shipping_methods ) ) {
			return apply_filters( 'reyhoon_get_service_type', $type, $order );
		}

		$shipping_method    = array_shift( $shipping_methods );
		$shipping_method_id = $shipping_method->get_method_id();

		$type = Reyhoon_Services::is_pickup_method( $shipping_method_id ) ? 'pickup' : 'delivery';

		return apply_filters( 'reyhoon_get_service_type', $type, $order );
	}

	/**
	 * Add columns to admin orders screen.
	 *
	 * @param array $columns
	 *
	 * @return array
	 */
	public static function add_admin_order_columns( $columns ) {
		$columns['reyhoon_service_type'] = 'روش تحویل';

		return $columns;
	}

	/**
	 * Add columns content to admin orders screen.
	 *
	 * @param $column_name
	 * @param $post_id
	 */
	public static function add_admin_order_columns_content( $column_name, $post_id ) {
		if ( 'reyhoon_service_type' === $column_name ) {
			$order = wc_get_order( $post_id );

			$type = $order->get_shipping_methods();
			$type = empty($type) ? 'no_shipping_method' : end($type)->get_method_id() ;

			// مقادیر پیش‌فرض
			$background = '#e2e8f0';
			$color = '#64748b';

			switch ($type) {
                case 'reyhoon_motorcycle':
                    $background = '#03045e26';
                    $color = '#03045e';
                    break;

                case 'reyhoon_local_pickup':
                    $background = '#2c6e4930';
                    $color = '#2c6e49';
                    break;

                case 'reyhoon_serving':
                    $background = '#d9042926';
                    $color = '#d90429';
                    break;

                default:
                    $background = '#e2e8f0';
                    $color = '#64748b';
                    break;
            }

			printf( '<mark class="order-status order-status--%s" style="background-color: %s; color: %s;"><span>%s</span></mark>', esc_attr( $type ), esc_attr( $background ),esc_attr( $color ), $order->get_shipping_method() );
		}

	}

	/**
	 * Modify order date/time labels.
	 *
	 * @param array    $labels
	 * @param WC_Order $order
	 *
	 * @return array
	 */
	public static function modify_order_date_time_labels( $labels, $order ) {
		$type       = Reyhoon_Services_Order::get_service_type( $order );
		$type_label = Reyhoon_Services::get_service_label( $type );

		$labels['order_date']['label'] = sprintf( '%s %s', $labels['order_date']['label'], $type_label );
		$labels['order_time']['label'] = sprintf( '%s %s', $labels['order_time']['label'], $type_label );

		return $labels;
	}

	/**
	 * Save order meta.
	 *
	 * @param WC_Abstract_Order $abstract_order
	 * @param WC_Data_Store     $data_store
	 *
	 * @return string
	 */
	public static function before_save_order( $abstract_order, $data_store ) {
		if ( empty( $abstract_order ) ) {
			return;
		}

		$type = Reyhoon_Services_Order::get_service_type( $abstract_order );

		$abstract_order->update_meta_data( '_reyhoon_service_type', $type );
	}
}
