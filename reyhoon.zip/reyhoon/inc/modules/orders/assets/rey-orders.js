function openACC(button) {
    jQuery(function($) {
        let orderRow = $(button).closest('.woocommerce-orders-table__row');
        let accContent = orderRow.find('.acc-content');

        $('.woocommerce-orders-table__row').removeClass('open');
        orderRow.addClass('open');

        // for close open acc
        if( accContent.css('display') == 'block'){
            accContent.hide(300);
            orderRow.removeClass('open');
            return;
        }

        $('.acc-content').hide(300);
        accContent.show(300);

    });
}
