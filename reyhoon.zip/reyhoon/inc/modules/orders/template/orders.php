<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header('reyhoon');
wp_enqueue_style( 'rey-orders' );
wp_enqueue_script( 'rey-orders' );

$orders = Reyhoon_Orders::get_orders();
if(!is_user_logged_in()) {
    echo do_shortcode('[reyhoon_otp]');
    get_footer();
    return;
}
if ( ! empty( $orders['active'] ) ) { ?>
    <div class="woocommerce-orders-table woocommerce-MyAccount-orders">
        <h1 class="reyhoon-orders-h1"> <?php _e("Active Orders:",'reyhoon'); ?> </h1>
		<?php
		foreach ( $orders['active'] as $order ) {
			Reyhoon_Orders::get_order_card_template( $order );
		}
		?>
    </div>
	<?php
}

if ( ! empty( $orders['old'] ) ) { ?>
    <div class="woocommerce-orders-table woocommerce-MyAccount-orders">
        <h1 class="reyhoon-orders-شh1"> <?php _e("Past Orders:",'reyhoon'); ?> </h1>
		<?php
		$is_active_order_loop =$orders['is-active'];
        foreach ( $orders['old'] as $order ) {
	        Reyhoon_Orders::get_order_card_template( $order );
		}
        ?>
    </div>
	<?php
}

if (count($orders, COUNT_RECURSIVE) <= 2)
{
    $no_order_message = Reyhoon_Settings::get_setting('translate_translate_no_order_message');
    $return_shop_message = Reyhoon_Settings::get_setting('translate_translate_return_shop_message');

    ?>
    <div class="woocommerce-orders-table woocommerce-MyAccount-orders">
        <p class="reyhoon-mini-cart__empty-message">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_1397_52)">
                    <path d="M12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21Z" stroke="#FFB901" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M12 8H12.01" stroke="#FFB901" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M11 12H12V16H13" stroke="#FFB901" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </g>
                <defs>
                    <clipPath id="clip0_1397_52">
                        <rect width="24" height="24" fill="white"/>
                    </clipPath>
                </defs>
            </svg>

            <?php
                echo $no_order_message? : __('شما هنوز سفارشی ثبت نکرده اید.','reyhoon');
             ?>
        </p>

        <div class="cart-empty-background">
		    <?php
            $upload_img=Reyhoon_Settings::get_setting('translate_translate_upload_img');
                echo $upload_img ? "<img src='$upload_img' style='max-width:765px;'>" :   Reyhoon_Helpers::echo_svg('cart-empty-background');
            ?>
        </div>

        <a href="<?= home_url(); ?>" class="empty-cart-btn"><?php echo $return_shop_message ? : __('بازگشت به منو مجموعه','reyhoon'); ?></a>
    </div>

<?php
}

