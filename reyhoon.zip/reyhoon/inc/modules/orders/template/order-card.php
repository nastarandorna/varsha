<?php
?>

<div class="woocommerce-orders-table__row order <?= $order->get_status(); ?>">
    <div class="reyhoon-order-status">
        <div class="order-status-container">
            <div class="order-status">
				<?php Reyhoon_Orders::get_order_icon( $order->get_status() ) ?>
            </div>
            <div class="order-status-nice-name">
                <span><?php _e('order ststus :','reyhoon'); ?></span>
                <p><?php Reyhoon_Orders::get_order_status_name( $order->get_status() ) ?></p>
            </div>
        </div>
        <div class="order-status-details">
            <div class="order-status-details-address">
                <p><span><?php _e("Delivery to:",'reyhoon'); ?></span> <?php echo wp_kses_post( $order->get_billing_address_1() ); ?></p>
            </div>
            <div class="order-items-image">
				<?php
				$items = $order->get_items();
				foreach ( $items as $item_id => $item ) {
					$product      = $item->get_product();
                    // if product removed
                    if(!$product) {
                        $thumbnail_id = false;
                    }else {
                        $thumbnail_id = $product->get_image_id();
                    }
					?>
                    <div class="order-items-image-container">
	                    <?php if(wp_get_attachment_image_url( $thumbnail_id ) == false) { ?>
		                        <img src = "<?php echo REYHOON_ASSETS_URL.'img/no-image.png' ?>" alt = "image" >
	                    <?php    }
                            else{ ?>
	                            <img src="<?= wp_get_attachment_image_url( $thumbnail_id ) ?>">
                            <?php    } ?>
                        <span class="order-items-image-count"><?= $item->get_quantity(); ?></span>
                    </div>
					<?php
				}
				?>
            </div>
        </div>
    </div>

    <div class="order-operation">

        <div class="order-delivery-time"><?php _e("Delivery until:",'reyhoon'); ?> <?=Reyhoon_Orders::get_delivery_time($order); ?></div>

        <div class="order-again">
			<?php
			$order_again_url = wp_nonce_url( add_query_arg( 'order_again', $order->get_id(), wc_get_cart_url() ), 'woocommerce-order_again' );
			?>
            <span>
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none"
                     xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_691_311)">
                        <path d="M13.3332 7.33334C13.1701 6.16015 12.6259 5.07311 11.7843 4.23967C10.9426 3.40623 9.85034 2.87262 8.67562 2.72104C7.50089 2.56947 6.30892 2.80833 5.2833 3.40084C4.25769 3.99335 3.45534 4.90663 2.99984 6.00001M2.6665 3.33334V6.00001H5.33317"
                              stroke="#071117" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M2.6665 8.66669C2.82954 9.83987 3.37379 10.9269 4.21541 11.7604C5.05703 12.5938 6.14933 13.1274 7.32406 13.279C8.49878 13.4306 9.69076 13.1917 10.7164 12.5992C11.742 12.0067 12.5443 11.0934 12.9998 10M13.3332 12.6667V10H10.6665"
                              stroke="#071117" stroke-linecap="round" stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_691_311">
                            <rect width="16" height="16" fill="white"/>
                        </clipPath>
                    </defs>
                </svg>
            </span>
            <a href="<?php echo esc_url( $order_again_url ); ?>"
               class="button"><?php esc_html_e( 'Order again', 'woocommerce' ); ?></a>
        </div>

        <div class="order-show-details">
            <button class="woocommerce-button button view" onclick="openACC(this)">
                <?php _e('show details','reyhoon'); ?>
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_683_57)">
                        <path d="M4 6L8 10L12 6" stroke="#071117" stroke-linecap="round"
                              stroke-linejoin="round"/>
                    </g>
                    <defs>
                        <clipPath id="clip0_683_57">
                            <rect width="16" height="16" fill="white" transform="translate(0 16) rotate(-90)"/>
                        </clipPath>
                    </defs>
                </svg>
            </button>
        </div>
    </div>

    <div class="acc-content">
		<?php
		wc_get_template( 'order/order-details.php', array(
			'order_id' => $order->get_id(),
		) );
		?>

        <div class="order-operation">
            <div class="order-show-details order-show-id"><?php _e("Order Number:",'reyhoon'); ?> <?php echo $order->get_id() ?>#</div>
            <div class="order-show-details">
                <div class="woocommerce-button button view">
                     <?php _e('date :','reyhoon'); echo wc_format_datetime( $order->get_date_created(), 'd M Y' ); ?></div>
            </div>
        </div>
    </div>

</div>
