(function( $, document ) {
	"use strict";

	var reyhoon_live_view = {
		/**
		 * On doc ready.
		 */
		on_ready: function() {
			reyhoon_live_view.mute_button();
			reyhoon_live_view.update_url_for_order_status_buttons();
		},

		/**
		 * Heartbeat send.
		 *
		 * @param e
		 * @param data
		 */
		on_heartbeat_send: function( e, data ) {
			data[ 'reyhoon_heartbeat' ] = 'reyhoon_live_view';
			data[ 'reyhoon_filtered_service' ] = reyhoon_live_view_vars.filtered_service;
			data[ 'reyhoon_filtered_due_date' ] = reyhoon_live_view_vars.filtered_due_date;
			data[ 'reyhoon_orderby' ] = reyhoon_live_view_vars.orderby;
			data[ 'reyhoon_last_order_id' ] = reyhoon_live_view.get_last_order_id();
		},

		/**
		 * Get last order ID.
		 *
		 * @return {number}
		 */
		get_last_order_id: function() {
			return parseInt( reyhoon_live_view_vars.last_order_id );
		},

		/**
		 * Heartbeat tick.
		 *
		 * @param e
		 * @param data
		 */
		on_heartbeat_tick: function( e, data ) {
			if ( typeof data.reyhoon === 'undefined' ) {
				return;
			}

			if ( data.reyhoon.last_order_id <= reyhoon_live_view.get_last_order_id() ) {
				 return;
			}

			// If there are new orders, reload the page.
			$( '#posts-filter' ).load( reyhoon_live_view_vars.url + ' #posts-filter > *', function( response, status, xhr ) {
				reyhoon_live_view.play_ding();

				if ( status === "error" ) {
					console.log( 'Live View Error Response', response );
					console.log( 'Live View Error Status', status );
				}

				$( document ).trigger( 'reyhoon-live-view-updated' );
			} );
		},

		/**
		 * Play ding sound.
		 */
		play_ding: function() {
			var mute_status = parseInt( $( '.reyhoon-live-view-button--audio' ).data( 'reyhoon-mute-status' ) ),
				$ding = $( '#reyhoon_ding' );

			if ( 1 === mute_status || $ding.length < 0 ) {
				return;
			}

			$ding[0].play();
		},

		/**
		 * Setup mute button.
		 */
		mute_button: function() {
			$( '.reyhoon-live-view-button--audio' ).on( 'click', function() {
				var $button = $( this ),
					mute_status = parseInt( $button.data( 'reyhoon-mute-status' ) ) === 1 ? 0 : 1, // invert status.
					current_text = $button.text(),
					new_text = $button.data( 'reyhoon-alt-text' );

				$button.data( 'reyhoon-mute-status', mute_status ).data( 'reyhoon-alt-text', current_text ).text( new_text );
			} );
		},

		/**
		 * Append '&reyhoon_live_view' to the order status hyperlinks.
		 */
		update_url_for_order_status_buttons: function () {
			$( '.subsubsub li a' ).each( function () {
				var href = $( this ).attr( 'href' );
				$( this ).attr( 'href', `${href}&reyhoon_live_view` );
			} );
		}
	};

	$( document ).ready( reyhoon_live_view.on_ready );
	$( document ).on( 'heartbeat-send', reyhoon_live_view.on_heartbeat_send );
	$( document ).on( 'heartbeat-tick', reyhoon_live_view.on_heartbeat_tick );
}( jQuery, document ));