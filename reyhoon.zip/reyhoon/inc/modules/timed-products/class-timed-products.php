<?php
/**
 * Module: Timed Products.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Timed Products module class.
 */
class Reyhoon_Timed_Products {
	/**
	 * Init.
	 */
	public static function run() {
		add_filter( 'reyhoon_valid_admin_pages', array( __CLASS__, 'add_valid_admin_pages' ) );
		add_action( 'admin_menu', array( __CLASS__, 'add_settings_page' ) );
	}

	/**
	 * Add valid admin page.
	 */
	public static function add_valid_admin_pages( $pages = array() ) {
		$pages[] = 'reyhoon-timed-products';

		return $pages;
	}

	/**
	 * Add settings page.
	 */
	public static function add_settings_page() {
		add_submenu_page( 'reyhoon', __( 'Timed Products', 'reyhoon' ), sprintf( '%s <span class="update-plugins" style="background-color: #ffffff1c"><span class="plugin-count">%s</span></span>', __( 'Timed Products', 'reyhoon' ), __( 'Pro', 'reyhoon' ) ), 'manage_options', 'reyhoon-timed-products', array( __CLASS__, 'timed_products_page' ), 10 );
	}

	/**
	 * Timed Products page.
	 */
	public static function timed_products_page() {
		Reyhoon_Settings::upgrade_page_content( __( 'Timed Products', 'reyhoon' ) );
	}
}
