<?php
/**
 * Layout: Single product.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/layouts/products-list.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 *
 * @var array $products Array of products.
 * @var array $args     Array of shortcode args.
 * @var array $child_category_group     Array of shortcode args.
 */

defined( 'ABSPATH' ) || exit;

switch ($args['cards']){
    case 'style_2':
        $cards_style = 'single-column-card';
        break;
    case 'style_3':
        $cards_style = 'style-3';
}

?>

<div id="category-<?php echo esc_attr( is_array( $child_category_group['category'] ) ? $child_category_group['category']['id'] : 'uncategorized' ); ?>" class="reyhoon-products-list reyhoon-products-list--grid">
	<?php foreach ( $products as $product ) {
		//FIXME add option for supermarket
		?>
		<div class="reyhoon-products-list__item <?=$cards_style?>">
			<?php include Reyhoon_Helpers::get_template_path( 'product.php', 'layouts' ); ?>
		</div>
	<?php } ?>
</div>
