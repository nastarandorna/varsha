<?php
/**
 * Layout: Single product.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/layouts/product.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 *
 * @var array $category Category array.
 * @var WC_Product $product Product object.
 * @var array $args Array of args for the shortcode.
 */

defined('ABSPATH') || exit;

$class = Reyhoon_Layouts::get_product_card_classes($args);
$click_cart = true;

if (class_exists('Reyhoon_Ajax_Quantity_Pro')) {
    $has_addones = Reyhoon_Ajax_Quantity_Pro::product_have_addones($product->get_id());
    $click_cart = $has_addones ? true : false;
}
if (!Reyhoon_Settings::get_setting('store_general_rey_status')) {
    $class[] = 'out-of-service';
}
?>
<div class="<?php echo esc_attr(implode(' ', $class)); ?>"
    <?php if ($click_cart) { ?>
        data-reyhoon-product-id="<?php echo esc_attr($product->is_type('variation') ? $product->get_parent_id() : $product->get_id()); ?>"
        data-reyhoon-product-type="<?php echo esc_attr($product->get_type()); ?>"
        data-reyhoon-variation-id="<?php echo esc_attr($product->is_type('variation') ? $product->get_id() : 0); ?>"
        data-reyhoon-variation-attributes=""
    <?php } ?>
>
   <?php if($product->is_on_sale()){
       $percentage = round(($product->get_regular_price() - $product->get_sale_price()) / $product->get_regular_price() * 100);
       echo '<span class="onsale ryh-onsale">' .  $percentage . '% </span>';
   } ?>
    <div class="food-info">
        <?php include Reyhoon_Helpers::get_template_path('templates/product/card-content.php'); ?>
        <?php include Reyhoon_Helpers::get_template_path('templates/product/hero.php'); ?>
    </div>

    <?php
    $layout = Reyhoon_Settings::get_setting('store_general_product_layout');
    if (isset($layout) && $layout === 'variable') {
        include Reyhoon_Helpers::get_template_path('templates/product/variable-actions.php');
    } else {
        include Reyhoon_Helpers::get_template_path('templates/product/actions.php');
    }
    ?>
</div>
