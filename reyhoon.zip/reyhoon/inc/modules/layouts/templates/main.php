<?php
/**
 * Layout: Main layout.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/layouts/main.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 *
 * @var array $products Array of products, sorted by category.
 * @var array $args     Array of shortcode args.
 */

defined( 'ABSPATH' ) || exit;

$original_products = $products;
?>

<div class="reyhoon-main <?php echo esc_attr( apply_filters( 'reyhoon_main_class', '', $args ) ); ?>">
	<?php do_action( 'reyhoon_main_before_sections', $args, $original_products ); ?>



	<div class="reyhoon-main__sections">
		<?php foreach ( $products as $product_group ) { ?>
			<?php
			$category             = $product_group['category'];
			$products             = $product_group['products'];
			$has_child_categories = ! empty( $category['children'] );
            $thumbnail_id = get_term_meta($category['id'], 'thumbnail_id', true);
            $image = wp_get_attachment_url($thumbnail_id);
			?>

			<?php if ( empty( $product_group['products'] ) && ! $has_child_categories ) {
				continue;
			} ?>

			<div id="category-<?php echo esc_attr( is_array( $category ) ? $category['id'] : 'uncategorized' ); ?>" class="reyhoon-main__group">

                <h3 class="reyhoon-tab-title">
                    <span><?php echo $image ? "<img src='{$image}'>" : "" ?><?php echo esc_attr( is_array( $category ) ? $category['name'] : 'uncategorized' ); ?></span>
                </h3>

                <?php do_action( 'reyhoon_main_before_products', $args, $product_group['category'], $product_group['products'] ); ?>

				<?php if ( $has_child_categories ) {
				    echo '<div class="child-group">';
					foreach ( $product_group['category']['children'] as $child_category_group ) {
						$category = $child_category_group['category'];
						$products = $child_category_group['products'];

						if ( empty( $products ) ) {
							continue;
						}

						do_action( 'reyhoon_main_before_products_category_children', $args, $category, $products );

						include Reyhoon_Helpers::get_template_path( 'products-list.php', 'layouts' );

						do_action( 'reyhoon_main_after_products_category_children', $args, $category, $products );
					}
                    echo '</div>';
				} else {
                    $child_category_group['category'] = "";
					include Reyhoon_Helpers::get_template_path( 'products-list.php', 'layouts' );
				} ?>

				<?php do_action( 'reyhoon_main_after_products', $args, $product_group['category'], $product_group['products'] ); ?>
			</div>
		<?php } ?>
	</div>

	<?php do_action( 'reyhoon_main_after_sections', $args, $original_products ); ?>
</div>
