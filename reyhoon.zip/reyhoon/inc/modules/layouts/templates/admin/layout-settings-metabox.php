<div class="reyhoon-fields-row reyhoon-fields-row--meta">
    <div class="reyhoon-fields-row__body">

        <div class="reyhoon-fields-row__body-row">
            <div class="reyhoon-fields-row__body-row-left">
                <h3>
                    <label for="categories"><?php _e( 'Categories', 'reyhoon' ); ?></label>
                </h3>
                <p><?php _e( 'Select which product categories to display in this layout.', 'reyhoon' ); ?></p>
            </div>
            <div class="reyhoon-fields-row__body-row-right">
                <?php
                // Categories.
                woocommerce_wp_select(
                    array(
                        'id'                => 'reyhoon_categories',
                        'name'              => 'reyhoon_categories[]',
                        'class'             => 'reyhoon-select reyhoon-select--multi-select reyhoon-select--categories',
                        'label'             => '',
                        'options'           => Reyhoon_Layouts::get_categories(),
                        'value'             => $layout_settings['categories'],
                        'custom_attributes' => array(
                            'multiple' => 'multiple',
                        ),
                    )
                );
                ?>
            </div>
        </div>

        <div class="reyhoon-fields-row__body-row">
            <div class="reyhoon-fields-row__body-row-left">
                <h3>
                    <label for="layout"><?php _e( 'Sections', 'reyhoon' ); ?></label>
                </h3>
                <p><?php _e( 'Separate each category by titles or tabs.', 'reyhoon' ); ?></p>
            </div>
            <div class="reyhoon-fields-row__body-row-right">
                <?php echo Reyhoon_Layouts::get_layout_sections_field( $layout_settings ); ?>
            </div>
        </div>

        <div class="reyhoon-fields-row__body-row">
            <div class="reyhoon-fields-row__body-row-left">
                <h3>
                    <label for="layout-card"><?php _e( 'Card Layout', 'reyhoon' ); ?></label>
                </h3>
                <p><?php _e( 'Product card layout.', 'reyhoon' ); ?></p>
            </div>
            <div class="reyhoon-fields-row__body-row-right">
                <?php echo Reyhoon_Layouts::get_layout_cards_field( $layout_settings ); ?>
            </div>
        </div>

        <div class="reyhoon-fields-row__body-row">
            <div class="reyhoon-fields-row__body-row-left">
                <h3>
                    <label for="images"><?php _e( 'Images', 'reyhoon' ); ?></label>
                </h3>
                <p><?php _e( 'Should product images be displayed?', 'reyhoon' ); ?></p>
            </div>
            <div class="reyhoon-fields-row__body-row-right">
                <?php
                // Images.
                woocommerce_wp_checkbox(
                    array(
                        'id'    => 'reyhoon_images',
                        'label' => '',
                        'value' => wc_bool_to_string( $layout_settings['images'] ),
                    )
                );
                ?>
            </div>
        </div>

        <div class="reyhoon-fields-row__body-row">
            <div class="reyhoon-fields-row__body-row-left">
                <h3>
                    <label for="clickable_card"><?php _e( 'Clickable Card', 'reyhoon' ); ?></label>
                </h3>
                <p><?php _e( 'Choose what happens when you click the product card.', 'reyhoon' ); ?></p>
            </div>
            <div class="reyhoon-fields-row__body-row-right">
                <?php
                // Layout.
                woocommerce_wp_select(
                    array(
                        'id'      => 'reyhoon_card_click',
                        'label'   => '',
                        'options' => array(
                            ''             => __( 'Nothing', 'reyhoon' ),
                            'view-product' => __( 'Quick View Product', 'reyhoon' ),
                        ),
                        'value'   => esc_attr( $layout_settings['card_click'] ),
                    )
                );
                ?>
            </div>
        </div>

    </div>
</div>
