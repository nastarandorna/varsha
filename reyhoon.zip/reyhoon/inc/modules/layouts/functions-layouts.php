<?php
/**
 * Functions: Layouts.
 *
 * @package Reyhoon/Functions
 */

defined( 'ABSPATH' ) || exit;

/**
 * Reyhoon function to render layout.
 *
 * @param int|null $id
 */
function reyhoon( $id = null ) {
	echo Reyhoon_Layouts::reyhoon_shortcode( array(
		'id' => $id,
	) );
}