<?php
defined('ABSPATH') || exit;

class Reyhoon_Header
{

    public static function run()
    {
        //add_action('get_header',  array(__CLASS__, 'xxxx'), 500, 2 );
        add_action('reyhoon_after_header', [__CLASS__, 'add_reyhoon_header_widget'], 15);
        add_action('wp_footer', [__CLASS__, 'toolbar_widget']);
        add_action('add_meta_boxes', [__CLASS__, 'add_meta_box_display_toolbar']);
        add_action('save_post', [__CLASS__,'save_display_toolbar_meta']);
    }

    public static function add_reyhoon_header_widget()
    {

        if (!is_account_page()) {
            echo do_shortcode("[reyhoon_header_widget]");
            echo shortcode_exists('reyhoon_last_orders') ? do_shortcode("[reyhoon_last_orders]") : '';
        }
    }

    public static function toolbar_widget()
    {
        $page_id = get_queried_object_id();
        $display_toolbar = get_post_meta($page_id, '_display_toolbar', true);
        if (wp_is_mobile() && empty($display_toolbar) && !is_checkout()) {
            echo shortcode_exists('reyhoon_toolbar_widget') ? do_shortcode("[reyhoon_toolbar_widget]") : '';
        }

    }

    public static function add_meta_box_display_toolbar()
    {
        add_meta_box(
            'display_toolbar_meta_box',
            ' تولبار',
            [__CLASS__,'display_toolbar_meta_box_callback'],
            'page',
            'side',
            'default'
        );
    }


     public static function display_toolbar_meta_box_callback($post)
    {
        $display_toolbar = get_post_meta($post->ID, '_display_toolbar', true);

        echo '<label for="display_toolbar">';
        echo '<input type="checkbox" id="display_toolbar" name="display_toolbar" value="1" ' . checked(1, $display_toolbar, false) . ' />';
        echo 'عدم نمایش تولبار';
        echo '</label>';
        wp_nonce_field('save_display_toolbar_meta', 'display_toolbar_meta_nonce');
    }
    public static function save_display_toolbar_meta($post_id) {
        if (!isset($_POST['display_toolbar_meta_nonce']) || !wp_verify_nonce($_POST['display_toolbar_meta_nonce'], 'save_display_toolbar_meta')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (isset($_POST['display_toolbar'])) {
            update_post_meta($post_id, '_display_toolbar', 1);
        } else {
            update_post_meta($post_id, '_display_toolbar', 0);
        }
    }



}

