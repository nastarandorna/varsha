<?php

/**
 * Module: Checkout Pro.
 *
 * @package Reyhoon/Classes
 */
defined('ABSPATH') || exit;

/**
 * Checkout module class.
 */
class Reyhoon_Checkout
{

    public static $checkout_type;

    /**
     * Init.
     */
    public static function run()
    {

        self::$checkout_type = Reyhoon_Settings::get_setting('store_general_checkout_type');
        self::$checkout_type = self::$checkout_type ?: 'reyhoon';

        self::general_hooks();

        if (self::$checkout_type === 'reyhoon') {
            self::checkout_reyhoon();
        } else {
            if (Reyhoon_Helpers::is_smart_table()) {
                self::checkout_reyhoon();
            } else {
                self::checkout_woo();
            }
        }
    }


    public static function general_hooks()
    {
        //Load Custom Template.
        add_filter('woocommerce_locate_template', array(__CLASS__, 'reyhoon_locate_template'), 10, 3);
        add_filter('woocommerce_checkout_fields', array(__CLASS__, 'checkout_fields_in_pickup'), 20, 1);
        add_action('woocommerce_cart_calculate_fees', [__CLASS__, 'add_packaging_cost']);
        add_filter('woocommerce_checkout_fields', array(__CLASS__, 'checkout_fields_in_stp'), 30, 1);

    }

    public static function checkout_reyhoon()
    {
        // Better x-theme compatibility.
        add_filter('woocommerce_enqueue_styles', '__return_empty_array');

        add_action('wp_enqueue_scripts', array(__CLASS__, 'frontend_assets'));

        add_filter('woocommerce_checkout_fields', array(__CLASS__, 'checkout_fields'), 15, 1);

        //reposition order review after payment method
        remove_action('woocommerce_checkout_order_review', 'woocommerce_order_review', 10);
        add_action('woocommerce_checkout_order_review', 'woocommerce_order_review', 30);

        // remove_action('woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10);
        // add_action('woocommerce_before_checkout_billing_form', 'woocommerce_checkout_coupon_form', 10);

        remove_action('woocommerce_checkout_order_review', 'woocommerce_checkout_payment', 20);
        add_action('reyhon_after_customer_details', 'woocommerce_checkout_payment', 20);


        add_filter('woocommerce_gateway_icon', array(__CLASS__, 'custom_payment_gateway_icons'), 10, 2);

    }

    public static function checkout_woo()
    {
        add_action('wp_enqueue_scripts', array(__CLASS__, 'frontend_assets_for_woo_checkout'));

        remove_action('woocommerce_review_order_before_submit', array('Reyhoon_Timings_Checkout', 'output_timing_fields'));
        add_action('reyhoon_before_payment', array('Reyhoon_Timings_Checkout', 'output_timing_fields'), 0);

        add_filter('woocommerce_checkout_fields', array(__CLASS__, 'defualt_checkout_fields'), 15, 1);
        add_filter('woocommerce_twenty_twenty_styles', '__return_false');
        add_filter('woocommerce_twenty_twenty_one_styles', '__return_false');
        add_filter('woocommerce_twenty_twenty_two_styles', '__return_false');
        add_filter('woocommerce_twenty_twenty_two_styles', '__return_false');
        add_filter('woocommerce_enqueue_styles', '__return_false');

    }

    /**
     * Add custom template support for woocommerce.
     */
    public static function reyhoon_locate_template($template, $template_name, $template_path)
    {
        global $woocommerce;

        if (is_checkout() && self::$checkout_type === 'woocommerce') {
            if (Reyhoon_Helpers::is_smart_table()) {
                $plugin_path = REYHOON_PATH . 'woocommerce/';
            } else {
                $plugin_path = REYHOON_PATH . 'woocommerce/woo-default/';
            }
        } else {
            $plugin_path = REYHOON_PATH . 'woocommerce/';
        }

        if (file_exists($plugin_path . $template_name)) {
            $template = $plugin_path . $template_name;
        }

        return $template;
    }


    public static function checkout_fields_in_pickup($fields)
    {
        if (!$_POST || (is_admin() && !is_ajax())) {
            return $fields;
        }

        if (isset($_GET['wc-ajax']) && Reyhoon_Services::get_selected_service(false) === 'pickup') {
            unset($fields['billing']['billing_address_1']);
        }
        return $fields;
    }

    /**
     * Get an array of checkout fields.
     */
    public static function checkout_fields($fields)
    {

        unset($fields['billing']['billing_email']);
        unset($fields['billing']['billing_last_name']);
        unset($fields['billing']['billing_company']);
        //unset($fields['billing']['billing_address_2']);
        unset($fields['billing']['billing_city']);
        unset($fields['billing']['billing_state']);
        //unset($fields['billing']['billing_country']);
        unset($fields['billing']['billing_postcode']);

        $fields['billing']['billing_first_name']['placeholder'] = 'نام';
        $fields['billing']['billing_first_name']['label'] = 'تحویل گیرنده';

        $fields['billing']['billing_address_1']['placeholder'] = 'آدرس';
        $fields['billing']['billing_address_1']['label'] = 'آدرس تحویل';
        $fields['billing']['billing_address_1']['type'] = 'textarea';

        $fields['billing']['billing_address_2']['placeholder'] = 'مثال: پلاک 32، واحد 4';
        $fields['billing']['billing_address_2']['label'] = 'جزئیات آدرس';


        $fields['billing']['billing_phone']['placeholder'] = 'شماره تماس';
        $fields['billing']['billing_phone']['label'] = 'شماره تماس';
        $fields['billing']['billing_phone']['priority'] = 20;

        /**
         * remove al shipping field
         */
        foreach ($fields['shipping'] as $key => $field) {
            unset($fields['shipping'][$key]);
        }

        $fields['order']['order_comments']['placeholder'] = 'توضیحات خاصی برای آماده‌سازی و ارسال سفارش مد نظرتان است؟ اینجا بنویسید.';

        if (Reyhoon_Helpers::is_smart_table()) {
            unset($fields['billing']['billing_address_1']);
        }

        return $fields;
    }

    public static function defualt_checkout_fields($fields)
    {
        unset($fields['billing']['billing_email']);
        unset($fields['billing']['billing_postcode']);

        return $fields;
    }

    public static function checkout_fields_in_stp($fields)
    {

        if (self::is_smart_table()) {
            $fields['billing']['billing_first_name']['required'] = false;
            $fields['billing']['billing_phone']['required'] = false;
            return $fields;
        }
        return $fields;
    }

    /**
     * Enqueue frontend assets.
     */
    public static function frontend_assets()
    {
        if (is_admin() || !is_checkout()) {
            return;
        }

        global $wp_scripts, $wp_styles;

        foreach ($wp_scripts->queue as $key => $name) {
            $src = $wp_scripts->registered[$name]->src;
            if (strpos($src, '/themes/')) {
                wp_dequeue_script($name);
            }
        }

        foreach ($wp_styles->queue as $key => $name) {
            $src = $wp_styles->registered[$name]->src;
            // The twenty-x themes have custom CSS within woo.
            if (strpos($src, '/themes/') || strpos($src, '/twenty')) {
                wp_dequeue_style($name);
            }
        }

        //$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
        $suffix_css = is_rtl() ? '-rtl' : '';

        // Styles.
        wp_enqueue_style('reyhoon-checkout-pro', REYHOON_URL . 'inc/modules/checkout/assets/frontend/css/checkout-pro' . $suffix_css . '.css', array(), REYHOON_VERSION);

        // Scripts.
        wp_enqueue_script('reyhoon-checkout-pro', REYHOON_URL . 'inc/modules/checkout/assets/frontend/js/main.js', array('jquery', 'wc-checkout', 'reyhoon'), REYHOON_VERSION, true);

    }

    public static function frontend_assets_for_woo_checkout()
    {

        if (is_admin() || !is_checkout()) {
            return;
        }

        $suffix_css = is_rtl() ? '-rtl' : '';

        // Styles.
        wp_enqueue_style('reyhoon-checkout-woo-pro', REYHOON_URL . 'inc/modules/checkout/assets/frontend/css/checkout-woo' . $suffix_css . '.css', array(), REYHOON_VERSION);

        // Scripts.
        wp_enqueue_script('reyhoon-checkout-woo', REYHOON_URL . 'inc/modules/checkout/assets/frontend/js/checkout-woo.js', array('jquery', 'wc-checkout', 'reyhoon'), REYHOON_VERSION, true);
        wp_enqueue_script('reyhoon-checkout-pro', REYHOON_URL . 'inc/modules/checkout/assets/frontend/js/main.js', array('jquery', 'wc-checkout', 'reyhoon'), REYHOON_VERSION, true);

    }


    /**
     * Add an image on Woocommerce payment method title
     */

    public static function custom_payment_gateway_icons($icon, $gateway_id)
    {

        $geteway_list = array(
            'payir'
        );

        $svg_path = REYHOON_ASSETS_URL . 'svg';
        $img_path = REYHOON_ASSETS_URL . 'img';

        // Setting (or not) a custom icon to the payment IDs
        if ($gateway_id == 'cod')
            $icon = '<img src="' . WC_HTTPS::force_https_url("$svg_path/payment-method-code.svg") . '" alt="' . '" />';
        elseif ($gateway_id != 'cheque' && $gateway_id != 'cod')
            $icon = '<img src="' . WC_HTTPS::force_https_url("$img_path/Shetab.png") . '" alt="' . '" />';

        return $icon;
    }

    public static function add_packaging_cost($cart)
    {
        if ((!self::is_smart_table() || !Reyhoon_Services::get_selected_service(true, true) === 'reyhoon_serving')) {
            $add_price = Reyhoon_Settings::get_setting('store_general_packaging_cost');
            if (absint($add_price) > 0) {
                $cart->add_fee('هزینه بسته بندی', $add_price);
            }
            $cart_items = WC()->cart->get_cart();

            foreach ($cart_items as $cart_item_key => $cart_item) {
                // Check if the product has the 'cost' meta
               // var_dump($cart_item['product_id']);
                $cost_meta = get_post_meta($cart_item['product_id'], 'reyhoon_metabox_packaging_cost', true);
               // var_dump($cost_meta);

                if ($cost_meta) {
                    $product = wc_get_product($cart_item['product_id']);
                    $item_cost = intval($cost_meta) * $cart_item['quantity'];
                    // Add the fee
                    $cart->add_fee('بسته بندی ' .$product->get_name() . '*'.$cart_item['quantity'] , $item_cost);
                }
            }
          //  wp_die();
        }
    }


    public static function is_smart_table()
    {
        $user = wp_get_current_user();
        $user_role = $user->roles;
        if (in_array('smart_table', $user_role)) {
            return true;
        }
        return false;
    }
}
