const showBillingForm = () => {
    document.getElementById('customer_details').classList.add('toggle-on');
    document.getElementById('backdrop').classList.add('toggle-on');
    const scrollY = document.documentElement.style.getPropertyValue('--scroll-y');
    const body = document.body;
    body.style.position = 'fixed';
    body.style.top = `-${scrollY}`;
};

const hideBillingForm = () => {
    const body = document.body;
    const scrollY = body.style.top;
    body.style.position = '';
    body.style.top = '';
    window.scrollTo(0, parseInt(scrollY || '0') * -1);
    document.getElementById('customer_details').classList.remove('toggle-on');
    document.getElementById('backdrop').classList.remove('toggle-on');

    insertBilligFormDataToAddrDiv();
};

const insertBilligFormDataToAddrDiv = () => {
    const addrBox = document.getElementById('delivery-addr');
    const inputs = {'billing_first_name': '', 'billing_last_name': '', 'billing_address_1': '', 'billing_address_2': '', 'billing_city': '', 'billing_phone': ''};

    for(let name in inputs) {
        let field = document.getElementById(name);
        if(typeof field !== 'undefined' && field !== null) {
            inputs[name] = field.value;
        }

    }

    var citySelect = document.getElementById("billing_city");
    if(typeof citySelect !== 'undefined' && citySelect !== null) {
        if(typeof citySelect.options !== 'undefined') {
            inputs.billing_city = citySelect.options[citySelect.selectedIndex].text;
        }else {
            inputs.billing_city = citySelect.value;
        }
    }
    //FIXME:
    //FIXME: not clean
    var output = '<div class="user-info"><div class="addr-box"><div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="18.759" height="21.51" viewBox="0 0 18.759 21.51"><g id="location" transform="translate(-2.623 -1.25)"><path id="Path_276" data-name="Path 276" d="M12,14.17a3.865,3.865,0,1,1,3.87-3.86A3.873,3.873,0,0,1,12,14.17Zm0-6.23a2.37,2.37,0,1,0,2.37,2.37A2.375,2.375,0,0,0,12,7.94Z" fill="#8995a6"/><path id="Path_277" data-name="Path 277" d="M12,22.76a5.971,5.971,0,0,1-4.13-1.67C4.92,18.25,1.66,13.72,2.89,8.33A9.116,9.116,0,0,1,12,1.25h.01a9.115,9.115,0,0,1,9.11,7.09c1.22,5.39-2.04,9.91-4.99,12.75A5.971,5.971,0,0,1,12,22.76ZM12,2.75A7.552,7.552,0,0,0,4.36,8.66C3.28,13.37,6.24,17.43,8.92,20a4.426,4.426,0,0,0,6.17,0c2.67-2.57,5.63-6.63,4.57-11.34A7.58,7.58,0,0,0,12,2.75Z" fill="#8995a6"/></g></svg></div><div class="addr">';
    output += '<p>' + inputs.billing_first_name + ' ' + inputs.billing_last_name + '</p>';
    output += '<h3>' + inputs.billing_city + ', ' + inputs.billing_address_1 + ' ' + inputs.billing_address_2 + '</h3>';
    output += "<p>" + inputs.billing_phone +"<button onClick='showBillingForm()'>ویرایش آدرس</button></p>";
    output += '</div></div></div>';

    addrBox.innerHTML= output;

}

window.addEventListener('scroll', () => {
    document.documentElement.style.setProperty('--scroll-y', `${window.scrollY}px`);
});


// ACC
const toggleAcc = (button) => {
    button.classList.toggle("is-open");
    let content = button.nextElementSibling;
    if (content.style.maxHeight) {
        //this is if the accordion is open
        content.style.maxHeight = null;
    } else {
        content.style.maxHeight = content.scrollHeight + "px";
    }
}
