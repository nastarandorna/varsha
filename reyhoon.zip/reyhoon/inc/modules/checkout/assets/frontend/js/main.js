( function ( $, document ) {
	"use strict";
	var reyhoon_checkout_pro = {
		/**
		 * On ready.
		 */
		on_ready: function () {

			reyhoon_checkout_pro.mobile_view();
			reyhoon_checkout_pro.toggle_delivery_area();
			reyhoon_checkout_pro.adress_drawer_actions();
			reyhoon_checkout_pro.open_date_time_timings();

			// Calculate the view panel when fragments are refreshed.
			$( document.body ).on( 'wc_fragments_refreshed', function() {
				reyhoon_checkout_pro.set_date_and_time();
				reyhoon_checkout_pro.mobile_view();
				reyhoon_checkout_pro.update_total();

			} );

			// Calculate the view panel when the checkout is updated (IE via tips)
			$( document.body ).on( 'updated_checkout', function() {
				reyhoon_checkout_pro.set_date_and_time();
				reyhoon_checkout_pro.mobile_view();
				reyhoon_checkout_pro.update_total();
				reyhoon_checkout_pro.open_date_time_timings();
				$( 'form.checkout_coupon' ).show();
			} );

			// Hide delivery options if this is a collection.
			$( document.body ).on( 'change', 'input.shipping_method', function() {
				reyhoon_checkout_pro.toggle_delivery_area();
				reyhoon_checkout_pro.mobile_view();
				reyhoon_checkout_pro.update_total();
			} );
		},

		update_total: function() {
			// FIXME برای آپدیت مجموع قیمت در دکمه تکمیل سفارش از این قسمت استفاده شود
			// var total = $('.order-total div:last-of-type').html();
			// $( '#place_order' ).html( total );
		},

		/**
		 * Move elements around for the mobile view.
		 */
		mobile_view: function() {

			var shipping_table = $( '#order_review .reyhoon-checkout__shipping-table' );

			if ( shipping_table.length ) {
				//var login_form = $( '.woocommerce-form-login.login' );
				var title = $( '<h3></h3>' ).text( 'روش تحویل را انتخاب کنید' );
				title.addClass( 'reyhoon_shipping_title' );

				$('#customer_details .reyhoon-checkout__shipping-table').remove();
				$('#customer_details .reyhoon_shipping_title').remove();

				$('#customer_details').prepend( shipping_table );
				$('#customer_details').prepend( title );
			}
		},

		/**
		 * Set Date and Time.
		 *
		 * When the shipping preview panel loads, we don't want to have
		 * to edit it immediately to set the date and time, so instead
		 * pick the first available ones. The customer can change them if
		 * they need to.
		 */
		set_date_and_time: function() {
			var date = document.querySelector( '#reyhoon-date' );
			var date_option = '';
			var date_value = '';
			if ( date ) {
				date_option = date.options[ date.selectedIndex ];
				if ( date_option ) {
					date_value = date_option.value;
					if ( ! date_value && date.options[ date.selectedIndex + 1 ] ) {
						date.options[ date.selectedIndex + 1 ].selected = true;
						$( date ).change();
					}
				}
			}

			if ( date_value === 'asap' ) {
				return;
			}

			var time = document.querySelector( '#reyhoon-time' );
			var time_option = '';
			if ( time ) {
				time_option = time.options[ time.selectedIndex ];
				if ( time_option && time.options[ time.selectedIndex + 1 ] ) {
					var time_value = time_option.value;
					if ( ! time_value ) {
						time.options[ time.selectedIndex + 1 ].selected = true;
						$( time ).change();
					}
				}
			}

			reyhoon_checkout_pro.toggle_delivery_area();
		},

		/**
		 * Toggle Delivery Area.
		 */
		toggle_delivery_area: function() {
			if($('form.checkout').hasClass('woo-def-checkout')) {
				return;
			}

			var shipping_method = document.querySelector( 'input.shipping_method:checked' );

			var resturantLocation = document.querySelector( '#resturant_location' );
			var userAdress = document.querySelector( '#user_adress' );
			var value = [];

			// If the shipping method choices exist, set the value.
			if ( shipping_method ) {
				value = shipping_method.value;
			}

			// If there are no shipping options, return.
			if ( value.length < 1 ) {
				return;
			}

			// If the choice is pickup, hide the delivery area.
			if ( value.includes( 'reyhoon_motorcycle' ) ||  value.includes( 'WC_Courier_Method')) {
				resturantLocation.style.display = 'none';
				userAdress.style.display = 'block';

			} else if( value.includes( 'reyhoon_local_pickup' ) || value.includes( 'reyhoon_serving' ) || value.includes( 'local_pickup' )) {
				userAdress.style.display = 'none';
				resturantLocation.style.display = 'block';

			}
		},

		adress_drawer_actions: function () {
			$('#confirm_location').click(function (){
				$('#address_drawer').toggleClass('address-show');
				$('#confirm_location').toggleClass('button-location-edit');
			})
		},

		open_date_time_timings:function (){
			$('.reyhoon-order-timings-header button').off('click');
			$('.reyhoon-order-timings-header button').click(function (){
				$('#date_time_timings').toggle(300);
			})
		},
	};

	$( document ).ready( reyhoon_checkout_pro.on_ready );

}( jQuery, document ) );
jQuery(document).ready(function ($) {
	$('.reyhoon-address-drawer-accept-address').click(function (e) {
		e.preventDefault();
		let address = $('#billing_address_1').val();
		$('.method-motorcycle-map p').text(address);
		$('.add-address').text('ویرایش آدرس');
		$(document.body).trigger('reyhoon-drawer.close');
	})

});
