<?php

/**
 * Timings settings.
 *
 * @package Reyhoon/Classes
 */

defined('ABSPATH') || exit;

/**
 * Timings settings class.
 */
class Reyhoon_Footer
{

    /**
     * Init.
     */
    public static function run()
    {
        add_filter('reyhoon_default_settings', array(__CLASS__, 'default_settings'));
        add_filter('wpsf_register_settings_reyhoon', array(__CLASS__, 'register_settings'), 20);


    }

    public static function default_settings($default_settings = array())
    {


        return $default_settings;
    }

    /**
     * Register settings.
     *
     * @param array $settings
     *
     * @return array
     */
    public static function register_settings($settings = array())
    {
        $menus =
        $settings['tabs'][] = array(
            'id' => 'footer',
            'title' => __("Header/Footer Settings",'reyhoon'),
            'priority' => 10,
        );

        $settings['sections'][] = array(
            'tab_id' => 'footer',
            'section_id' => 'footer',
            'section_title' => __('Footer Settings', 'reyhoon'),
            'section_description' => '',
            'section_order' => 0,
            'fields' => array(
                array(
                    'id' => 'h_menus',
                    'title' => __("Header Menu",'reyhoon'),
                    'type' => 'select',
                    'choices' => self::get_menus()
                ),
                array(
                    'id' => 'h_delivery_cost',
                    'title' => __("Display delivery Fee / Display Custom Text",'reyhoon'),
                    'type' => 'toggle',
                    'subtitle' => __("If you deactivate this option, you can display your custom text in the header widget.",'reyhoon'),
                    'default' => true
                ),
                array(
                    'id' => 'h_widget_text',
                    'title' => __("Header Widget Text",'reyhoon'),
                    'type' => 'textArea',
                    'subtitle' => __("In this section, you can place your desired text or HTML for display in the header widget.",'reyhoon'),
                    'show_if' => array(
                        array(
                            'field' => 'footer_footer_h_delivery_cost',
                            'value' => ['false'],
                        ),
                    )
                ),
                array(
                    'id' => 'f_menus',
                    'title' => __("Footer Menu",'reyhoon'),
                    'type' => 'select',
                    'choices' => self::get_menus()
                ),
                array(
                    'id' => 'enamad',
                    'title' => 'لینک اینماد',
                    'type' => 'text',
                ),
                array(
                    'id' => 'insta',
                    'title' => __("Instagram Link",'reyhoon'),
                    'type' => 'text',

                ),
                array(
                    'id' => 'whats',
                    'title' => __("WhatsApp Link",'reyhoon'),
                    'type' => 'text',

                ),
                array(
                    'id' => 'phone',
                    'title' => __("Contact Number for the Collection",'reyhoon'),
                    'type' => 'text',

                ),
                array(
                    'id' => 'copyright',
                    'title' => __("Copyright",'reyhoon'),
                    'type' => 'custom',
                    'output' => self::get_copyright_settings(),

                ),
            )
        );

        return $settings;

    }

    public static function get_menus()
    {
        $menus_nav = wp_get_nav_menus();
        foreach ($menus_nav as $menu) {
            $menus[$menu->term_id] = $menu->name;
        }

        return !empty($menus) ? $menus : array(__("Menu not found",'reyhoon'));
    }

    public static function get_copyright_settings()
    {
        if (!is_admin()) {
            return;
        }
        ob_start(); ?>
            <strong class="reyhoon-table__rwd-labels"><?php _e("'Copyright'",'reyhoon') ?></strong>
            <?php echo Reyhoon_Helpers::get_pro_button(); ?>
            <?php
            return apply_filters('reyhoon_get_copyright_settings', ob_get_clean());
    }

}
