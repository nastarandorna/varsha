<?php

class Reyhoon_Wc_Login_Form
{

    public static function run()
    {
        if (is_admin() || shortcode_exists('reyhoon_otp')) {
            return;
        }

        add_shortcode('reyhoon_otp', array(__CLASS__, 'render_otp_form'));
    }

    public static function render_otp_form()
    {

        self::style();

        echo '<div class="reyhoon-drawer-overlay reyhoon-drawer-overlay--open" data-reyhoon-trigger="drawer.close"></div><div class="reyhoon-drawer otp reyhoon-drawer--open">';
        if(function_exists('df_digits_form')) {
            $values = array('render_form' => 1, 'type' => 'login-register' , 'redirect_to' => wc_get_checkout_url());
            echo df_digits_form_render($values);
        }else {
            woocommerce_login_form();
        }
        echo '</div></div>';

    }


    public static function style()
    {
        ob_start();
        ?>
        <style>
            #customer_login > div:last-child {
                margin-top: 48px;
                border-top: 1px solid var(--reyhoon-stroke);
                padding-top: 24px;
            }

            #customer_login > div h2 {
                text-align: center;
                color: var(--reyhoon-black);
                margin-bottom: 16px;
            }

            #customer_login input {
                border: 1px solid var(--reyhoon-stroke);
                border-radius: 8px;
            }

            #customer_login .woocommerce-form-row * {
                width: 100%;
                padding: 8px 0;
            }

            #customer_login .woocommerce-button {
                display: block;
                margin: 24px auto;
                width: 90%;
                height: 54px;
                border: 0;
                background-color: var(--reyhoon-main);
                color: #fff;
            }

        </style>
        <?php
        echo ob_get_clean();
    }
}
