<?php

if (!defined('WPINC')) {
    die;
}

if (!class_exists('Reyhoon_Motorcycle_Shipping_Method')) {
    class Reyhoon_Motorcycle_Shipping_Method extends WC_Shipping_Method
    {
        /**
         * Constructor for your shipping class
         *
         * @access public
         * @return void
         */
        public function __construct()
        {
            $this->id = 'reyhoon_motorcycle';
            $this->method_title = __("Motorcycle Courier",'reyhoon');
            $this->method_description = '';

            $this->init();

            $this->enabled = isset( $this->settings['enabled'] ) ? $this->settings['enabled'] : 'yes';
            $this->title = isset($this->settings['title']) ? $this->settings['title'] : __("Motorcycle Courier",'reyhoon');
        }

        /**
         * Init your settings
         *
         * @access public
         * @return void
         */
        function init()
        {
            // Load the settings API
            $this->init_form_fields();
            $this->init_settings();

            // Save settings in admin if you have any defined
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        /**
         * Define settings field for this shipping
         * @return void
         */
        function init_form_fields()
        {

            $this->form_fields = array(

                'enabled' => array(
                    'title' => 'فعال سازی',
                    'type' => 'checkbox',
                    'default' => 'yes'
                ),

                'title' => array(
                    'title' => 'عنوان',
                    'type' => 'text',
                    'default' => __("Motorcycle Courier",'reyhoon')
                ),

                'cost' => array(
                    'title' => 'قیمت',
                    'type' => 'text',
                    'default' => '12000'
                ),

            );

        }

        public function is_available( $package = [] ): bool {
            return $this->enabled === 'yes' ? true : false;
        }

        /**
         * This function is used to calculate the shipping cost. Within this function we can check for weights, dimensions and other parameters.
         *
         * @access public
         * @param mixed $package
         * @return void
         */
        public function calculate_shipping($package = array())
        {

            $cost = $this->get_option( 'cost' );

            $rate = array(
                'id' => $this->id,
                'label' => $this->title,
                'cost' => $cost,
                'package' => $package,
            );

            $this->add_rate($rate);

        }
    }
}
