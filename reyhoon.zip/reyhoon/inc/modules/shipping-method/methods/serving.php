<?php

if (!defined('WPINC')) {
    die;
}

if (!class_exists('Reyhoon_Serving_Shipping_Method')) {
    class Reyhoon_Serving_Shipping_Method extends WC_Shipping_Method
    {
        /**
         * Constructor for your shipping class
         *
         * @access public
         * @return void
         */
        public function __construct()
        {
            $this->id = 'reyhoon_serving';
            $this->method_title = __("On-site dining",'reyhoon');

            $this->init();

            $this->enabled = isset( $this->settings['enabled'] ) ? $this->settings['enabled'] : 'yes';
            $this->title = isset($this->settings['title']) ? $this->settings['title'] : __("On-site dining",'reyhoon');
        }

        /**
         * Init your settings
         *
         * @access public
         * @return void
         */
        function init()
        {
            // Load the settings API
            $this->init_form_fields();
            $this->init_settings();

            // Save settings in admin if you have any defined
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        /**
         * Define settings field for this shipping
         * @return void
         */
        function init_form_fields()
        {

            $this->form_fields = array(

                'enabled' => array(
                    'title' => __("Activate",'reyhoon'),
                    'type' => 'checkbox',
                    'default' => 'yes'
                ),

                'title' => array(
                    'title' => __("Title",'reyhoon'),
                    'type' => 'text',
                    'default' => __("On-site dining",'reyhoon')
                ),

                'desc' => array(
                    'title' => __("Subtitle",'reyhoon'),
                    'type' => 'text',
                    'default' => __("In the restaurant space",'reyhoon')
                ),
            );

        }

        public function is_available( $package = [] ): bool {
            return $this->enabled === 'yes' ? true : false;
        }

        /**
         * This function is used to calculate the shipping cost. Within this function we can check for weights, dimensions and other parameters.
         *
         * @access public
         * @param mixed $package
         * @return void
         */
        public function calculate_shipping($package = array())
        {

            $rate = array(
                'id' => $this->id,
                'label' => $this->title,
                'cost' => 0,
                'package' => $package,
            );

            $rate['meta_data']['description'] = $this->get_option( 'desc' );

            $this->add_rate($rate);

        }
    }
}
