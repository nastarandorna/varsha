<?php
class Reyhoon_Shipping_Method {
    /**
     * Init.
     */
    public static function run() {
        if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
            add_action( 'woocommerce_shipping_init', array( __CLASS__, 'reyhoon_shippings_method' ));
            add_filter( 'woocommerce_shipping_methods', array( __CLASS__,'add_reyhoon_shippings_method' ));
        }
    }

    public static function reyhoon_shippings_method()
    {
        require_once REYHOON_MODULES_PATH . 'shipping-method/methods/motorcycle.php';
        require_once REYHOON_MODULES_PATH . 'shipping-method/methods/local-pickup.php';
        require_once REYHOON_MODULES_PATH . 'shipping-method/methods/serving.php';
    }

    public static function add_reyhoon_shippings_method( $methods ) {
        $methods['reyhoon_motorcycle'] = 'Reyhoon_Motorcycle_Shipping_Method';
        $methods['reyhoon_local_pickup'] = 'Reyhoon_Local_Pickup_Shipping_Method';
        $methods['reyhoon_serving'] = 'Reyhoon_Serving_Shipping_Method';
        return $methods;
    }

	public static function get_shipping_cost_by_id( $shipping_name = 'reyhoon_motorcycle' ) {
		return wc_price(get_option('woocommerce_'. $shipping_name .'_settings')['cost']);
	}

}
