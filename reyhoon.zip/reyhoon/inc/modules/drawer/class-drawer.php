<?php
/**
 * Module: Drawer.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Drawer module class.
 */
class Reyhoon_Drawer {
	/**
	 * Init.
	 */
	public static function run() {
		self::load_classes();

		add_action( 'wp_footer', array( __CLASS__, 'add' ) );
		add_filter( 'woocommerce_add_to_cart_fragments', array( __CLASS__, 'cart_count_fragments' ), 10, 1 );
		add_filter( 'woocommerce_add_to_cart_fragments', array( __CLASS__, 'cart_content_fragments' ), 10, 1 );
		add_filter( 'woocommerce_cart_item_permalink', '__return_false' );
		add_filter( 'wc_get_template', array( __CLASS__, 'mini_cart_template' ), 100, 5 );
	}

	/**
	 * Load classes for this module.
	 */
	public static function load_classes() {
		$classes = array(
			'drawer-settings' => 'Reyhoon_Drawer_Settings',
			'drawer-ajax' => 'Reyhoon_Drawer_Ajax',
		);

		foreach ( $classes as $file_name => $class_name ) {
			require_once REYHOON_MODULES_PATH . 'drawer/class-' . $file_name . '.php';

			$class_name::run();
		}
	}

	/**
	 * Add drawer and overlay.
	 */
	public static function add() {
		if ( is_admin() || is_cart() || is_checkout() ) {
			return;
		}

		include Reyhoon_Helpers::get_template_path( 'overlay.php', 'drawer' );
		include Reyhoon_Helpers::get_template_path( 'drawer.php', 'drawer' );
		include Reyhoon_Helpers::get_template_path( 'floating-cart.php', 'drawer' );
	}

	/**
	 * Update cart count after adding to cart.
	 *
	 * @param array $fragments Array of HTML fragments.
	 *
	 * @return mixed
	 */
	public static function cart_count_fragments( $fragments ) {
		ob_start();

		include Reyhoon_Helpers::get_template_path( 'floating-cart.php', 'drawer' );

		$fragments['.reyhoon-floating-cart'] = ob_get_clean();

		return $fragments;
	}

	/**
	 * Update cart content after adding to cart.
	 *
	 * @param array $fragments Array of HTML fragments.
	 *
	 * @return mixed
	 */
	public static function cart_content_fragments( $fragments ) {
		ob_start();

		self::mini_cart();

		$fragments['.reyhoon-mini-cart-wrapper'] = ob_get_clean();

		return $fragments;
	}

	/**
	 * Replace mini cart template.
	 *
	 * @param string $template
	 * @param string $template_name
	 * @param array  $args
	 * @param string $template_path
	 * @param string $default_path
	 *
	 * @return string
	 */
	public static function mini_cart_template( $template, $template_name, $args, $template_path, $default_path ) {
		if ( 'cart/mini-cart.php' !== $template_name ) {
			return $template;
		}

		if ( empty( $args['reyhoon'] ) ) {
			return $template;
		}

		// if file exists in theme, use that.
		$theme_file = get_stylesheet_directory() . '/reyhoon/cart/mini-cart.php';
		if ( file_exists( $theme_file ) ) {
			return $theme_file;
		}

		return REYHOON_PATH . 'woocommerce/cart/mini-cart.php';
	}

	/**
	 * Output mini cart with Reyhoon param set.
	 */
	public static function mini_cart() {
		?>
		<div class="reyhoon-mini-cart-wrapper">
			<?php woocommerce_mini_cart( array( 'reyhoon' => true ) ); ?>
		</div>
		<?php
	}
}
