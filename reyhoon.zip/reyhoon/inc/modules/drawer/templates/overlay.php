<?php
/**
 * Drawer: Overlay.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/drawer/overlay.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="reyhoon-drawer-overlay" data-reyhoon-trigger="drawer.close"></div>
