<?php
/**
 * Drawer: Floating Cart Button.
 *
 * This template can be overridden by copying it to yourtheme/reyhoon/drawer/floating-cart.php
 *
 * HOWEVER, on occasion Reyhoon will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @package Reyhoon/Templates
 */

defined( 'ABSPATH' ) || exit;


$cart_count = WC()->cart->get_cart_contents_count();
$style      = Reyhoon_Drawer_Settings::get_cart_icon_css();
?>

<div class="reyhoon-floating-cart reyhoon-floating-cart--br" data-reyhoon-trigger="cart" style="<?php echo esc_attr( $style ); ?>">
	<button class="reyhoon-floating-cart__button"><?php _e("Place an Order",'reyhoon'); ?><span><?php echo wp_kses_data( $cart_count ); ?><?php _e("Item",'reyhoon'); ?></span></button>
</div>
