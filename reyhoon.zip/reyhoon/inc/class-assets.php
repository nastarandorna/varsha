<?php
/**
 * Script and style assets.
 *
 * @package Reyhoon/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Assets class.
 */
class Reyhoon_Assets {
    /**
     * Run.
     */
    public static function run() {
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'frontend_assets' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
    }

    /**
     * Frontend assets.
     */
    public static function frontend_assets() {
        if ( is_admin() ) {
            return;
        }

        $suffix     = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '' /* FIXME :: '.min' */;
        $suffix_css = ( is_rtl() ? '-rtl' : '' ) . $suffix;

        wp_enqueue_style( 'reyhoon', REYHOON_ASSETS_URL . 'frontend/css/main' .  $suffix_css . '.css', array(), REYHOON_VERSION );
        wp_enqueue_script( 'reyhoon', REYHOON_ASSETS_URL . 'frontend/js/main' . $suffix . '.js', array( 'jquery' , 'wc-add-to-cart' , 'ryn-event' ), REYHOON_VERSION, true );

        if(Reyhoon_Settings::get_setting('style_style_color')){
            $color = Reyhoon_Settings::get_setting('style_style_color'); //E.g. #FF0000
            $main_color_css = "
                :root{
                        --reyhoon-main : {$color};
                }";
            wp_add_inline_style('reyhoon',$main_color_css);
        }

        wp_localize_script( 'reyhoon', 'reyhoon_vars', array(
            'i18n'                                => array(
                'out_of_stock' => __( 'Sorry, that product is out of stock.', 'reyhoon' ),
                'unavailable'  => __( 'Sorry, that product is unavailable.', 'reyhoon' ),
                'no_exist'     => __( 'Sorry, that combination does not exist.', 'reyhoon' ),
            ),
            'ajax_url'                            => WC()->ajax_url(),
            /**
             * If the option "Enable AJAX add to cart buttons on archives" is not enabled,
             * we need to turn off the click event for .add_to_cart_button elements on drawer.js
             * to keep the AJAX behaviour only on Mini cart.
             */
            'woocommerce_enable_ajax_add_to_cart' => 'yes' === get_option( 'woocommerce_enable_ajax_add_to_cart' ),
            'sw_url' => site_url().'/sw.js',
            'site_name' => get_bloginfo(),
        ) );

		if (is_product()){

				$product_style = array(
					'woocommerce-layout'      => array(
						'src'     => plugins_url( 'assets/css/woocommerce-layout-rtl.css', WC_PLUGIN_FILE ),
						'deps'    => '',
						'version' => REYHOON_VERSION,
						'media'   => 'all',
					),
					'woocommerce-smallscreen' => array(
						'src'     => plugins_url( 'assets/css/woocommerce-smallscreen-rtl.css', WC_PLUGIN_FILE ),
						'deps'    => 'woocommerce-layout-rtl',
						'version' => REYHOON_VERSION,
						'media'   => 'only screen and (max-width: ' . apply_filters( 'woocommerce_style_smallscreen_breakpoint', '768px' ) . ')',
					),
					'woocommerce'     => array(
						'src'     => plugins_url( 'assets/css/woocommerce-rtl.css' , WC_PLUGIN_FILE ),
						'deps'    => '',
						'version' => REYHOON_VERSION,
						'media'   => 'all',
					),
				);
			foreach ( $product_style as $handle => $args ) {

				wp_enqueue_style( $handle, $args['src'], $args['deps'], $args['version'], $args['media'] );
			}
		}

        do_action( 'reyhoon_after_frontend_assets' );
    }

    /**
     * Admin assets.
     */
    public static function admin_assets($hook_suffix) {
        if($hook_suffix == 'post.php' || $hook_suffix == 'post-new.php' || (class_exists('DakhlPlus_Admin') && DakhlPlus_Admin::is_dakhlplus())) {
            wp_enqueue_script('reyhoon-qrcode',REYHOON_ASSETS_URL.'admin/js/qrcode.js',array('jquery'),REYHOON_VERSION);
            wp_enqueue_script('ryn-qrcode-generator',REYHOON_ASSETS_URL.'admin/js/qr-generator.js',array('reyhoon-qrcode'),REYHOON_VERSION,true);
        }
        if ( ! is_admin() || ! Reyhoon_Settings::is_settings_page() ) {
            return;
        }

        $suffix      = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
        $style_deps  = apply_filters( 'reyhoon_admin_style_deps', array() );
        $script_deps = apply_filters( 'reyhoon_admin_script_deps', array( 'jquery' ) );

        wp_enqueue_style( 'reyhoon', REYHOON_ASSETS_URL . 'admin/css/main' . $suffix . '.css', $style_deps, REYHOON_VERSION );
        wp_enqueue_style( 'select2', REYHOON_ASSETS_URL . 'vendor/select2/select2' . $suffix . '.css', array(), REYHOON_VERSION );

        wp_enqueue_media();
        wp_enqueue_script( 'reyhoon-select2', REYHOON_ASSETS_URL . 'vendor/select2/select2' . $suffix . '.js', $script_deps, REYHOON_VERSION );
        wp_enqueue_script( 'reyhoon-jquery-multi-select', REYHOON_ASSETS_URL . 'vendor/jquery-multi-select/jquery.multi-select' . $suffix . '.js', array( 'jquery' ), REYHOON_VERSION );
        wp_enqueue_script( 'reyhoon', REYHOON_ASSETS_URL . 'admin/js/main' . $suffix . '.js', array( 'jquery' ), REYHOON_VERSION );

        do_action( 'reyhoon_admin_assets_enqueued' );
    }

}
